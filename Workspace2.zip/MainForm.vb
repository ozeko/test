Imports System.Threading    'for Sleep
Imports System.IO.Ports     ' for SerialError
Imports System.IO           'for File



Public Class MainForm


    '--------------------------------------------------------------------------------------------
    '
    '   MainForm  --- Starts Application
    '
    '--------------------------------------------------------------------------------------------

    'Instances of MDI-Children Forms  --> Moved to CmnModule.vb
    'Friend BreakerForm As New BreakerForm
    'Friend AutoSaveForm As New AutoSaveForm
    'Friend ConnectForm As New ConnectForm
    'Friend EndForm As New EndForm
    'Friend HelpForm As New HelpForm
    'Friend InfoForm As New InfoForm
    'Friend InvTestForm1 As New InvTestForm1
    'Friend InvTestForm2 As New InvTestForm2
    'Friend InvTestForm3 As New InvTestForm3
    'Friend MicTestForm1 As New MicTestForm1
    'Friend MicTestForm2 As New MicTestForm2
    'Friend OutlineForm As New OutlineForm
    'Friend SelfTestForm As New SelfTestForm
    'Friend StartForm As New StartForm
    'Friend TrbForm1 As New TrbForm1
    'Friend TrbForm2 As New TrbForm2
    'Friend TuningForm As New TuningForm

    Friend AutoSaveForm As AutoSaveForm
    Friend ConnectForm As ConnectForm
    Friend EndForm As EndForm
    Friend InvPCBTestForm1 As InvPCBTestForm1
    'Friend InvPCBTestForm2 As InvPCBTestForm2
    'Friend InvPCBTestForm3 As InvPCBTestForm3
    'Friend InvUnitTestForm As InvUnitTestForm
    Friend MicTestForm2 As AccpTestForm1
    Friend TCUTestForm As TCUTestForm1
    Friend SelfTestForm As SelfTestForm
    Friend StartForm As StartForm
    Friend TrbForm1 As TrbForm1
    Friend TrbForm2 As TrbForm2
    Friend TuningForm As TuningForm
    Friend OutlineForm As OutlineForm

    Friend BreakerForm As BreakerForm
    Friend InfoForm As InfoForm

    Friend InitMsgDlg As InitMsgDlg

    '---------------------------------------------------------------
    ' System Initialization
    ' 2009.04.01 updated
    '---------------------------------------------------------------
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim bRet As Boolean
        Dim iInstanceStatus As Integer
        Dim iRet As Integer
        Dim sIniFile As String

        Const APPTITLE As String = "BTE for PATH PA-5 HVAC"

        Try
            Me.DoubleBuffered = True

#If PATH2 Then
        glAppHomePath = Application.StartupPath
#Else
        glAppHomePath = Application.StartupPath & "\..\.."
#End If

            '-------------------------------------------------------------
            '  Confirms the existence of RW folder and PATHBTE_RW.ini
            '  2013.03.07 add to control the users access right
            '-------------------------------------------------------------
            'glRWIniPath = "C:\TestReport\RW"
            If My.Computer.FileSystem.DirectoryExists(glRWIniPath) = False Then
                My.Computer.FileSystem.CreateDirectory(glRWIniPath)
            End If
            'Sets RW File Path as the hidden folder
            Dim diMyDir As New DirectoryInfo(glRWIniPath)
            diMyDir.Attributes = FileAttributes.Hidden

            'Copies PATHBTE_RW.ini if it does not exist in the RWIniPath
            If (My.Computer.FileSystem.FileExists(glRWIniFile) = False) Then
                My.Computer.FileSystem.CopyFile(glAppHomePath & "\" & INIFILE_RW, glRWIniFile)
            End If
            '-----

            'Single instance can exist
            sIniFile = glAppHomePath & "\" & INIFILE

            iInstanceStatus = GetPrivateProfileInt("STARTUP", "INSTANCE", 0, glRWIniFile)

            Select Case iInstanceStatus
                Case 0, 2
                    iRet = WritePrivateProfileString("STARTUP", "INSTANCE", 1, glRWIniFile)

                Case 1
                    Dim MyProcess As Process = Process.GetCurrentProcess
                    Dim processes() As Process
                    processes = Process.GetProcesses()
                    Dim sMyName As String = My.Application.Info.AssemblyName.ToString

                    For idx As Integer = 0 To processes.Length - 1
                        If sMyName.Equals(processes(idx).ProcessName.ToString) Then
                            If MyProcess.Id <> processes(idx).Id Then
                                Dim hwnd As IntPtr = FindWindow(vbNullString, APPTITLE)
                                If hwnd <> 0 Then
                                    AppActivate(APPTITLE)
                                    'ShowWindow(hwnd, SW_SHOWMAXIMIZED)'@@@ mrk for debug
                                    'if the same name application already exists, stops execution
                                    End
                                End If
                            End If
                        End If
                    Next idx
            End Select

            InitMsgDlg = New InitMsgDlg
            InitMsgDlg.Show()
            Application.DoEvents()

            StartForm = New StartForm

            '---------------------------------------------------------------
            ' Multimeter Port Initialization (COM2, COM7)  
            '---------------------------------------------------------------
            '' mod k.sakemi 2009/10/08 
            bRet = gfncMultiOpen(Me.Com2)
            bRet = gfncMultiOpen(Me.Com7)
            '' mod end

            '---------------------------------------------------------------
            ' Port Open for all Cards
            '---------------------------------------------------------------
            bRet = gfncDIOCardSettingIni()
            bRet = gfncAllCardPortOpen()

            '---------------------------------------------------------------
            ' Sets All DO(Relay) Card to 0
            '---------------------------------------------------------------
            If gfncDOALLClear() <> True Then
                Call subWriteErrorLog("DO All Clear Error", "at MainForm_Load")
            End If

            '---------------------------------------------------------------
            ' Set All AO Card to 0
            '---------------------------------------------------------------
            If gfncAOALLClear() <> True Then
                Call subWriteErrorLog("AO All Clear Error", "at MainForm_Load")
            End If

            '---------------------------------------------------------------
            ' Multimeter and Built-in Multiplexer Initialization
            '---------------------------------------------------------------
            bRet = gfncReadScanCmdFromIni()

            If gfncMultiInit(False) <> True Then    'add  False flag 2010/04/05 K.Sakamoto
                Call subWriteErrorLog("Multimeter Initialization Error", "at MainForm_Load")
            End If

            '' add k.sakemi 2009/10/08
            bRet = fncGetMultiSetValFromINI()       '' Multimeter SetData Read for Each SelfTests
            '' add end

            '---------------------------------------------------------------
            ' Changes where to start
            '---------------------------------------------------------------
            InitMsgDlg.Dispose()

            '' mod k.sakemi 2009/09/25
            'Me.Text = "BTE for PATH HVAC"
            Me.Text = APPTITLE
            '' mod end


            'Test Status Panel
            Panel1.Visible = False

            Dim iStatus As Integer = GetPrivateProfileInt("STARTUP", "STATUS", 0, glRWIniFile)
            Dim strBuffer As New System.Text.StringBuilder

            strBuffer.Capacity = 255

            Call subResetTSInfoData()

            Select Case iStatus
                Case 0  'from the beginning
                    '----------------------------
                    ' RS-232C Open
                    '----------------------------
                    If fncMICRs232cOpen() <> True Then
                        Call subWriteErrorLog("COM1 Open (for Controller)  Error", "MainForm_Load")
                        MessageBox.Show("Error occurred at Main Menu Loading Procedure.(COM1 Open Error)", _
                                "System Execution Aborted.", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        iRet = WritePrivateProfileString("STARTUP", "INSTANCE", 0, glRWIniFile)
                        End
                        Exit Sub
                    End If

                    '' add k.sakemi 2009/10/07
                    '----------------------------
                    ' COM8 Open for Inverter
                    '----------------------------
                    If fncInvRs232cOpen() <> True Then
                        Call subWriteErrorLog("COM8 Open (for Inverter) Error", "MainForm_Load")
                        MessageBox.Show("Error occurred at Main Menu Loading Procedure.(COM8 Open Error)", _
                                "System Execution Aborted.", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        iRet = WritePrivateProfileString("STARTUP", "INSTANCE", 0, glRWIniFile)
                        End
                        Exit Sub
                    End If
                    '' add end

                    StartForm.LblVer.Text = "Ver." & Application.ProductVersion
                    StartForm.Show()


                Case 1  'after rerun (to execute Additional Test at Inverter Test)
                    '----------------------------
                    ' COM1 Open for Inverter
                    '----------------------------
                    If fncInvRs232cOpen() <> True Then
                        Call subWriteErrorLog("COM1 Open (for Inverter) Error", "MainForm_Load")
                        MessageBox.Show("Error occurred at Main Menu Loading Procedure.(COM1 Open Error)", _
                                "System Execution Aborted.", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        iRet = WritePrivateProfileString("STARTUP", "INSTANCE", 0, glRWIniFile)
                        End
                        Exit Sub
                    End If

                    'Gets Test Information from INI
                    iRet = GetPrivateProfileString("STARTUP", "UNIT_SERIALNO", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glUnitSerialNo = strBuffer.ToString.Trim

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "TESTDATE", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glUnitDateTime = strBuffer.ToString.Trim

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "FLTCODE", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glstrTestFltCode = strBuffer.ToString.Trim

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "ADDTEST_PTNNO", "0", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glAddTestPtnNo = CInt(strBuffer.ToString)

                    glTestName = NAME_INVTEST
                    glTarget = TestTarget.HvacInverter
                    glAdditionalTestF = True
                    glDispChgNo = DispChgNo.FList_V6Start
                    bRet = gfncDispChg(glDispChgNo)


                Case 2  'after rerun (to execute Additional Test (from History List) at Inverter Test )
                    If fncInvRs232cOpen() <> True Then
                        Call subWriteErrorLog("COM1 Open (for Inverter) Error", "MainForm_Load")
                        MessageBox.Show("Error occurred at Main Menu Loading Procedure.(COM1 Open Error)", _
                                "System Execution Aborted.", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        iRet = WritePrivateProfileString("STARTUP", "INSTANCE", 0, glRWIniFile)
                        End
                        Exit Sub
                    End If

                    'Gets Test Information from INI
                    iRet = GetPrivateProfileString("STARTUP", "UNIT_SERIALNO", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glUnitSerialNo = strBuffer.ToString.Trim

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "TESTDATE", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glUnitDateTime = strBuffer.ToString.Trim

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "FLTCODE", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glstrTestFltCode = strBuffer.ToString.Trim

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "ADDTEST_PTNNO", "0", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glAddTestPtnNo = CInt(strBuffer.ToString)

                    strBuffer.Remove(0, strBuffer.Length)
                    iRet = GetPrivateProfileString("STARTUP", "HISTORY_FILE", "", strBuffer, strBuffer.Capacity, glRWIniFile)
                    glCurrentTestReportName = strBuffer.ToString.Trim

                    glTestName = NAME_INVTEST
                    glTarget = TestTarget.HvacInverter
                    glAdditionalTestF = True
                    glDispChgNo = DispChgNo.FList_VHistoryStart
                    bRet = gfncDispChg(glDispChgNo)
            End Select

            glIsEMStopBtnPushed = False


            '' del k.sakemi 2009/11/26 default False
            'TimerEMStopChk.Enabled = True   'starts timer to check emergency stop button


            '#If DEMO Then
#If EMCHK = False Then
            DEMO_EMPanel.Visible = True
#End If

        Catch ex As Exception
            Call subWriteErrorLog("Error Occurred [" & ex.Message.ToString, "at MainForm_Load")
        End Try

    End Sub




    '-----------------------------------------------------------------------------------------------------
    '   Multimeter Error Code Detecting Procedure
    '
    '                               [Return   ] None
    '                               [Parameter] ARG1 - (IN) String
    '
    '   2008.03.04 updated
    '
    '  **** Enough? Or other error codes?
    '-----------------------------------------------------------------------------------------------------
    Private Sub Com2_ErrorReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialErrorReceivedEventArgs) _
        Handles Com2.ErrorReceived, Com7.ErrorReceived      '' add k.sakemi 2009/10/26

        Select Case e.EventType
            Case SerialError.Frame      'Frame error
                glMultiErrStat = SerialError.Frame
            Case SerialError.Overrun    'String buffer overruns
                glMultiErrStat = SerialError.Overrun
            Case SerialError.RXOver     'Receive buffer overflows
                glMultiErrStat = SerialError.RXOver
            Case SerialError.RXParity   'Parity error
                glMultiErrStat = SerialError.RXParity
            Case SerialError.TXFull     'Send buffer is full
                glMultiErrStat = SerialError.TXFull
        End Select

    End Sub



    '-----------------------------------------------------------------------------------------------------
    '   Multimeter ScanTimer   <Event Procedure>
    '
    '                               [Return     ] None
    '                               [Parameter  ] None
    ' 2008.01.22 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub ScanTimer_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ScanTimer.Tick

        glMultiTmrCnt = glMultiTmrCnt + 1
    
    End Sub



    '--------------------------------------------------------------------------------------------------------------------
    '   MODULE NAME : Com1_DataReceived
    '   FUNCTION         : Detects RS-232C Transmission Error Code
    '                               [Return     ] None
    '                               [Parameter] None
    '
    '   2008.03.04 updated
    '--------------------------------------------------------------------------------------------------------------------
    Private Sub Com1_DataReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialDataReceivedEventArgs) Handles Com1.DataReceived

        'Reset Timer Counter
        glInvTmrCnt = 0
    
    End Sub



    '--------------------------------------------------------------------------------------------------------------------
    '   MODULE NAME : Com1_ErrorReceived
    '   FUNCTION         : Detects RS-232C Transmission Error Code
    '                               [Return   ] None
    '                               [Parameter] 
    '
    '   2008.02.29 updated
    '--------------------------------------------------------------------------------------------------------------------
    Private Sub Com1_ErrorReceived(ByVal sender As Object, ByVal e As System.IO.Ports.SerialErrorReceivedEventArgs) _
                                    Handles Com1.ErrorReceived

        Select Case e.EventType
            Case SerialError.Frame      'Frame error
                glInvErrStat = SerialError.Frame
                glInvTmrStat = D_TIMEHARDERR          'Timer status

            Case SerialError.Overrun    'String buffer overruns
                glInvErrStat = SerialError.Overrun
                glInvTmrStat = D_TIMEHARDERR          'Timer status

            Case SerialError.RXOver     'Receive buffer overflows
                glInvErrStat = SerialError.RXOver
                glInvTmrStat = D_TIMEHARDERR          'Timer status

            Case SerialError.RXParity   'Parity error
                glInvErrStat = SerialError.RXParity
                glInvTmrStat = D_TIMEHARDERR          'Timer status

            Case SerialError.TXFull     'Send buffer is full
                glInvErrStat = SerialError.TXFull
                glInvTmrStat = D_TIMEHARDERR          'Timer status
        End Select

    End Sub


    '--------------------------------------------------------------------------------------------------------------------
    '   MODULE NAME : Timer2000_Tick   <Event Procedure>
    '   FUNCTION         : Count up
    '                               [Return     ] None
    '                               [Parameter] None
    '
    '   2008.02.29 updated
    '--------------------------------------------------------------------------------------------------------------------
    Private Sub Timer2000_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer2000.Tick

        glInvTmrCnt = glInvTmrCnt + 1

    End Sub



    '--------------------------------------------------------------------------------------------------------------------
    '   MODULE NAME : Timer2000_Tick   <Event Procedure>
    '   FUNCTION         : Count up
    '                               [Return     ] None
    '                               [Parameter] None
    '
    '   2008.02.29 updated
    '--------------------------------------------------------------------------------------------------------------------
    Private Sub Timer500_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer500.Tick

        glInvTmr05ChkCnt = glInvTmr05ChkCnt + 1

    End Sub



    '-------------------------------------------------------------------------------------------------------
    '   Cancels [x] button on MainForm Window and Alt+F4 action
    '   2008.03.07 updated
    '-------------------------------------------------------------------------------------------------------
    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        Const WM_SYSCOMMAND As Int32 = &H112%
        Const SC_CLOSE As Int32 = &HF060%

        If (m.Msg = WM_SYSCOMMAND) AndAlso (m.WParam.ToInt32 = SC_CLOSE) Then
            m.Result = System.IntPtr.Zero
        Else
            MyBase.WndProc(m)
        End If

    End Sub


    '-------------------------------------------------------------------------------------------------------
    '   Normally displays window at Maximum Size
    '   2008.07.14 updated
    '-------------------------------------------------------------------------------------------------------
    Private Sub MainForm_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged

        If Me.WindowState <> FormWindowState.Minimized Then
            Me.WindowState = FormWindowState.Maximized
        End If

    End Sub

  
   
    '-------------------------------------------------------------------------------------------------------
    '   Clicks Emergency Stop DEMO Button
    '   2009.04.06 updated
    '-------------------------------------------------------------------------------------------------------
    Private Sub btnEMStopDEMO_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnEMStopDEMO.Click

        glIsEMStopBtnPushed = IIf(glIsEMStopBtnPushed, False, True)
        lblEMBtnClickCnt.Text = IIf(glIsEMStopBtnPushed, "True", "False")

    End Sub


    '-------------------------------------------------------------------------------------------------------
    '   Emergency Stop Check Timer
    '   2009.04.01 updated
    '-------------------------------------------------------------------------------------------------------
    Private Sub TimerEMStopChk_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimerEMStopChk.Tick

        Try
            TimerEMStopChk.Enabled = False

#If DEMO Then
            Me.MsgLbl.Text = "Timer"
            'Thread.Sleep(200)
            Application.DoEvents()
#End If
            If fncEmergencyStopBtnCheck() = False Then      'emergency stop button has not been pushed
                TimerEMStopChk.Enabled = True
            End If

        Catch ex As Exception
            Call subWriteErrorLog("Error Occurred [" & ex.Message.ToString, "at TimerEMStopChk_Tick of MainForm")
        End Try

    End Sub


    ''' <summary>
    ''' TestFlow lblClick ACCP
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub LblMic_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LblMic2.Click, LblMic3.Click, _
                                LblMic4.Click, LblMic5.Click, LblMic6.Click, LblMic7.Click, _
                                LblMic8.Click, LblMic9.Click, LblMic10.Click, LblMic11.Click, LblMic12.Click, _
                                LblMic13.Click, LblMic14.Click


        Dim lbls As Label() = New Label() _
                                {Me.LblMic2, Me.LblMic3, Me.LblMic4, Me.LblMic5, _
                                 Me.LblMic6, Me.LblMic7, Me.LblMic8, Me.LblMic9, Me.LblMic10, _
                                 Me.LblMic11, Me.LblMic12, Me.LblMic13, Me.LblMic14}

        Dim lbl As Label = DirectCast(sender, Label)


        '' only displayed Result
        If AccpTestForm1.grpResult.Visible = False Then
            Exit Sub
        End If

        '' only ( OK or ERR or ABORT )  mod k.sakemi 2010/01/06
        If lbl.BackColor <> Color.FromName(COLOR_OK) And lbl.BackColor <> Color.FromName(COLOR_ERR) _
            And lbl.BackColor <> Color.FromName(COLOR_ABORT) Then
            Exit Sub
        End If


        For i As Integer = 0 To lbls.Length - 1
            If lbl.Equals(lbls(i)) Then


                If lbl.Text = "Power Voltage" Or lbl.Text = "Software Version" Or lbl.Text = "Transmission1" Or _
                   lbl.Text = "DI" Or lbl.Text = "DO" Then
                    AccpTestForm1.TabControl1.SelectTab(0)

                    AccpTestForm1.btnTabRestart.Visible = False

                ElseIf lbl.Text = "Analog Input" Or lbl.Text = "Parameter Set Value" Then
                    AccpTestForm1.TabControl1.SelectTab(1)

                    AccpTestForm1.btnTabRestart.Visible = False

                ElseIf lbl.Text = "LED" Then

                    AccpTestForm1.TabControl1.SelectTab(2)

                    AccpTestForm1.btnTabRestart.Visible = False

                ElseIf lbl.Text = "Switch" Or lbl.Text = "Transmission2" Then

                    AccpTestForm1.TabControl1.SelectTab(3)

                    AccpTestForm1.btnTabRestart.Visible = False

                ElseIf lbl.Text = "Main Circuit" Then

                    AccpTestForm1.TabControl1.SelectTab(4)

                    '' Abort or Fail are btnTabRestart Visible
                    If lbl.BackColor = Color.FromName(COLOR_ABORT) Or lbl.BackColor = Color.FromName(COLOR_ERR) Then
                        AccpTestForm1.btnTabRestart.Visible = True
                    Else
                        AccpTestForm1.btnTabRestart.Visible = False
                    End If

                ElseIf lbl.Text = "Protection Circuit" Then

                    AccpTestForm1.TabControl1.SelectTab(5)

                    '' Abort or Fail are btnTabRestart Visible
                    If lbl.BackColor = Color.FromName(COLOR_ABORT) Or lbl.BackColor = Color.FromName(COLOR_ERR) Then
                        AccpTestForm1.btnTabRestart.Visible = True
                    Else
                        AccpTestForm1.btnTabRestart.Visible = False
                    End If


                End If

                Exit For

            End If
        Next
        '' mod end


    End Sub

    ''' <summary>
    ''' TestFlow lblClick TCU
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks>mod 2010/01/22</remarks>
    Private Sub LblTCU_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LblTCU1.Click, LblTCU2.Click, _
                                LblTCU3.Click, LblTCU4.Click, LblTCU5.Click, LblTCU6.Click, LblTCU7.Click, _
                                LblTCU8.Click, LblTCU9.Click, LblTCU10.Click, LblTCU11.Click, _
                                LblTCUGold1.Click, LblTCUGold2.Click, _
                                LblTCUGold3.Click, LblTCUGold4.Click, LblTCUGold5.Click, LblTCUGold6.Click, LblTCUGold7.Click, _
                                LblTCUGold8.Click, LblTCUGold9.Click, LblTCUGold10.Click, LblTCUGold11.Click, LblTCUGold12.Click

        Dim lbls As Label()

        If glTestDetail = TestDetail.Test_M_SCP47 Or glTestDetail = TestDetail.Test_M_LON01 Or glTestDetail = TestDetail.Test_M_SCT23 Then

            lbls = New Label() {Me.LblTCUGold1, Me.LblTCUGold2, Me.LblTCUGold3, Me.LblTCUGold4, Me.LblTCUGold5, _
                                Me.LblTCUGold6, Me.LblTCUGold7, Me.LblTCUGold8, Me.LblTCUGold9, Me.LblTCUGold10, _
                                Me.LblTCUGold11, Me.LblTCUGold12}
        Else
            lbls = New Label() {Me.LblTCU1, Me.LblTCU2, Me.LblTCU3, Me.LblTCU4, Me.LblTCU5, _
                                Me.LblTCU6, Me.LblTCU7, Me.LblTCU8, Me.LblTCU9, Me.LblTCU10, _
                                Me.LblTCU11}

        End If
  
        Dim lbl As Label = DirectCast(sender, Label)


        '' only displayed Result
        If TCUTestForm1.grpResult.Visible = False Then
            Exit Sub
        End If


        '' only ( OK or ERR or ABORT )  mod k.sakemi 2010/01/06
        If lbl.BackColor <> Color.FromName(COLOR_OK) And lbl.BackColor <> Color.FromName(COLOR_ERR) _
            And lbl.BackColor <> Color.FromName(COLOR_ABORT) Then
            Exit Sub
        End If
        '' mod end

        For i As Integer = 0 To lbls.Length - 1
            If lbl.Equals(lbls(i)) Then


                If lbl.Text = "Power Voltage" Or lbl.Text = "Software Version" Or lbl.Text = "Transmission1" Or _
                   lbl.Text = "DI" Or lbl.Text = "DO" Or lbl.Text = "Appearance Check" Then

                    TCUTestForm1.TabControl1.SelectTab(0)

                ElseIf lbl.Text = "Analog Input" Or lbl.Text = "Parameter Set Value" Then

                    TCUTestForm1.TabControl1.SelectTab(1)

                ElseIf lbl.Text = "LED" Then

                    TCUTestForm1.TabControl1.SelectTab(2)

                ElseIf lbl.Text = "Switch" Or lbl.Text = "Transmission2" Then

                    TCUTestForm1.TabControl1.SelectTab(3)

                End If

                Exit For

            End If
        Next

    End Sub

 

    '
    ' invalidate "close button"
    '
    Protected Overrides ReadOnly Property CreateParams() As System.Windows.Forms.CreateParams

        Get
            Const CS_NOCLOSE As Integer = &H200
            Dim cp As CreateParams = MyBase.CreateParams
            cp.ClassStyle = cp.ClassStyle Or CS_NOCLOSE

            Return cp
        End Get

    End Property


End Class
