







- M-SPU23B Test 
    1. Main Menu
    2. Test Trasition (DummyForm)
    3. Test Information Input (InfoForm)
    4. Appearance Check (OutlineForm)
        - グループボックスの文字列のみ？
    5. Circuit Breaker Setting (BreakerForm)
    6. Connection Instruction (ConnectForm)
        - 指示図とガイダンス
    7. Circuit Breaker Setting (BreakerForm)
    8. M-SPU23B Test (自動試験) (PCBTestForm)
        - グループボックスの文字列のみ？ 試験方法は異なる。

        (手動試験) (SPU23TrbTestForm) ※ M－SPU23A： 8.2.1～8.2.9、8.3.1～8.3.12
        8.1.1. 手動測定試験 (入力部回路試験 1) (D12 (K) - Q4 (D)間)
        8.1.2. 手動測定試験 (入力部回路試験 2) (L2 2 - 4間)
        8.1.3. 手動測定試験 (入力部回路試験 3) (F1 1 - 2間)
        8.1.4. 手動測定試験 (入力部回路試験 4) (L2 4 - 2間)
        8.1.5. 手動測定試験 (5V出力部回路試験 1) (C7両端部)
    ※ 8.1.6. 手動測定試験 (5V出力部回路試験 2) (C17両端部)
        8.1.7. 手動測定試験 (5V出力部回路試験 3-1) (C13 1 - 2間)
        8.1.8. 手動測定試験 (5V出力部回路試験 3-2) (R8両端部, R9両端部)
        8.1.9. 手動測定試験 (5V出力部回路試験 3-3) (D5両端部)
        8.1.10. 手動測定試験 (5V出力部回路試験 3-4) (C12両端部)
        8.1.11. 手動測定試験 (5V出力部回路試験 3-5) (D4両端部, C18両端部)
        8.1.12. 手動測定試験 (5V出力部回路試験 3-6) (TP1 - TP2間)
        8.1.13. 手動測定試験 (5V出力部回路試験 3-7) (R34両端部)
        8.1.14. 手動測定試験 (5V出力部回路試験 3-8) (C28両端部)
        8.1.15. 手動測定試験 (5V出力部回路試験 3-9) (PC1 3 - 4間)
        8.1.16. 手動測定試験 (5V出力部回路試験 3-10) (C62両端部)
        8.1.17. 手動測定試験 (5V出力部回路試験 3-11) (R30_1 - R31_2間)
        8.1.18. 手動測定試験 (5V出力部回路試験 3-12) (C25両端部)
        8.1.19. 手動測定試験 (5V出力部回路試験 3-13) (C30両端部)

        8.2.1. 手動測定試験 (入力部回路試験 1) (D12 (K) - Q4 (D)間)
        8.2.2. 手動測定試験 (入力部回路試験 2) (L2 2 - 4間)
        8.2.3. 手動測定試験 (入力部回路試験 3) (F1 1 - 2間)
        8.2.4. 手動測定試験 (入力部回路試験 4) (L2 4 - 2間)
        8.2.5. 手動測定試験 (24V出力部回路試験 1) (C32両端部)
    ※ 8.2.6. 手動測定試験 (24V出力部回路試験 2) (C44両端部)
        8.2.7. 手動測定試験 (24V出力部回路試験 3-1) (C40両端部)
        8.2.8. 手動測定試験 (24V出力部回路試験 3-2) (R44両端部, R45両端部)
        8.2.9. 手動測定試験 (24V出力部回路試験 3-3) (D9両端部)

        8.2.10. 手動測定試験 (24V出力部回路試験 3-4) (C39両端部)
        8.2.11. 手動測定試験 (24V出力部回路試験 3-5) (D8両端部, C47両端部, R49両端部)
        8.2.12. 手動測定試験 (24V出力部回路試験 3-6) (TP3 - TP4間)
        8.2.13. 手動測定試験 (24V出力部回路試験 3-7) (R74両端部)
        8.2.14. 手動測定試験 (24V出力部回路試験 3-8) (C57両端部)
        8.2.15. 手動測定試験 (24V出力部回路試験 3-9) (PC3 3 - 4間)
        8.2.16. 手動測定試験 (24V出力部回路試験 3-10) (C50両端部)
        8.2.17. 手動測定試験 (24V出力部回路試験 3-11) (R69_1 - R70_2間)
        8.2.18. 手動測定試験 (24V出力部回路試験 3-12) (C54両端部)
        8.2.19. 手動測定試験 (24V出力部回路試験 3-13) (C60両端部)

        8.3.1. 手動測定試験 (入力部回路試験 1) (D12 (K) - Q4 (D)間)
        8.3.2. 手動測定試験 (入力部回路試験 2) (L2 2 - 4間)
        8.3.3. 手動測定試験 (入力部回路試験 3) (F1 1 - 2間)
        8.3.4. 手動測定試験 (入力部回路試験 4) (L2 4 - 2間)
        8.3.5. 手動測定試験 (24V出力部回路試験 1) (C32両端部)
        8.4.5. 手動測定試験 (5V出力部回路試験 1) (C7両端部)
    ※ 8.4.6. 手動測定試験 (5V出力部回路試験 2) (C17両端部)
        8.4.7. 手動測定試験 (5V出力部回路試験 3-1) (C13 1 - 2間)
        8.4.8. 手動測定試験 (5V出力部回路試験 3-2) (R8両端部, R9両端部)
        8.4.9. 手動測定試験 (5V出力部回路試験 3-3) (D5両端部)
        8.4.10. 手動測定試験 (5V出力部回路試験 3-4) (C12両端部)
        8.4.11. 手動測定試験 (5V出力部回路試験 3-5) (D4両端部, C18両端部)
        8.4.12. 手動測定試験 (5V出力部回路試験 3-6) (TP1 - TP2間)
        8.4.13. 手動測定試験 (5V出力部回路試験 3-7) (R34両端部)
        8.4.14. 手動測定試験 (5V出力部回路試験 3-8) (C28両端部)
        8.4.15. 手動測定試験 (5V出力部回路試験 3-9) (PC1 3 - 4間)
        8.4.16. 手動測定試験 (5V出力部回路試験 3-10) (C62両端部)
        8.4.17. 手動測定試験 (5V出力部回路試験 3-11) (R30_1 - R31_2間)
        8.4.18. 手動測定試験 (5V出力部回路試験 3-12) (C25両端部)
        8.4.19. 手動測定試験 (5V出力部回路試験 3-13) (C30両端部)
    ※ 8.3.6. 手動測定試験 (24V出力部回路試験 2) (C44両端部)
        8.3.7. 手動測定試験 (24V出力部回路試験 3-1) (C40両端部)
        8.3.8. 手動測定試験 (24V出力部回路試験 3-2) (R44両端部, R45両端部)
        8.3.9. 手動測定試験 (24V出力部回路試験 3-3) (D9両端部)
        8.3.10. 手動測定試験 (24V出力部回路試験 3-4) (C39両端部)
        8.3.11. 手動測定試験 (24V出力部回路試験 3-5) (D8両端部, C47両端部, R49両端部)
        8.3.12. 手動測定試験 (24V出力部回路試験 3-6) (TP3 - TP4間)
        8.3.13. 手動測定試験 (24V出力部回路試験 3-7) (R74両端部)
        8.3.14. 手動測定試験 (24V出力部回路試験 3-8) (C57両端部)
        8.3.15. 手動測定試験 (24V出力部回路試験 3-9) (PC3 3 - 4間)
        8.3.16. 手動測定試験 (24V出力部回路試験 3-10) (C50両端部)
        8.3.17. 手動測定試験 (24V出力部回路試験 3-11) (R69_1 - R70_2間)
        8.3.18. 手動測定試験 (24V出力部回路試験 3-12) (C54両端部)
        8.3.19. 手動測定試験 (24V出力部回路試験 3-13) (C60両端部)

    9. Circuit Breaker Setting
    10. Test Finish (Aborted)
    11. Test Result Save (Pass)
    12. Test Result Save (Pass)
    13. Test Result Not Save (Pass)
    14. Test Result Save (Fail)
    15. Test Result Save (Fail)
    16. Test Result Not Save (Fail)
    17. Fault Cause List
        17.1. Troubleshooting Guidance



### 変更点メモ

    - glTestData(`自動試験の結果２パタン(P/FとF/F)`,`TS試験項目数(自動試験の結果がP/Fの場合２個、F/Fの場合４個)`)
    - glSubTestData1~6(`(サブ試験における)STEP数`, `試験項目数(最大４項目)`)  ※1~6あるのは、glTestDataの試験数分
```vb
    'M-SPU23 trouble shooting operation data(ini file)
    Public glTestData(2 - 1, 4 - 1) As Trbshoot
    Public glSubTestData1(10 - 1, 4 - 1) As Trbshoot
                    ～
    Public glSubTestData6(10 - 1, 4 - 1) As Trbshoot

```




## 故障コード
- SPU23A - Sxxx
- SPU23B - Uxxx

- 外観検査 (subPCBTest -> fncAppearanceCheck @ PCBTestForm で以下のコードが`glstrTestFltCode`にセットされる)
    - `U501` The power supply board fault
    - `U502` The power supply board fault
- 自動試験 (subPCBTest @ PCBTestForm で以下のコードが`glstrTestFltCode`にセットされる)
    - `U001` P5 output fault
    - `U002` P24 output fault
    - `U003` All output fault


- `subPCBTest @ PCBTestForm`の大まかな流れ
```vb
        ・・・
        fncAppearanceCheck() ' ここで、U501/U502 がセットされる
        Thread.Sleep(5000)
        ・・・
        fncControlPowerChange(POWER_ON)
        fncDC5V24VRelayTest()   ' エラーが発生すれば mglFltListItmIdx　に 1 or 2 or 3 がセットされる
        fncControlPowerChange(POWER_OFF)
        ・・・
        fncGetFltCodefromTrbIni(mglFltFormIdx, mglFltListViewIdx, mglFltListItmIdx)' mglFltListItmIdx <> -1 なら、U001/U002/U003 がセットされる
```



# Output Power Voltage Test (R-PWR03C)
InvPCBTestForm1_Shown
    subInvPCBTest()
        fncOPVTest()
            glInvChkOPVT(0~4: "CN3"~"CN7")
                ChkData:  判定値
                Range:    ＋マージン(%) 
                Range2:   ーマージン(%) 
★ INIファイルは、[CRITERIA_INVTEST]
    OPVT_U12V　～　OPVT_CP12V

# PCB Test
- 電圧が 5V ±５％に収まっているかどうかのチェック (読み取った電圧値に補正値1.07を乗算してから比較する)
- ※ 1.07を掛けるということは、+７％(5.35)にすることなので、読取値が5Vだと当然max値を超える。
    - min: 4.75, max: 5.25
- 電圧が 24V ±５％に収まっているかどうかのチェック (読み取った電圧値に補正値1.02を乗算してから比較する)
    - min: 22.8, max: 25.2
★ INIファイルは、[CRITERIA_PCBTEST]




★ SPU23B 用の、リポートファイル作成処理もいる。。。`gfncCreateTestReport4SPU23_txt @ CmnModule.vb`
    - EndForm.btnYes_Click
        CmnModule.gfncSaveTestReport
            gfncCreateTestReport4SPU23_txt

★ SPU23TrbTestForm にある処理の抜けをチェックすること！！！
- 


## VirtualBoxにおける開発
- 10で作成したアプリを単に実行させると` failed to initialize properly (0xc0000135). `で落ちる。
    - .NET Framework が入ってないということらしい。
        - XPには、.NET Framework 4.0.3 までインストール出来るらしい。



★故障要因リストのスペルミス
- U102: indiviudal
- U211: reegulator
- Lonworks <> LonWorks

変更点管理マトリクス表に、レポート作成処理の更新を追加する。


# 11/8
- [TSMSG_FINAL_FAIL]
    - A101, T101
    - S001

- [TSMSG_1ST]の、本来は、S001/S002/S003/S501/S502 以外はいらないはず。。。
    - だが、レポート作成処理(gfncCreateTestReport4SPU23_txt)で、ここから取得している(Fcode_L1)
        - レポート内の[GENERAL JUDGEMENT] -> Fault Code Contents のところ
    - また、ACCPで[DEMO]を使うと、glAdditionalTestF=Falseのまま、FaultListFormに行くので、 どうしても[TSMSG_1ST]からの参照になってしまう。
- というわけで、SPU23B の故障情報も、[TSMSG_1ST]と[TSMSG_FINAL_FAIL]に持っとかないといけない。
    - ただし、[TSMSG_FINAL_FAIL]に U001/U002/U003/U501/U502 はいらない。。。はず。


# 11/6
- gfncCreateTestReport4Mic_txt にある、prSavePtn = ReportSavePtn.Ptn4 時の `Save the Appearance Check`のところは、置き換えていいのか？
- gfncCreateTestReport4TCU_txt にある、prSavePtn = ReportSavePtn.Ptn4 時の `Save the Appearance Check`のところは、置き換えていいのか？
    - 同上 にある、`[ PATH PA-5 HVAC BTE - xxx(Use Golden Unit) TEST REPORT ]` は、置き換えていいのか？
- 同じく、gfncCreateTestReport4PWR03_txt にある、`[ PATH PA-5 HVAC BTE - R-PWR03C TEST REPORT ]`
- 同じく、gfncCreateTestReport4Inv/gfncCreateTestReport4Inv_txt にある、`[ PATH PA-5 HVAC BTE - xxx TEST REPORT ]`
- 同じく、gfncCreateTestReport4SCB01_txt にある、`[ PATH PA-5 HVAC BTE - M-SCB01 TEST REPORT ]`

- Confirm the test result preservation
    `preservation`: 保存


# 11/5
- 流用元の内部バージョン（アセンブリ/ファイルバージョン）は、1.0.0.43 になっている。
- なんか見た目が流用元と違うと思ったら、XP Visual styleを有効にしたなかった。

- Self Test 4/5 接続画面 右のボタンは、[CBLA Help1]になっている。[CBLA Help]のままでいい（変更なし）
    - TCU Test 画面でも同様
- ACCP/TCU NarrowDown の [Power Volatage]のグループボックスのタイトル`M-SPU23 Test`が変わってない。
    - ここでは、SPU23Bのための10秒間試験は行わず、現行の(SPU23A用)試験を行う。

- MainForm タイトルに試験名が入りきれない。
    - タイトル領域を長くしたら、`1/5`みたいのがずれてしまった。
- リポートファイル中の基板名も変更要！！！

- Label をフォームのセンターに表示したい
    - `Set Label's AutoSize property to False, TextAlign property to MiddleCenter and Dock property to Fill.`


# 11/4
- ACCP S/W Downloadツール
    - PATH-PTEと同じかと思ったら、若干ロジックが違う。
    - Show を、ShowDialog に置き換えたが、なぜか表示されない。
        - なので、Show はそのままで、処理を中断/終了させないようにするように変更ということにしたい。
            - 具体的には、フォームの[CotrolBox=False]、メインフォームの[FormClosing]でダウンロード中なら[e.Cancel=True]にする。


# 11/2
- VirtulaBox 10GBしか取ってなかったから容量不足となった。ふざけんな
    - しょうがないから、別ドライブにVSを入れなおし。
- VirtulaBox 解像度は、実マシン(1920x1080)より細かいのは設定できないっぽい。
    - フルスクリーンにしてから、(1280x1024)に設定できた。


# 10/30
- 仕様確認の回答がない。環境が構築できない。


# 10/29
- トラブルシューティング画面の電源ボタンの実装はあれでいいのか？
    - ボタン上の"ON""OFF"は、単にトグルしているだけ。x
- あと、Abortボタン押下げ時は、PowerOFFしているが、それ以外の時はしてない。いいのか？
    - subExitCard はやっている。


# 10/28
- STEPには処置という意味がある。
- STEP_ID - 処置の方法と画像が定義される - トラブルシューティングガイダンス (TrbForm2)で使用 - trbmes.ini[TSMSG2]で定義
    - 故障要因リスト画面(FaultListForm)で、処置行をクリックすると表示される。（具体的な処置と画像が表示される）
        - TrbForm2では、画像およびマニュアル参照ページが2個分表示できるようになっているが、１つか２つかはどこを見ればいいのか？
            - １つか２つかは、まだ分からない。MEE殿が用意する画像によってtrbmes.iniを編集する必要がある。
                - 外観検査(U501/U502)のやつは２つ 
    - 現在の実装(`subChgState @ TrbForm2`)では、画像がないと例外(FileNotFoundException)が発生する。
- STEP_ID 1~200         : Self Test?
- STEP_ID 201~          : ACCP/TCU Test
- STEP_ID 301~          : M-SPU23 Test
- STEP_ID 401~          : Inverter Test
- STEP_ID 501~          : SCB01 Test
- STEP_ID 600~701,702?  : PWR03 Test
- STEP_ID 801~          : PCB Test (今回 M-SPU23Bで使用する)
                        : 元々 901 ~ 905が定義してあった

- ★ ACCP の方にも、SPU23 test がある。HELPが若干異なる。                        


# 10/27
- リポートファイルフォーマットが分からないが、とりあえず作ってみた。



# 10/26
- trbmes.iniの故障情報は、[TSMSG_1ST]に置くか、[TSMSG_FINAL_FAIL]に置くか、両方に置くか？ リポートファイル作成処理で使用しているので要検討。
    - [TSMSG_FINAL_PASS]には置きたくない、というか置くとすれば、トラブルシューティングテストでPassになる`U104`だけ。
        - [TSMSG_FINAL_PASS]のを使うなら、`glAddTestResultPassed = True`にしてやらないといけない。

- `glAdditionalTestF = True` で、[TSMSG_FINAL_FAIL]から故障情報を取ってくる。
@ FaultListForm.vb
```vb
    Public Sub subSetFCode()
        ・・・
        sSecName = "TSMSG_1ST"
        If glAdditionalTestF Then
            If glAddTestResultPassed Then
                sSecName = "TSMSG_FINAL_PASS"
            Else
                sSecName = "TSMSG_FINAL_FAIL"
                'Narrow Down Test Fault 2009-10-23 T.Komine
                If glNarrowTestFltCode > 0 Then
                    FCode = FCode & glNarrowTestFltCode.ToString
                End If
            End If
        ・・・
```
- `glAdditionalTestF = True`は、自動試験画面でNextボタン押下げ時に行っている
@ PCBTestForm.vb
```vb
    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click

        If glTarget = TestTarget.HvacSPU23 Then
            If RSLT_FAIL.Equals(lblResult.Text) Then
                glDispChgNo = DispChgNo.PCBTest_Failed

                'S501, S502 are not final fault code 2010-01-25 T.Komine
                'S001 is not change trouble shooting screen 2010-02-05 T.Komine
                If glstrTestFltCode.Equals("S501") OrElse glstrTestFltCode.Equals("S502") _
                OrElse glstrTestFltCode.Equals("S001") Then
                    '@@@ 何もしない
                Else
                    'Added flag Narrow down test T.Komine 2009-11-30
                    glAdditionalTestF = True
                End If

            Else
                glDispChgNo = DispChgNo.PCBTest_Passed
            End If
            ・・・
        End If

        bRet = gfncDispChg(glDispChgNo)

    End Sub
```
- `glAddTestResultPassed`は、subSetFCode() @ FaultListForm.vb でしか使用(IF文で)してない。(INIファイルのセクション変える`TSMSG_FINAL_FAIL/TSMSG_FINAL_PASS`)
    - このフラグは、[Check]ボタンで一旦`Fail`になると、False になるので、その後で`Pass`になっても True には戻らない。
        - 結局、同じ結果にもかかわらず、INIファイルから取ってくるメッセージのセクションが変わるということになる。
```vb
     Public glAddTestResultPassed As Boolean 'True: Additional Test results "Passed"
```



# 10/23
- 自動試験のDEMO版はどうする？

`subSetFCode @ FaultListForm.vb`
    ```vb
        glKindAddTest = GetPrivateProfileInt("TSMSG_1ST", FCode & "_ADDTESTKIND", "0", `trbmes.ini`)
    ```
- glKindAddTest だが、
    - trbms.ini で値として使用しているのは、以下の`Test_M_SCB_SPU = 13`のみ
    ```vb
        Public Enum AddTestCode
            Test_TCU = 1              'TCU AddTest
            Test_M_SPU23 = 11         'PCB(M-SPU23) AddTest
            Test_M_SCB01 = 12         'PCB(M-SCB01) AddTest
            Test_M_SCB_SPU = 13       'PCB(M-SCB01,M-SPU23) AddTest
        End Enum
    ```
- なので、`fncChgState @ ConnectForm` にある以下のようなのは、対応しなくてもいい？
```vb
    ElseIf glKindAddTest = AddTestCode.Test_M_SPU23 Then                'PCB(M-SPU23) AddTest
        ・・・
```
 - 自動試験の右下に出る`Result of xxx Test`は、`ACCP/TCU Narrow Down`はそのままでいいのか？
    - 遷移図 P.53～ 終了画面がないので判断できない。





# 10/22
- mglpassNextItem : 成功時の次テスト（1:Final Step, 2~:Next Step 31~:SubTest, 700~:判明した故障コード)
- My.MyProject.MyForms

- SPU23BTest_Next と SPU23BTest_Abort　では、Hide()しているが、Close()でもいいのではないか？
    - ヘルプや故障リストのように戻らないので。

- 以下のどれを変えるか要検討
```vb
    Public glTarget As Short(TestTarget)    'Selected Target (0:Not Selected, 1:HVAC CONTROLLER, 2:HVAC INVERTER)
    Public glTestName As String             'Selected Test Name (to display)
    Public glTestType As Integer(TestType)  'SelfTest/ControllerTest/InverterTest
    Public glDispChgNo As Integer           'Test Sequence No
```
TestTarget.HvacSPU23: 25行
TestType.SPU23Test: 　65行
NAME_SPU23TEST:       10行

- リポートファイル出力 : glTestType





# 10/21
- 小数の誤差の問題はどうする？
- 以下の２つはやっていることはほぼ同じ
```vb
    gfncDispChg()
        Case DispChgNo.SPU23Test_Next
            MainForm.lblMicTestTime.Text = ""
        Case DispChgNo.SPU23Test_Abort
```
- この辺も追加せんと駄目っぽい...
        SPU23Test_Next      '-> BreakerForm [20]
        SPU23Test_FList     '-> FaultListForm [5]
        SPU23Test_Help      '-> HelpForm
        SPU23Test_Abort     '-> BreakerForm [20]
- FoultListForm からの[Back]のための
        FList_M212Back　とかも必要なようだ・・・
- HelpForm からの[Close]のための
        Help_Close07　とかも必要なようだ・・・
- PCBTest_Failed も　別に定義せんといかんようだ・・・
    - PCBTest_Failed は、自動試験に絡むので保留・・・



# 10/19
- 通常試験と、C44/C17試験は別々のクラスで処理したい(Formでまとめて処理しない)
    - 実装は、とりあえずUserControlの予定。TabControlが使えるかも。FormOnFormはやめた方がいい？


# 10/16
- 入力部試験とC32/C7両端部試験の、条件のどちらがPassでどちらがFailか分からない。
    - D12 (K) - Q4 (D)間 - 10V未満:Pass(以降下の方がPass)、10V以上:Fail
    - C32/C7両端部試験 - 1V未満:Pass、1V以上:Fail



# 10/15
- SPU23TrbTestForm.fncChgState()
    - fncGetSPU23TestCheckDataFromINI()
    - fncGetSPU23TrbShootCheckDataFromINI()
- ジャグ配列
```vb
    stage1-
        - test1
    stage2
        - test1
        - test2
    stage3
        - test1
        - test2
        - test3
```

- VS2005 には、型推論がないので、Option Infer が使えない。


# 10/14
- vbでの配列宣言の基本形。良く忘れる。
- vbでは宣言時に数を指定する。
```vb
    Public Results() As PassFail = New PassFail() {}
```
- c#ではインスタンス作成時に数を指定する。
```cs
    public PassFail[] Results = New PassFail[3];
```
- 15:15~16:30 - 変更点管理マトリクス表 DR



# 10/13
- リポートファイルのパスはどうなる？ `TCU\M-SPU23`
    - リポートファイルは、INIファイルで 0:CSV,1:TEXTを指定出来るが、SPU23はTEXTのみ
    - フォーマットは、SPU23Aと同じでいいのか？
    - 型番は？ (SPU23Aは`KSB472H17`)

- SPU23 は、fncDC5V24VRelayTest しかやらない。
- SCB01 は、fncDC375VRelayTest, fncDC24VRelayTest, fncSigRelayTest　をやる。
- 上記のテストは、[PCBTEST_EXEPTN] のIDXx に対応　(IDX1:fncDC5V24VRelayTest etc.)

- glKindAddTest とは？
    - セットしているのは、subSetFCode() @ FaultListForm.vb の以下の箇所のみ
    ```vb
        glKindAddTest = GetPrivateProfileInt("TSMSG_1ST", FCode & "_ADDTESTKIND", "0", sTsFile)
    ```
    - `_ADDTESTKIND`は、SDDによると、`故障コードxxxx 詳細試験種別` となっている。
    - 取りうる値は、
    ```vb
        Public Enum AddTestCode
            Test_TCU = 1              'TCU AddTest
            Test_M_SPU23 = 11         'PCB(M-SPU23) AddTest
            Test_M_SCB01 = 12         'PCB(M-SCB01) AddTest
            Test_M_SCB_SPU = 13       'PCB(M-SCB01,M-SPU23) AddTest
        End Enum
    ```
    - 以下のような判定文が結構あるが、SPU23A/B共用でいいのか？
    ```vb
        If glKindAddTest = AddTestCode.Test_M_SPU23 Then    
    ```


- リポート保存画面から、故障要因画面への遷移
    - 各試験画面では、`glstrTestFltCode`に故障コードがセットされる。
```vb
    EndForm.btnNext_Click()
        Select Case stateNo
            Case EndFormDispNo.No_02        'from MicTestForm2 (when test is failed)
                glDispChgNo = DispChgNo.End_MtoTest
            Case EndFormDispNo.No_03        'from MicTestForm3
                glDispChgNo = DispChgNo.End_MNext
            Case EndFormDispNo.No_05        'from InvTestForm3 (when test is failed)
                glDispChgNo = DispChgNo.End_VtoTest
            Case EndFormDispNo.No_06        'from InvTestForm2
                glDispChgNo = DispChgNo.End_VNext
        End Select
        bRet = gfncDispChg(glDispChgNo)

    CmnModule.gfncDispChg()
        Case DispChgNo.End_MNext       ' -> FaultListForm [4] (after Additional Test)
            ・・・
            FaultListForm.FaultCode = glstrTestFltCode
            FaultListForm.subSetFCode() ' FaultCode　に従って、メッセージをINIファイルから読み込んで故障リスト画面にセットする
            FaultListForm.DispStateNo = FltListDispNo.No_04
            FaultListForm.subChgState()
            FaultListForm.Show()
            If (EndForm IsNot Nothing) Or (EndForm.IsDisposed = False) Then
                EndForm.Dispose()
            End If
```



# 10/12
- TrbForm1 : Self 試験で使用？
- TrbForm2 : Trouble Shooting Guidance ダイアログになる。
- TrbForm3 : 未使用？
- FaultListForm : 故障要因リスト画面

- SUD: 操作説明書

- 変更点NO.13は、PATHBTE.ini の`Output Power Voltage Test`あたりを変更する。
    - 使っているのは、InvPCBTestForm1.vb




# 10/9
- HELP No.は付け方の決まりがあるのか？ SPU23Aは以下のようになっている。
- 外観検査 (OutlineForm) glHelpDispNo = `AppearanceSPU23_btn1`=59
    - 51 ～ (現在70まで使用済)　-> SPU23A:Help1=59、Help2=60
- 接続指示 (ConnectForm) glHelpDispNo = `ConnToHelp_SPU23_1`=164
    - 150 ～ (現在176まで(182,185,186も)使用済)　-> SPU23A:Help1=164、Help2=165
- トラブルシューティング (SPU23TrbTestForm) - glHelpDispNo = `TEST1_ITEM1_HELP=201` @ PPCBTrbShoot.ini
    - 201 ～ (SPU23A: 201～269)　(R-PWR03: 301～343)
- 具体的な処置
    - Message.ini に、外観検査用(71/72？)、接続指示用(177/178？)、トラブルシューティング用(401～？)のHELP定義を追加
    - PPCBTrbShoot.ini に、記述することになるがまだ未定。。。
    - OutlineForm
```vb
        Private Function fncGetHelpIndex(ByVal btn As Button) As Integer
            Select Case glTestName
                Case NAME_SPU23BTEST '@@@ "M-SPU23B Test"
                    If btn.Equals(Me.btnHelp1) Then
                        fncGetHelpIndex = HelpDispNo.AppearanceSPU23B_btn1 '@@@ Enum HelpDispNo に定義追加
                    ElseIf btn.Equals(Me.btnHelp2) Then
                        fncGetHelpIndex = HelpDispNo.AppearanceSPU23B_btn2 '@@@ Enum HelpDispNo に定義追加
                    End If
```
    - ConnectForm
```vb
        Private Sub btnHelp1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp1.Click
            Select Case glTestName
                Case NAME_SPU23TEST
                    glHelpDispNo = HelpDispNo.ConnToHelp_SPU23B_1 '@@@ Enum HelpDispNo に定義追加


        Private Sub btnHelp2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHelp2.Click
            Select Case glTestName
                Case NAME_SPU23TEST
                    glHelpDispNo = HelpDispNo.ConnToHelp_SPU23B_2 '@@@ Enum HelpDispNo に定義追加
```
    - SPU23TrbTestForm
        - [★ 未定・・・]


- 故障要因
    - trbmes.ini に、[TSIDX_SPU23]、[TSMSG_1ST]、[TSMSG_FINAL_PASS]
        - [TSMSG1]、[TSMSG1-1]、[TSMSG1-2]、[TSMSG1-3]、[TSMSG1-4]　この辺はよくわからない・・・
        - [TSMSG2]
            STEP_IDxxx_STEP = "Replace caution lamp, WL of Power Supply Unit"
            STEP_ID1_PIC1 = "jpg\PSU_WL.jpg"


- 画面遷移 P.119 `Result of M-SCP47 Test` となっている・・・`Result of M-SCT23 Test`の間違いと思われ。

- PCBTrbShoot.ini の[M_SPU23TRBTEST]は、SPU23Bでも同じように使えるのか？
    - 修正しないと多分使えない。



# 10/8
- ~10:30 - Office365インストール

- HELP は、`Message.ini`、故障要因画面は、`trbmes.ini`
- メインメニュー画面のボタン表記変更が変更点一覧にはない。いいのか？
- 画面の変更点で、機器名以外の修正もあるが、変更点一覧にはない。いいのか？
     - 例えばACCP試験-接続指示画面のボタン表記、Test cables CBLA2 Help ⇒ Test cables CBLA Help 2 とか、自動試験の`Aborted`の表示とか。
     - と思ったら、接続指示画面のは変更点一覧 No.15 にあった。。。

- `Calibration History`ボタンは非表示になっているが、校正画面は無いのか？



# 10/7
- 画面遷移(KS-3209-04A)の画面は、すべて`Step 0`となっているが。。。
- 画面遷移(試験遷移)をデータ化するのが難しい。。。
- そもそも、INIファイルを使う意味は何なのか？



# 10/6
- 8.1.1. 8.1.2. 入力箇所は一つなのに`Input the measured values.`と複数形になっているがいいのか？
    - 逆のパターンもある、8.1.8. は、２つなのに`value.`となっている。
- また、 8.1.1. とかチェックボックスがないのに`put a check in the checkbox`という表示はいいのか？
- SPU23A-故障要因特定の`P/F`時の1回目のテストで2項目ともPASS(つまり2項目とも条件に合わない)の場合の、故障コードがない。
    - アプリを実行して確認すると、`S002 - P24 output fault` となる。⇒ これは、つまり24V出力のエラー（自動試験の結果そのまま)
- 8.1.4. 入力部回路試験 Step 4では、判定結果がどちら(3KΩ以上/3KΩ未満)であっても故障要因が確定するが、判定はどちらが`Pass`で、どちらが`Fail`なのか？どちらも`Fail`？


- .Net には、eval() がない。(DataTable.Computeは使えそうだが)
    - ので、`fncJdgData @ SPU23BTrbTestForm` を使わざるを得ない。。。が private なので Shared にしたい。

 



# 10/5
- kick off : 10:00 ~ 11:30

- `自動試験` (出力電圧確認試験: 入力電源電圧23V ~ 42.5Vに対して出力電圧が正常な範囲にあることを確認する。)
    -                       5V試験    10V試験
    1. 故障無し             Pass       Pass
    2. 故障解析パターン１    Fail       Pass
    3. 故障解析パターン２    Pass       Fail
    4. 故障解析パターン３    Fail       Fail

- とりあえず、SPU23B 用に、新フォームを作成する方向で。`SPU23BTrbTestForm`





# 10/2
- `自動試験` : PCBTestForm.vb : `Shown` ⇒ `subPCBTest` ⇒ `fncDC5V24VRelayTest` 
    - `電圧測定 (5V/24V)` : CntrolModule.vb : `gfncPCBTest_DC5V24VRelay`
 - PCBTestForm.vb : `btnNext_Click`
    - `Failed`? gfncDispChg(DispChgNo.PCBTest_Failed)
    - `Passed`? gfncDispChg(DispChgNo.PCBTest_Passed)
```vb
    Function gfncDispChg(ptrDispNo)
        ・・・
        Case DispChgNo.PCBTest_Failed       '-> SPU23TestForm
            SPU23TrbTestForm.Show()
            PCBTestForm.Hide()
        ・・・
```

```vb
    Function fncSetPCBTestExecPtn()
        ・・・
    End Function

    ' DC5V/DC24V Relay Test
    Function fncDC5V24VRelayTest()

        For i = 0 To 2　{at 23.0Vdc, at 42.5Vdc, at 37.5Vdc}
            ' 23.0Vdc から 37.5Vdc まで順番に、5Vと24Vの電圧を測定する。
            ' AOに出力してDMMの値を取得する？ それなりに時間がかかると思われ(3秒ぐらい？)
            gfncPCBTest_DC5V24VRelay(dGetData, i)
            ・・・
            ' 電圧が 24V ±５％に収まっているかどうかのチェック
            ' glPCBChkPte24V は、PATHBTE.INI の [CRITERIA_PCBTEST] から
            If (dGetData(1) >= (dChkData(1) * ((100 - glPCBChkPte24V(i).Range) / 100))) _
                AndAlso (dGetData(1) <= (dChkData(1) * ((100 + glPCBChkPte24V(i).Range) / 100))) Then
                ListView4.Items(1).SubItems(i + 2).ForeColor = Color.FromName(COLOR_VALUE_OK)
            Else
                ListView4.Items(1).SubItems(i + 2).ForeColor = Color.FromName(COLOR_VALUE_NG)
                isErrF(1) = True
            End If
        Next
```
- 「10秒間24V±5%範囲内であるかを監視し、範囲外とならなければ”Pass”、1 度でも範囲外となった場合は”Fail”と判定する事」とあるが、
- `gfncPCBTest_DC5V24VRelay`では、5V&24Vを一緒に測定していて何秒かかかるのだが、この関数内で10秒間DMMの値を読み込むということか？

- Conduct detaild test (詳細試験を行ってください)




# 10/1

- トラブルシューティング画面、というより故障要因画面 - FaultListForm
    - CHG-KS3209-03_PATH_E-BTE_故障要因リスト

- SelfTestForm に２つコンボボックスを追加　(試験名、故障コード)
    - lblResult が `FAILED` にして、`Show Falut List`ボタンを表示させる。
    - SelectIndexChanged イベントで、glsXXXX に選択された故障コードをセットする。
    - `Show Falut List`ボタンで、トラブルシューティング画面に飛ぶ。

- トラブルシューティング画面では、Cause(要因)、STEP(対処)の2行が表示される。
    - STEP はリンクになっているので、クリックするとトラブルシューティングガイダンス画面(TrbForm2)が開く。
        - この画面には画像が張り付けられているので、そこの基板名等もチェックする必要がある。
        - ただし、電源ONのままだと、リンクが無効になっている可能性があるので、そのへんも対応する。


- 画面遷移(KS3029-04A)と、現バージョンのテスト画面と異なっているのでは？
    - 例えば、P50の`8. M-SCP47B / M-SCP47B-S1 Test (自動試験, 半自動試験)`
    - と思ったら、遷移図の方はタブコントロールの別タブで、[Abort Test]ボタンも[Reastart Test]の裏に隠れていた。


    - 画面遷移
        gfncDispChg(`DispChgNo`)


```vb
    Public glTarget As TestTarget        'Selected Target (0:Not Selected, 1:HVAC CONTROLLER, 2:HVAC INVERTER)
    Public glTestName As String     'Selected Test Name (to display)
    Public glTestType As TestType    'SelfTest/ControllerTest/InverterTest
    Public glDispChgNo As DispChgNo   'Test Sequence No  @@@ Screen Display Change No.

    Private Sub btnMspu23_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMspu23.Click
        glTestType = TestType.SPU23Test
        glTarget = TestTarget.HvacSPU23
        glTestName = NAME_SPU23TEST

        glDispChgNo = DispChgNo.Start_SPU23
        Dim bRet = gfncDispChg(glDispChgNo)
    End Sub
```

- ※ 故障要因は、Fault Cause List画面に表示されるだけだろうか？　ファイル等に記録したりしない？
- ※ 接続指示図リストは、チェックする必要あるのか？ 画面遷移のチェックで事足りるのでは？






# 9/30
- PATH 増車向け E-BTE S/W変更 作業開始

[主な変更点]
1. PATH増車向けで開発 (生産中止品対応)したACCP基板と非常換気インバータ基板の試験をE-BTE S/Wに追加する。
(PATH E-BTE S/W Versiion 1.3 → 1.4)




# 9/11
- 15:00 ~ 16:30 - E-BTEのDR2


# 9/4
- 10:15 ~ 12:00  - E-BTEのDR2




# 8/31
- 出荷DR
- 製品版(Ver.2.0) リリース
    - WibuKeyコードをR188のから元に戻した。



# 7/30
- ビルド後イベントで、リネームする
    ```cpp
        if "$(ConfigurationName)" == "MELCO" (
            rename "$(TargetPath)" "MELCO_PTEPROGRAM.exe"
        )
    ```
- これだと、既にファイルがある時にエラーになるので以下のようにする。
    ```cpp
        if "$(ConfigurationName)" == "MELCO" (
            move /y "$(TargetPath)" "$(TargetDir)MELCO_PTEPROGRAM.exe"
        )
    ```
- 検証版 Ver.1.4 リリース


# 7/29
- C# コードをコンパイルすると、ソースコードを一切書き換えていなくても、生成結果の exe/dll や pdb のバイナリが変化する。
    - [C# で、同じソースコードから常に同じバイナリを生成する](https://ufcpp.net/blog/2019/5/deterministicbuilds/)


# 7/27
- 13:00 ～ 14:15 S/W 完了DR
- 「Error WK1117-WIBUKEY.SYS is not installed」のエラーメッセージが出ます   
    - ＵＳＢプロテクトツールのサーバー・クライアント兼用のドライバーをインストールしてください。  
      インストール時に32ビットWkNet/WkLANネットワークサーバーという所のチェックを外すとクライアント用ですが、サーバー用をインストールしても問題なく動きます。
    - ドライバインストール時において、[Network Server]のチェックを外すと駄目らしい。。。


# 7/20
- Win10 英語 PC/WibuKeyドングル を返却


# 7/17
- 内部試験完了DR
- 検証版 Ver.1.3 リリース


# 7/15
- Forced Test
    - Pattern と Time　をセットしただけでは、試験開始（Pr.21=試験パタン、Pr.22=試験時間)しない。
    - `TEST START`を押さないといけない。これは`OFF`であっても同じ。(`OFF`もパターンの１つと見る)
    - とりあえず、試験終了

# 7/14
- ラボで実機試験 10~15
    - 基板(TCU/表示器)、電源、のシンプルな構成
    - ダウンロード試験も問題なく出来た。

- Self Test 中にアプリ終了できるが、完全に終了するのに時間かかる。
- Test で使っている`ErrTimer`は何のためにあるのか？


# 7/13
- 試験設計DR


# 7/10
- 試験数
    1.	インストール、その他 - 4
    2.	メイン画面 - 4 + 5 + 12 + 3 + 1  ⇒ 25
    3.	System Software version画面 - 5
    4.	Log画面 - 6 + 1 + 1  ⇒ 8
    5.	Test画面 - 5 + 8  ⇒ 13
    6.	Data Monitoring画面 - 11 + 2  ⇒ 13
    7.	Trend Data Monitoring画面 5
    8.	Software Download画面 12 + 8 + 8 + 5 + 5 + 1 + 1 + 13  ⇒ 53
    9.	Log Erasure画面 - 3
    10.	Administrative Other Functions画面 - 10 + 6 + 3  ⇒ 19
    11.	流用元不具合対応 - 5 + 5 + 1 + 1 + 2 + 2 + 2 + 1  ⇒ 19
    total - 156

- Trend画面、cycleが空でSEC/MIN切り替えをやると例外発生。
    ⇒ 対応した。
- frmMain_Loadで、`CreateDirectory("C:\PA5PTE\Data\HVAC")`とCドライブ固定で作成しているが問題ないか？

- ダウンロードでタイムアウトエラーになってリトライNOで再起動すると、`Are you sure …`は出ないで（OFFLINEモードにならない）ダウンロード画面になる。

>> 11 XON, 転送回数=[1506]



# 7/9
- MGDLL.dll のソースが見つからないが、シグネチャは合っているのか？
- As句がない箇所が多すぎる。
- frmParameterSet_Load の On Error は削除する。通信エラーの場合は、ポップアップ表示されるので必要ない。



# 7/8
- frmLog - `Compressor State #1/#2` の初期値が、`Full load/Un load`になっていた。

- 所内用の試験はどうする？
    ⇒ とりあえず、構成は別にして実行ファイル名は手動で修正する。

- 通信異常フォームが下にもぐる問題。メニューからの操作に対応してなかった。
- 水平展開への対応もまだ。




# 7/7
- frmSWDownload - ファイルの種類で`Full_Program`となっている。
    - `Full Program`にしないと、プログレスフォームで例外が発生する！

- 流用元がリトライが一回多い。



# 7/6
frmMain_Closing
    Call Rs232End() 
        DestroyTTYInfo(0)でエラー
°F
shift-jis

- 10:00 ~ 11:30 - 変更点マトリクス表のDR
- 15:00 ~ 17:00 - R211 アップロードのDR

- `System.InvalidOperationException: 'CreateHandle() の実行中は値 Dispose() を呼び出せません。`
    - これは、Form.OnLoad で、アプリを終了させると出る。
        - frmControlMenu.cmdVersion_Click
            - mdlMain.fVersion.Show()
                - frmSwVersion_Load
                    - frmCommErr.ShowDialog()
                        - Application.Exit()
    - 対策として、Load イベントではなく、 Shown イベントで処理させれば問題ない。
        - frmControlMenu.cmdVersion_Click
            - mdlMain.fVersion.Show()
            - frmSwVersion_Shown
                - frmCommErr.ShowDialog()
                    - Application.Exit()


# 7/3
- セットアッププロジェクトでのインストール先の設定
    - Application Folder の `DefaultLocation`プロパティを変更するがデフォルトは、
        [ProgramFilesFolder][Manufacturer]\[ProductName]
    これを、[ドライブ]\[ProductName]にしたいので
        [WindowsVolume]\[ProductName]
    とする。
- 今日、気づいたが、`HVAC System Setting`画面は仕様書から削除されているらしい。

- 現在、デバッグバージョンで、R188のWibuKeyコードを使っているが、インストーラはリリース時しかビルドしないようにしているので、インストールした奴では起動しない。
    - なので、一時的にデバッグバージョンでもインストーラを作成するようにしておく。（万が一元に戻すのを忘れても特に問題はない）
        - ・・・としていたが、品証でもR188用ので試験をするので、製品版をリリースする時に変えるようにした。

-  (ビルド)構成ごとに実行ファイル名を変えるにはどうしたらいいのか？
    - VC++だと、リンカー ⇒ 全般 ⇒ 出力ファイル で変えられるが、.NETだと変えられない。

- `Communication Error`フォームは、なぜモードレスで表示しているのか？機能フォームの下に隠れる場合もあるのだが。
    - あと、`OK`で再試行とあるが、実際はフォームを閉じているだげ。`EXIT`では`MdiParent.Close()`をやっている。

- バグ！！！
    - frmLogErasure, frmCommChange を開くときに通信エラーになると、例外が発生する。
        - mdlMain.fCommErr.MdiParent = Me <= こういうことをやっている。
        - 機能フォームは、当然`IsMdiContainer = False`なので例外が発生する。
    - 上のバグをつぶしても、通信エラーフォームが機能フォームの下にもぐってしまう。S/Wバージョン画面では問題ない。
        - S/Wバージョン画面では、`mdlMain.fCommErr.Focus()`これを機能画面.Show()の後にやっているから。
            - 正直、これをやるより、OnLoad でやっていることを、OnShown でやった方がいいと思われ。
        - 潜る画面
            - SW Version (メニューから起動した場合)
            - (Fault Log / Trend / Download 画面では、load時に通信しない)
            - (TEST / Data Monitoring 画面では、fCommErr ではなく MsgBox を使用)
            - operating hour
            - energy consumption
            - Log Erasure
            - parameter setting
            - memory read
            - setting changes
        - ★これは、アプリが落ちるわけではないのでここまで直す必要はないのでは？
        - というか、潜在バグが多すぎてフォローできない。
    - Forced TestのErrTimer　Close時にFalseにしてないので、タイミングによって落ちる。


# 7/2
- Wibu Key のドライバが入ってないと、`WibuKeyLib.Dll access error!`が出る。
- FirmCode/UserCodeが正しくないと、Wibukeyエラー`A suitable WibuBox entry was not found (17).`が出る。

- 相互運用機能アセンブリ（Interop Assembly）は、参照の追加でCOMコンポーネント一覧から、`WibuKey COM API`を選択すると自動的に作成される。
    - `obj\[Debug|Release]\Interop.WIBUKEYLib.dll` (なぜbinフォルダではないのか不明)
- ツールボックスにも追加できる。
    - ツールボックス右クリックでアイテムの選択でCOMコンポーネントタブから`Wibukey Class`を選択する。
    - `obj\[Debug|Release]\AxInterop.WIBUKEYLib.dll`が作成される。
    - ※ と思ったら、`New WibuKey`でエラーが出るようになった。
        - ツールボックスから削除しても駄目なのでドライバを入れ直した。
- ★ Interop.WIBUKEYLib.dll は置き換えなくてもいいかもしれない。そのままでも動くので。
    - ただし、実行フォルダにこれが必要。（COMコンポーネントの場合は、実行ファイルに埋め込み可能）
    - あと、`Wibukey.dll`(COMコンポーネント本体)が配布物に含まれてしまう。これは、WibuKeyドライバ`WkRuntime.exe (Ver.6.32)`を入れたら自動的に入るもの。
- ★★ 新しいのに置き換えたら、`Wibukey.dll`も含まれなくなったので、やはり新しいのに置き換えることにする。
        
- インストーラを作って実行すると、.NET Framework2.0を要求される。
    - どうも、セットアッププロジェクト自体が古いので作り直す必要があるようだ。
        - セットアッププロジェクトのタイトルが変。
        - セットアッププロジェクトで、Wibukey.dll が組み込まれるが必要なのか。（なくても動いているようだが）
        - セットアッププロジェクトのバージョンはどうする？




# 7/1
- frmProgressber版：123.11 sec
- frmProgressBar版：122.67 sec
- ダウンロードがスタートしたら、OK/NGにかかわらずアプリは必ず再起動される。

- Interop.WIBUKEYLib.dll は置き換えなくていいのか？

- 
    ｵﾍﾟﾚｰﾃｨﾝｸﾞｼｽﾃﾑ: Windows 10
    ｿｰｽﾊﾟｽ: C:\Users\QW69970\AppData\Local\Temp\WZSE1.TMP

    選択された言語:
    English
    日本語

    次のｺﾝﾎﾟｰﾈﾝﾄがｲﾝｽﾄｰﾙされます。:
    ﾜｲﾌﾞｷｰﾄﾞﾗｲﾊﾞｰﾌｧｲﾙ
    ﾜｲﾌﾞｷｰ COM ｺﾝﾄﾛｰﾙ
    WIBU-SYSTEMS (Win64/x64 variant) Shell Extension
- 



# 6/29
- コンパイルオプションの`Option Infer`は、Onにする。（型推論有効）
    - 本当にいいのか？要件等。。。
- フォームが重なったりスクロールバーが出たりするのを防ぐため、Dockプロパティを使おうかと思ったが、フォームの表示する順番によって下に潜ったりして面倒。(Menuが固定ならいいが、移動自由、ON/OFFも自由なので)
    - Menuを固定しようか（mdiではなく、通常のコントロールみたいにMainにAddControlする）と思ったが、あまり動作を変えるのはよくない。
        - なので、初期位置とサイズだけ調整することにする。
            - 機能フォームは、初期の位置は(182,0)、サイズは(846, 700)である。ここを調整する必要がある。初期位置 -> (190,0)
            - frmMain - Size = (1032, 773) -> (1056, 786)
    - `System S/W Version`画面のコントロールのアンカーがおかしいので調整する。

- frmProgressBar版：121.30 sec
- ダウンロード中に、ボタンが押せるのはおかしい。



# 6/26
- Win10 英語 PCを借りる`HP ProBook 650 G4 - 1920x1080 Text:125%`。WIBU Keyも借りたが、R188用。なのでアプリ内のFC/USを一時的にR188用に変えてデバッグする。
    - USB-Serial コネクタは `UC-SGT1` を使う。ドライバをインストールして接続できた。
    - Pass: melco
- Wind10 には、.NET Framework 3.5 (includes .NET 2.0 and 3.0)が、入ってない？
	- MELCO_PTEPROGRAM.exe を起動すると、エラーダイアログが表示される。
- MELCO用の`MELCO_PTEPROGRAM.exe`は作成するのか？
- `Parameter Settings` で表示するパラメータは、0～101で問題ないか。

- `COM1`固定。要望が出たらその時に修正する。
- S/W versionは`2.0`とのことだが、検証用のバージョンは何にするのか（元のバージョンは、1.2.3）
    - 1.3, 1.4 ・・・とする。


# 6/25
- `ダウンロード処理`
    - `BackGroundWorker`を使った方が、すっきりするかも。

# 6/24
- `メニューバー`
    - `Save Log` @ frmMain
        If Not GV_Ver < 0 Then
            41 01 00 12 00 02   パラメータRead(18) - Car Number ⇒ gstrSetParameter(18/19) ⇒ fControlMenu.txtMenuCarNo
            42 02   or  42 03   重故障 or 軽故障 履歴情報 - 
            (※ 上記処理が、fLog 非表示中に行われると 例外発生する。)
            (上記処理は、fLog != null 以下に移動させないといけない)

            fLog != null
                故障履歴 保存処理（frmLog でやっているのと同じ処理）
            fOperatingHour != null
                運転時間 保存処理
            fEnergyConsumption != null
                消費電力量 保存処理


    - `cmdSAVE_Click` @ frmLog
        If GV_Ver > 0 Then
            41 01 00 12 00 02   パラメータRead(18) - Car Number ⇒ gstrSetParameter(18/19) ⇒ fControlMenu.txtMenuCarNo
            42 02   or  42 03   重故障 or 軽故障 履歴情報 - 
            For i = 1 To 10
                PrintLine `(Car ID),HVAC,HVAC Controller,0001,06-24-2020,09:36:21,(故障コード),(故障名)、(42 02 or 42 03 で読み込んだ 履歴情報1、2、3、･･･)            
            Next

    - Wibu-key チェック
        - Administration の各処理の前にチェックを行っている。



# 6/23
- `Parameter Settings`
    - ParaDataAllRead()で、パラメータ読み込みサイズが`199`になっている。`200`にしなくていいのか？
        - TCU側がどう対応しているか知らないが、仕様書のコマンド説明が正しければ、バグということになる。
    - `Value`が`Error`になっているのは、TCUから読み出したパラメータ値が範囲外だったということ。
    - Pr.135 以上が、書き込みOKになっているが、大丈夫なのか？（S/WバージョンとかWIBU KEYとかだが？）
        - 画面に表示するのはPr.101までなので大丈夫のようだが…
    - 6/12 との関連だが、mstファイルで、`018,Car No(Upper),0,FF,AB,H,,1,1,1` のようになっていると、`DEFULT WRITE`で例外が発生する。

- `Setting Changes`
    - PC I/F の デバッグI/F(Pr.116 = 1) とは何か？
    - OnLoad()
        WIBU KEY CHECK
        41 02 00 88 00 00   パラメータWrite(136) - Wibu Key Serial Number <High-high>
        41 02 00 89 00 00   パラメータWrite(137) - Wibu Key Serial Number <High-low>
        41 02 00 8A 00 00   パラメータWrite(138) - Wibu Key Serial Number <Low-high>
        41 02 00 8B 00 00   パラメータWrite(139) - Wibu Key Serial Number <Low-low>
        50 10 00 00         運転時間 読み込み ⇒ 画面更新
        50 12 00 00         消費電力量 読み込み ⇒ 画面更新


# 6/22
- `Communication for Inverter`
    - OnLoad() で `GV_Ver <= 0` をオフラインと判断しているので、`GV_Ver = 0` でもオフラインとなり画面更新タイマが起動しない。
        - しかも、OnBack() では、`GV_Ver < 0` をオフラインと判断しているので、`GV_Ver = 0` ではモニタリング画面に戻れない･･･どころか`EXIT`ボタンしか効かない。
        - これは、バグとすべきなのか？
    - SDR/SD要求コマンドは、2バイトではなく、4バイトなので注意！ -> `50 06 00 00`

- `Fault Log Erasure`
    - Pr.110（故障リセット）=1、Pr.111（故障履歴リセット）=1 を行う。
- `Operating Hours Erasure`
    - Pr.123（Operationg Hour Reset）=1 を行う。
- `Energy Consumption Erasure`
    - Pr.124（Energy Consumption Reset）=1 を行う。


# 6/19
- `Self Test`
    - `RESULT DISPLAY`ボタンが非表示のままだが、使用していない？
        - 結局、結果リストが更新されるのは、テスト完了(46 05)受信時のみなのか？

    - テスト中、Pr.140 = 0 なら、`Stop`ボタンは有効にならない。


# 6/18
- `Forced Test`
    1. Test 時間を分単位で設定する。
    2. Pattern コンボボックスから選択する。
    3. TEST START ボタンを押す。(押さないでいると、4秒くらいでPattern＝OFFとなる)

- 強制試験中に他画面に遷移させてもいいのか？


# 6/17
- `Fault Log`画面で故障リストにスクロールバーが表示されるのは問題ないか？流用元は表示された？
    - 調整した方がいいと思う。
- `Fault Log`画面を開くと、必ず`UNSAVED`になるのは問題ないのか？（RbnMajor_CheckedChangedでセットされる）
    - SRSには、REFRESHボタン押下げ後に表示されるとあるが。



# 6/16
- オフラインかどうかを、`GV_Ver = -999` or `GV_Ver < 0` で判断している。
    - 6/22追記： 判断があいまい。`GV_Ver = 0`がオフラインと判断してる箇所(Communication for Inverter)もある。
- 故障履歴リストは、他の案件のように`Insert`ではなく、`Add`している。(つまり新しく追加したのが下になる)



# 6/15
- 流用元は、`\プログラム\4_ver1.2.3`でいいのか？（ソースの最終更新日は、`4/21`）
    - これは、`\プログラム\3_仕様変更_140421`にあるものと同じ？ 
        - mstの中身が違う（PR037~043）‎
            - 2014‎年‎11‎月‎6‎日、‏‎21:16:52
            - ‎2011‎年‎11‎月‎28‎日、‏‎12:51:20
        - あとは同じ。
    - なので、`\プログラム\4_ver1.2.3`でいいと思われる。
- ソリューションにセットアッププロジェクトも含まれている（フォルダが別だが）
- Ver.1.3 (2009)というのもあるが、これはVer.1.2のパラメータ違いみたいなので考えなくていいようだ。

- セットアップファイル名は、`Setup_PA5PTE.msi`のままでいいのか？

- frmMain(1457) で落ちる。
    - 1456-1486 の 2008-12-04 追加分は何のためにあるのか？


# 6/12
- パラメータ設定では、HEX値を入力できない。しかも、HEX値以外を入力して[Write]ボタン押下げも範囲チェックで例外発生（FFとかをInt変換してるため）
    - HEX値のパラメータは、mstファイルで書き込み不可にしているとはいえ、いびつな感じがする。


# 6/10
- ダウンロード時に、正確なサイズを通知していない（64 byteで丸めている）がいいのか？


# 6/9
> NET Framework 1.1以前ではFormClosingイベントが使えませんので、フォームのClosingイベントハンドラで、CancelEventArgs.CancelプロパティをTrueにします。

- On Error GoTo は、try catch にしたい。



# 6/8
- パラメータ読み込み
- `要求 (6 byte)`
    | DLE | STX | 0x41 | 0x01 | ﾊﾟﾗﾒｰﾀNoH | ﾊﾟﾗﾒｰﾀNoL | ﾃﾞｰﾀ数H | ﾃﾞｰﾀ数L | DLE | ETX | BCC |
- `応答 (4 + (n * 2) byte)`
    | DLE | STX | 0x41 | 0x00 | ﾊﾟﾗﾒｰﾀNoH | ﾊﾟﾗﾒｰﾀNoL | ﾃﾞｰﾀ1_H | ﾃﾞｰﾀ1_L | ﾃﾞｰﾀ2_H | ﾃﾞｰﾀ2_L |・・・| ﾃﾞｰﾀn_H | ﾃﾞｰﾀn_L | DLE | ETX | BCC |
- パラメータ書き込み
- `要求 (7 byte)`
    | DLE | STX | 0x41 | 0x02 | ﾊﾟﾗﾒｰﾀNoH | ﾊﾟﾗﾒｰﾀNoL | ﾃﾞｰﾀH | ﾃﾞｰﾀL | DLE | ETX | BCC |
- `応答 (7 byte)`
    | DLE | STX | 0x41 | 0x00 | ﾊﾟﾗﾒｰﾀNoH | ﾊﾟﾗﾒｰﾀNoL | ﾃﾞｰﾀH | ﾃﾞｰﾀL | DLE | ETX | BCC |

>> 57               - `W`
>> 07               - ブロック数
>> 00 00 80 00      - アドレス１
>> 00 01 00 00 
>> 00 01 80 00 
>> 00 01 F0 00 
>> 00 01 F4 00 
>> 00 01 F8 00 
>> 00 01 FC 00      - アドレス７

- 送受信データに0x3Fが混じるのはパリティエラーを起こしている。(ParityReplaceコード=0x3Fに置き換えられている)

frmMain_Load
    WIBU KEY Check
    シリアルポートOpen
    パラメータファイルRead ⇒ gstrParameter1～10, gstrSetParameter
    80 01               通信確立確認要求 - timeout ⇒ 「Are you sure that you have turned ON the power of theHVAC controller?」 
                                                     　Cancel ⇒ GV_Ver = -999, goto ShowFrm
    41 01 00 87 00 01   パラメータRead(135) - Software Version for HVAC ⇒ GV_Ver
    41 01 00 12 00 02   パラメータRead(18) - Car No
    41 02 00 88 00 00   パラメータWrite(136) - Wibu Key Serial Number <High-high>
    41 02 00 89 00 00   パラメータWrite(137) - Wibu Key Serial Number <High-low>
    41 02 00 8A 00 00   パラメータWrite(138) - Wibu Key Serial Number <Low-high>
    41 02 00 8B 00 00   パラメータWrite(139) - Wibu Key Serial Number <Low-low>
  ShowFrm:
    fControlMenu.Show()

frmControlMenu_Load
    41 01 00 12 00 02   パラメータRead(18) - Car No
    Display Car Number
    ダウンロード後の再起動なら、ダウンロード画面を開く




# 6/5
- 通常のシリアル通信(9600,E)には、MgDLLを使い、ダウンロード時(9600,N)は、MSCommを使う。
    - 切り替えは、Timer1_Tick @ frmDownChange.vb で行う。
- ポートは`COM1`固定
~~~vb
        'ダウンロードモード要求送信(Pr190 <- 2790(0xAE6))
        TextTrans(...)

        "Reset the power voltage or CPU"
        Yes or No

        ' Change Comm Interface
        Dim St2 As Short
        St2 = DestroyTTYInfo(0)
        Windows.Forms.Application.DoEvents()

        If mdlMain.fProgressBar Is Nothing Then
            mdlMain.fProgressBar = New frmProgressber
            mdlMain.fProgressBar.MdiParent = Me.MdiParent
        End If
        mdlMain.fDownChange.Close()
        mdlMain.fProgressBar.Show()
        Exit Sub
~~~
- ダウンロード処理は、Timer1_Tick @ frmProgressbar.vb で行う。
    - TCU 側のフラッシュ書き込み処理は、FLASH_WR.SRC で行っているようだ。

- 模擬ツール側でシリアル通信を間違うと、PTEで例外が発生する。。。怖い。



### End (Environment.Exit) を呼んでいる箇所

  frmDataMonitor.vb(1408):                    End
  frmDataMonitor.vb(2353):                End
  frmForcedTest.vb(1387):                    End
  frmForcedTest.vb(2210):                End
  frmSelfTest.vb(2091):                End

  frmHVACSet.vb(607):                End ⇒ フォーム未使用
  frmHVACSet.vb(685):                    End ⇒ フォーム未使用

  frmMain.vb(324):            End ⇒ Application.Exit に代替え可能
  frmParameterSet.vb(241):        End ⇒ Application.Exit に代替え可能
  frmProgressber.vb(168):        End ⇒ フォーム自体削除予定
  mdlMain.vb(331):        End ⇒ gfncParameterMasterFileRead:ErrorHandler -1を返すべき
  mdlMain.vb(401):        End ⇒ 削除



## 変更点 (64bitアプリとして作成する場合)
1. ビルド - ターゲットCPUを`x64`にする。
    - AxImp.exe" はコード -1163019603 を伴って終了しました。
    - C:\Windows\SysWOW64\MSComm32.Ocx
    - MSComm は、32bit版しかないので使えないのでは？？？ ⇒ SerialPort を使うしかない？
2. 64bit版DLLを用意する。
    - WIBUKEYLib.dll の64bit版を公式サイトからダウンロードする。
    - MgDllの64bit版`MGDLL64.dll`を用意する。
    - 64bit版のI/Fが変わっていれば対応する。
3. 水平展開（Environment.Exit(0) がクラッシュを引き起こす）対応
4. about ダイアログのバージョンと日付を更新する。

## 変更点 (32bitアプリとして作成する場合)
1. ターゲットフレームワークを`4.6.1`にする。
2. ビルド - ターゲットCPUを`x86`にする。
3. Win32のGetSystemMenu/RemoveMenuの引数のシグネチャを修正
4. フォーム同士が重なったり、スクロールバーが出たりしないように位置サイズを調整する。
5. ダウンロードプログレスフォームの置き換え
6. 水平展開（Environment.Exit(0) がクラッシュを引き起こす）対応
7. about ダイアログのバージョンと日付を更新する。

※ Crystal Report を使用している？
    - してないなら 参照から削除する。


## いろいろ
1. 仕様書が無い。
    -> User Manual が仕様書となる。
2. 起動時、なぜ全画面表示なのか？
    - 元のサイズに戻したとき、ウィンドウが重なったりしてスクロールバーが出たりする（OSによって微妙に違う）
        - 実際の使用環境(Win10(Eng))で表示させて、位置サイズ等を細かく調整しないといけない。
            - 面倒だしスマートでない。Dockプロパティを指定する方法のがいいのでは？(System S/W Version内のコントロールのAnchorの調整等が必要)
3. オフラインモード
    - 起動時通信タイムアウト ⇒　GV_Ver = -999　（これがオフラインフラグとなる。パラメータ(Pr.135)から読み込むと最大65535でマイナスにはならない）
    -　`GV_Ver=0`でもオフラインと判断したりしてあいまい。以下`GV_Ver=0`をオフラインと判断している箇所
    - `If GV_Ver > 0 Then`
        - frmCommInv_Load       (`GV_Ver=0`だと、`<<BACK`ボタンも効かず、アプリを終了するしかなくなる)
        - frmDataMonitor_Load   (同じメソッド内で、`If GV_Ver = -999`でも判断しているので、意図的にやっているのかどうかがよくわからない )
        - ErrTimer_Tick @ frmForcedTest
        - cmdSAVE_Click @ frmLog (`GV_Ver=0`だと、このIf文に到達せず、`There is no data`で終わる)
        - frmMain_Closing
        - frmMemoryRead_Load    そもそも、オフラインなのに`READ`ボタンが押せるのはおかしい。
            - txtAdrs_KeyDown       意味ない使い方
        - frmParameterSet_Load  (`GV_Ver=0`だと、`READ``WRITE`ボタンが押せない)
        - ErrTimer_Tick @ frmSelfTest
        - frmTrend_Load
            - saveTrenddata
        - gfncGetSaveFileName @ mdlMain
    - `GV_Ver=0`で、`Off Line`と表示される画面
        - Trend Data Monitoring
        - Parameter Setting
        - Memory Read
    - そもそも、S/Wバージョンとして`0.0`は有効か（あり得るのか）？
        - `0.0`は有り得ない値のようだ。
4. バグ（修正する必要あり）
    - `Fault Log`以外の画面で、メニューバーのFile->Save Log を選ぶと、例外発生。
        - `Fault Log`画面が作成されてない(Nothing)なのに、画面上のコントロールにアクセスしている(`mdlMain.fLog.RbnMajor.Checked`)
    - `Parameter Setting`画面で、パラメータ読み込みコマンドが`41 01 00 00 00 C7` (読み込みサイズが`199`）になっている。`200`にする必要がある。
        - しかし、製品版では、0~101 までしかリストに表示しない。
5. バグ？（修正した方がいいのでは？）
    - 画面で、表示しきれずにスクロールバーが出るところは、出ないようにした方がいい。
        ⇒ 修正する方向。
    - オフラインの判断。オフラインフラグを設けた方がいいと思うが、GV_Verを使うのであれば、`GV_Ver < 0`に統一すべき。
        ⇒ 修正しない。
    - ダウンロード中にメニューが選択できる、また、ダウンロードフォーム自体を右上の☒ボタンで閉じられる、ので修正すべき。
        ⇒ 修正する方向。
6. WibuKeyドライバ更新による、相互運用機能アセンブリ（Interop Assembly）の置き換え