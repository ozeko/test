﻿Imports System.ComponentModel
Imports System.IO

Namespace TroubleShooting

    Public Enum PassFail
        Unadministered
        Pass
        Fail
    End Enum

    ' judging expression
    Public Class EXP
        Public ReadOnly Name As String
        Public ReadOnly HelpNo As Integer
        Public ReadOnly Criterion As String '@@@ Pass になる条件？それともFailになる条件？
        Public ReadOnly OHM As Boolean

        Public Sub New(name As String, helpNo As Integer, criterion As String, unit As String)
            Me.Name = name
            Me.HelpNo = helpNo
            Me.Criterion = criterion
            Me.OHM = (String.Compare(unit, "ohm", True) = 0)
        End Sub
    End Class

    Public Class TSTest
        Public Name As String
        Public OnFail() As String
        Public OnPass As String
    End Class

    Public Class TSTestA
        Inherits TSTest
        Public Exp() As EXP
        Function IsAllResistance() As Boolean
            For Each e As EXP In Exp
                If Not e.OHM Then Return False
            Next
            Return True
        End Function
    End Class

    Public Class TSTestB
        Inherits TSTest
        Public HelpNo As Integer
    End Class

    Public Class TestSequence
        Implements INotifyPropertyChanged

        ' Declare the event
        Public Event PropertyChanged As PropertyChangedEventHandler Implements INotifyPropertyChanged.PropertyChanged

        ' This method is called by the Set accessor of each property.
        ' The CallerMemberName attribute that is applied to the optional propertyName
        ' parameter causes the property name of the caller to be substituted as an argument.
        Private Sub NotifyPropertyChanged(Optional ByVal propertyName As String = Nothing)
            RaiseEvent PropertyChanged(Me, New PropertyChangedEventArgs(propertyName))
        End Sub

        Private position As Integer
        Private test() As TSTest

        Public ReadOnly Property Count() As Integer
            Get
                Return test.Length
            End Get
        End Property

        Public ReadOnly Property Current() As TSTest
            Get
                Return IIf(position >= 0, test(position), Nothing)
            End Get
        End Property

        Public ReadOnly Property StepNo() As Integer
            Get
                Return position + 1
            End Get
        End Property

        Function LoadFromINI(section As String) As Boolean
            ' e.g. M_SPU23BTRBTEST_? -> M_SPU23BTRBTEST_U001
            If Strings.Right(section, 1) = "?" Then
                section = section.Replace("?", glstrTestFltCode)
            End If

            Dim iniPath As String = glAppHomePath & "\" & "hoge.ini"

            Dim count As Integer = GetProfileInt(section, "COUNT", 0, iniPath)
            If count = 0 Then Return False ' Cannot retrieve

            ReDim test(count - 1)
            For iTest As Integer = 0 To count - 1
                Dim prefkey As String = "TEST" & (iTest + 1).ToString
                Dim expcnt As Integer = GetProfileInt(section, prefkey & "_EXPCOUNT", 0, iniPath)
                If expcnt = 0 Then
                    Dim testB As TSTestB = New TSTestB
                    testB.Name = GetProfileString(section, prefkey & "_NAME", "", iniPath)
                    testB.HelpNo = GetProfileString(section, prefkey & "_HELP", "", iniPath)
                    ReDim testB.OnFail(3)
                    testB.OnFail(0) = GetProfileString(section, prefkey & "_ONFAIL_BELOW1V", "", iniPath)
                    testB.OnFail(1) = GetProfileString(section, prefkey & "_ONFAIL_20VORHIGHER", "", iniPath)
                    testB.OnFail(2) = GetProfileString(section, prefkey & "_ONFAIL_VARIES1V20V", "", iniPath)
                    testB.OnFail(3) = GetProfileString(section, prefkey & "_ONFAIL_VARIESOTHER", "", iniPath)
                    test(iTest) = testB
                Else
                    Dim testA As TSTestA = New TSTestA
                    ReDim testA.Exp(expcnt - 1)
                    ReDim testA.OnFail(expcnt - 1)
                    For iExp As Integer = 0 To expcnt - 1
                        Dim prefkeyEx As String = prefkey & "_EXP" & (iExp + 1).ToString
                        Dim name As String = GetProfileString(section, prefkeyEx & "_NAME", "", iniPath)
                        Dim help As Integer = GetProfileInt(section, prefkeyEx & "_HELP", -1, iniPath)
                        Dim criterion As String = GetProfileString(section, prefkeyEx & "_CRITERION", "", iniPath)
                        Dim unit As String = GetProfileString(section, prefkeyEx & "_UNIT", "", iniPath)
                        testA.Exp(iExp) = New EXP(name, help, criterion, unit)
                        testA.OnFail(iExp) = GetProfileString(section, prefkeyEx & "_ONFAIL", "", iniPath)
                    Next
                    test(iTest) = testA
                End If
                test(iTest).OnPass = GetProfileString(section, prefkey & "_ONPASS", "", iniPath)
            Next

            'position = 0
            'NotifyPropertyChanged("Current")
            position = -1
            Return True
        End Function

        Public Function MoveNext() As Boolean
            'Debug.Assert(position < test.Length)
            If position < test.Length - 1 Then
                position = position + 1
                NotifyPropertyChanged("Current")
                Return True
            Else
                Return False
            End If
        End Function

        Public Function IsFinalTest() As Boolean
            Return position = test.Length - 1
        End Function

    End Class

    Public Class TestResultDetail
        Public Name As String
        Public Criterion As String
        Public Value As String
        Public Passed As Boolean
        Public Sub New(name As String, criterion As String, value As String, passed As Boolean)
            Me.Name = name
            Me.Criterion = criterion
            Me.Value = value
            Me.Passed = passed
        End Sub
    End Class

    Public Class TestResultA
        Inherits TestResult

    End Class

    Public Class TestResultB
        Inherits TestResult

    End Class

    Public Class TestResult
        Public TestID As Integer
        Public Detail() As TestResultDetail
        Public Passed As Boolean
        Public Judgement As String

        Public Shared Function IsFaultCode(result As TestResult)
            Return System.Text.RegularExpressions.Regex.IsMatch(result.Judgement, "[A-Z][0-9]{3}")
        End Function
    End Class

    Module CmnModule
        ''' <summary>
        ''' Evaluate a specified expression
        ''' </summary>
        ''' <param name="exp">expression</param>
        ''' <returns>True:Pass, False:Fail</returns>
        Function Evaluate(ByVal exp As String) As Boolean
            exp = exp.Replace("(", "").Replace(")", "")
            Dim words() As String = exp.Split(New String() {" ", "　"}, StringSplitOptions.RemoveEmptyEntries)
            Dim q As Queue(Of String) = New Queue(Of String)(words)
            Dim bope As String = ""
            Dim result As Boolean = False
            While True
                Dim left As String = q.Dequeue
                Dim ope As String = q.Dequeue
Label1:
                Dim right As String = q.Dequeue
                If bope = "" Then
                    result = Sub1(left, ope, right)
                Else
                    result = Sub2(result, bope, Sub1(left, ope, right))
                End If
                If (q.Count = 0) Then Exit While

                ope = q.Dequeue()
                If "<>=".Contains(ope(0)) Then
                    bope = "and"
                    left = right
                    GoTo Label1
                End If

                bope = ope
            End While
            Return result
        End Function

        ''' <summary>
        ''' Evaluation function 1
        ''' </summary>
        Function Sub1(ByVal left As String, ByVal ope As String, ByVal right As String) As Boolean
            Dim v1, v2 As Double
            If Not Double.TryParse(left, v1) Then Throw New Exception()
            If Not Double.TryParse(right, v2) Then Throw New Exception()
            If (ope = "<") Then Return v1 < v2
            If (ope = ">") Then Return v1 > v2
            If (ope = ">=") Then Return v1 >= v2
            If (ope = "<=") Then Return v1 <= v2
            If (ope = "=") Then Return v1 = v2
            If (ope = "<>") Then Return v1 <> v2
            Throw New Exception()
        End Function

        ''' <summary>
        ''' Evaluation function 2
        ''' </summary>
        Function Sub2(ByVal left As Boolean, ByVal ope As String, ByVal right As Boolean) As Boolean
            If String.Compare(ope, "and", True) = 0 Then
                Return left AndAlso right
            End If
            If String.Compare(ope, "or", True) = 0 Then
                Return left OrElse right
            End If
            Throw New Exception()
        End Function


        ''' <summary>
        ''' Retrieves a string from INI file
        ''' </summary>
        Public Function GetProfileString(ByVal strAppName As String, ByVal strKeyName As String, ByVal strDefault As String, ByVal strFile As String) As String
            Try
                Dim strWork As System.Text.StringBuilder = New System.Text.StringBuilder(1024)
                Dim intRet As Integer = GetPrivateProfileString(strAppName, strKeyName, strDefault, strWork, strWork.Capacity - 1, strFile)
                Return strWork.ToString()
            Catch ex As Exception
                Return strDefault
            End Try
        End Function

        ''' <summary>
        ''' Retrieves an integer from INI file
        ''' </summary>
        Public Function GetProfileInt(ByVal strAppName As String, ByVal strKeyName As String, ByVal defVal As Integer, ByVal strFile As String) As Integer
            Try
                Return GetPrivateProfileInt(strAppName, strKeyName, defVal, strFile)
            Catch ex As Exception
                Return defVal
            End Try
        End Function

        ''' <summary>
        ''' Fault Factors in trbmes.ini
        ''' </summary>
        Private Class FaultDetail
            Structure LineMessage
                Public Message As String
                Public StepID As Integer
            End Structure
            Public Line() As LineMessage

            Public Sub New(ByVal faultCode As String, ByVal section As String)
                Dim iniPath As String = glAppHomePath & "\" & "trbmes.ini"
                Dim count As Integer = GetProfileInt(section, faultCode & "_LCNT", 0, iniPath)
                If count = 0 Then Return

                ReDim Line(count - 1)
                For i As Integer = 0 To count - 1
                    'Dim msg As String = GetProfileString("TSMSG_1ST", faultCode & "_L" & (i + 1).ToString, "", iniPath)
                    'Dim id As String = GetProfileInt("TSMSG_1ST", faultCode & "_L" & (i + 1).ToString & "_STEPID", 0, iniPath)
                    Dim msg As String = GetProfileString(section, faultCode & "_L" & (i + 1).ToString, "", iniPath)
                    Dim id As String = GetProfileInt(section, faultCode & "_L" & (i + 1).ToString & "_STEPID", 0, iniPath)
                    Line(i) = New LineMessage
                    With Line(i)
                        .Message = msg
                        .StepID = id
                    End With
                Next
            End Sub
        End Class

        ''' <summary>
        '''  Output M－SPU23 test report to a txt file
        ''' </summary>
        ''' <param name="prFileName">file path</param>
        ''' <param name="prSavePtn">save pattern</param>
        ''' <returns></returns>
        Public Function CreateTestReport4SPU23(ByVal prFileName As String, ByVal prSavePtn As Integer) As Boolean
            Dim i As Integer
            Dim dChkCurMin(4 - 1) As Double
            Dim dChkCurMax(4 - 1) As Double
            Dim dChkVolMin(4 - 1) As Double
            Dim dChkVolMax(4 - 1) As Double

            Using sw As StreamWriter = New StreamWriter(prFileName, append:=True)
                Dim detail As FaultDetail = New FaultDetail(glstrTestFltCode, "TSMSG_1ST")
                '-------------------------
                'saves (1)
                '-------------------------
                If (prSavePtn = ReportSavePtn.Ptn1) Or (prSavePtn = ReportSavePtn.Ptn2) Or _
                   (prSavePtn = ReportSavePtn.Ptn3) Or (prSavePtn = ReportSavePtn.Ptn4) Then
                    ' Go/NoGo and narrow flow print out
                    sw.WriteLine("[ PATH PA-5 HVAC BTE - {0} REPORT ]", glTestName)
                    sw.WriteLine("TEST REPORT: MEL {0} {1}-{2} <E-BTE software ver. {3}>]", _
                                       PARTNO_M_SPU23, InfoForm.txtSerialNo.Text, glDateTime, "2.00")
                    sw.WriteLine("TEST UNIT SERIAL NO." & vbTab & ": MEL {0} {1}", PARTNO_M_SPU23, InfoForm.txtSerialNo.Text)
                    sw.WriteLine("TEST DATE AND TIME" & vbTab & ": {0}", InfoForm.txtDateandTime.Text)
                    sw.WriteLine("TESTER" & vbTab & vbTab & vbTab & ": {0}", InfoForm.txtTestedBy.Text)
                    sw.WriteLine()
                    sw.WriteLine("[GENERAL JUDGEMENT]")
                    Dim strResult As String = PCBTestForm.lblResult.Text
                    sw.WriteLine(strResult)
                    If strResult = RSLT_FAIL Then
                        sw.WriteLine("Fault Code : {0}", glstrTestFltCode)
                        sw.WriteLine("Fault Code Contents : {0}", detail.Line(0).Message)
                    End If
                    sw.WriteLine()

                    ' Save the Appearance Check
                    Dim items As ListView.ListViewItemCollection = PCBTestForm.ListView5.Items
                    If items.Count > 0 Then
                        sw.WriteLine("< {0} >", PCBTestForm.GroupBox5.Text)
                        sw.WriteLine("Name" & vbTab & vbTab & vbTab & vbTab & "P/F")
                        sw.WriteLine("---------------------------------------------------------------------------------------------------")
                        For i = 0 To items.Count - 1
                            sw.WriteLine("{0, -28}" & vbTab & "{1}", items(i).SubItems(1).Text, items(i).SubItems(2).Text)
                        Next
                        sw.WriteLine()
                    End If

                    ' DC5V/24V Power Voltage Test
                    items = PCBTestForm.ListView4.Items
                    If items.Count > 0 Then
                        sw.WriteLine("< {0} >", PCBTestForm.GroupBox4.Text)
                        sw.WriteLine("Name" & vbTab & "Volt" & vbTab & vbTab & "Value" & vbTab & "Criterion" & vbTab & vbTab & "P/F")
                        sw.WriteLine("---------------------------------------------------------------------------------------------------")
                        For i = 0 To items.Count - 1
                            If i = 0 Then
                                gfncGetMaxMin(dChkVolMax(0), dChkVolMin(0), glPCBChkPte5V(0).ChkData, glPCBChkPte5V(0).Range, 0 - glPCBChkPte5V(0).Range)
                                gfncGetMaxMin(dChkVolMax(1), dChkVolMin(1), glPCBChkPte5V(1).ChkData, glPCBChkPte5V(1).Range, 0 - glPCBChkPte5V(1).Range)
                                gfncGetMaxMin(dChkVolMax(2), dChkVolMin(2), glPCBChkPte5V(2).ChkData, glPCBChkPte5V(2).Range, 0 - glPCBChkPte5V(2).Range)
                            Else
                                gfncGetMaxMin(dChkVolMax(0), dChkVolMin(0), glPCBChkPte24V(0).ChkData, glPCBChkPte24V(0).Range, 0 - glPCBChkPte24V(0).Range)
                                gfncGetMaxMin(dChkVolMax(1), dChkVolMin(1), glPCBChkPte24V(1).ChkData, glPCBChkPte24V(1).Range, 0 - glPCBChkPte24V(1).Range)
                                gfncGetMaxMin(dChkVolMax(2), dChkVolMin(2), glPCBChkPte24V(2).ChkData, glPCBChkPte24V(2).Range, 0 - glPCBChkPte24V(2).Range)
                            End If

                            sw.WriteLine("{0}" & vbTab & "at 23.0Vdc" & vbTab & "{1}" & vbTab & "({2}V - {3}V)" & vbTab & "{4}", _
                             items(i).SubItems(1).Text, items(i).SubItems(2).Text, dChkVolMin(0), dChkVolMax(0), items(i).SubItems(5).Text)
                            sw.WriteLine(vbTab & "at 42.5Vdc" & vbTab & "{0}" & vbTab & "({1}V - {2}V)", items(i).SubItems(3).Text, dChkVolMin(1), dChkVolMax(1))
                            sw.WriteLine(vbTab & "at 37.5Vdc" & vbTab & "{0}" & vbTab & "({1}V - {2}V)", items(i).SubItems(4).Text, dChkVolMin(2), dChkVolMax(2))
                            sw.WriteLine()
                        Next
                        sw.WriteLine()
                    End If

                    sw.WriteLine()
                    sw.WriteLine()

                    If prSavePtn = ReportSavePtn.Ptn1 Then
                        sw.WriteLine("-------------------------------------------<END OF FILE>-------------------------------------------")
                    End If
                End If

                '-------------------------
                'saves (2)
                '-------------------------
                If (prSavePtn = ReportSavePtn.Ptn2) Or (prSavePtn = ReportSavePtn.Ptn3) Then
                    sw.WriteLine()
                    sw.WriteLine()
                    sw.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
                    sw.WriteLine("[GO/NOGO TEST - FAULT CAUSES]")
                    sw.WriteLine()

                    sw.WriteLine("Fault Code : {0}", glstrTestFltCode)
                    If detail.Line.Length < 1 Then Exit Function

                    sw.WriteLine("Fault Code Contents : {0}", detail.Line(0).Message)
                    For i = 1 To detail.Line.Length - 1
                        If (i Mod 2) = 1 Then
                            sw.WriteLine(vbTab & detail.Line(i).Message)
                        Else
                            sw.WriteLine(vbTab & vbTab & "{0}" & vbTab & "<StepID : {1} >", detail.Line(i).Message, detail.Line(i).StepID)
                            sw.WriteLine(vbTab & vbTab & "[]")
                        End If
                    Next

                    sw.WriteLine()
                    sw.WriteLine()
                End If

                '-------------------------
                'saves (3)
                '-------------------------
                If (prSavePtn = ReportSavePtn.Ptn4) Then

                    detail = New FaultDetail(glstrTestFltCode, "TSMSG_FINAL_FAIL")

                    sw.WriteLine()
                    sw.WriteLine()
                    sw.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
                    sw.WriteLine()
                    sw.WriteLine("[TROUBLE SHOOTING TEST JUDGMENT RESULT]")
                    sw.WriteLine("Fault Code : {0}", glstrTestFltCode)
                    sw.WriteLine("Fault Code Contents : {0}", detail.Line(0).Message)
                    sw.WriteLine()
                    sw.WriteLine()

                    '-------------------------------------------------------------
                    'Saves the result of voltage , Resistance test (first Test)
                    '-------------------------------------------------------------
                    '@@@ トラブルシューティング部分
                    Dim results As List(Of TestResult) = TSForm.Results

                    For Each result As TestResult In results
                        sw.WriteLine("< Measure the Voltage or Resistance >")
                        sw.WriteLine("Name" & vbTab & vbTab & vbTab & "Value" & vbTab & "Criterion" & vbTab & vbTab & vbTab & vbTab & vbTab & vbTab & "P/F")
                        sw.WriteLine("---------------------------------------------------------------------------------------------------")
                        If TypeOf result Is TestResultB Then
                            '@@@ 保留・・・
                            sw.WriteLine("< M-SPU23B用の新しいトラブルシューティング試験 >")
                        Else
                            For Each item As TestResultDetail In result.Detail
                                sw.WriteLine("{0,-20}" & vbTab & "{1}" & vbTab & "{2,-50}" & vbTab & "{3}", item.Name, item.Value, item.Criterion, IIf(item.Passed, "Pass", "Fail"))
                            Next
                        End If
                        sw.WriteLine()
                    Next

                    '-------------------------
                    'saves (4)
                    '-------------------------
                    sw.WriteLine()
                    sw.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
                    sw.WriteLine()
                    sw.WriteLine("[FINAL FAULT CAUSES]")
                    sw.WriteLine()
                    sw.WriteLine("Fault Code : {0}", glstrTestFltCode)
                    If detail.Line.Length < 1 Then Exit Function

                    sw.WriteLine("Fault Code Contents : {0}", detail.Line(0).Message)
                    For i = 1 To detail.Line.Length - 1
                        If (i Mod 2) = 1 Then
                            sw.WriteLine(vbTab & detail.Line(i).Message.Replace(CR_MARK, vbCrLf & vbTab))
                        Else
                            sw.WriteLine(vbTab & vbTab & "{0}" & vbTab & "<StepID : {1} >", detail.Line(i).Message, detail.Line(i).StepID)
                            sw.WriteLine(vbTab & vbTab & "[]")
                        End If
                    Next
                    sw.WriteLine()
                    sw.WriteLine()
                    sw.WriteLine("-------------------------------------------<END OF FILE>-------------------------------------------")

                ElseIf (prSavePtn = ReportSavePtn.Ptn3) Then
                    '-------------------------
                    'saves (2) as (4)
                    '-------------------------
                    sw.WriteLine()
                    sw.WriteLine("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
                    sw.WriteLine()
                    sw.WriteLine("[FINAL FAULT CAUSES]")
                    sw.WriteLine()
                    sw.WriteLine("Fault Code : {0}", glstrTestFltCode)
                    If detail.Line.Length < 1 Then Exit Function

                    sw.WriteLine("Fault Code Contents : {0}", detail.Line(0).Message)
                    For i = 1 To detail.Line.Length - 1
                        sw.WriteLine(vbTab & detail.Line(i).Message.Replace(CR_MARK, vbCrLf & vbTab))
                        If (i Mod 2) = 0 Then
                            sw.WriteLine(vbTab & "[]")
                        End If
                    Next
                    sw.WriteLine()
                    sw.WriteLine()
                    sw.WriteLine("-------------------------------------------<END OF FILE>-------------------------------------------")
                End If
            End Using

            Return True
        End Function
    End Module

End Namespace
