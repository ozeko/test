﻿Imports System.Drawing
Imports System.Threading


Public Class PCBTestForm

    '*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*
    '  
    '   Executes Controller Test (Narrow Down Test)
    '
    '*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*---*

    Private mglAbortFlg As Boolean = False
    Private FailDEMOFlg As Boolean = False
    Private mglSPU23TestFlg As Boolean = True
    Private mglSCB01TestFlg As Boolean = True

    Private mglFltFormIdx As Integer = 0
    Private mglFltListViewIdx As Integer = 0
    Private mglFltListItmIdx As Integer = -1

    '----------------------------------------------------------------------------------
    '  Changes Switch Label colors, texts, Operation Messages, and Button visibility
    '
    '  2009.09.17 updated
    '----------------------------------------------------------------------------------
    Public Sub fncChgState()
        'Dim bRet As Boolean

        If glTarget = TestTarget.HvacSPU23 Then
            mglSCB01TestFlg = False
            GrpSCB01.Visible = False
            '@@@ mrk [ver1.4] >>
            GrpSPU23.Text = glTestName
            '@@@ mrk [ver1.4] <<

            '' add k.sakemi 2009/11/18
        ElseIf glTarget = TestTarget.HvacSCB01 Then
            mglSPU23TestFlg = False
            GrpSPU23.Visible = False
            '' add end
        End If

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '       Form_Load
    '
    '
    '   2009.04.20 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub PCBTestForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cnt As Short
        Dim ListViews = New ListView() {ListView1, ListView2, ListView3, ListView4, ListView5, ListView6}
        Dim lstvw As ListView
        Dim StrBuffer As New System.Text.StringBuilder
        Dim iRet As Integer

        Me.MdiParent = MainForm
        Me.Dock = DockStyle.Fill
        Me.DoubleBuffered = True

        ''ListView clear title blue you 2009-11-06 T.Komine
        For Each lstvw In ListViews
            lstvw.Clear()
        Next
        'displays Test execution time
        'StrBuffer.Capacity = 255
        'iRet = GetPrivateProfileString("TEST_TIME", "CONTEST_TIME", "", StrBuffer, _
        '                                StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
        'MainForm.lblMicTestTime.Text = StrBuffer.ToString.Trim

        'GroupBox forecolor
        StrBuffer.Remove(0, StrBuffer.Length)
        iRet = GetPrivateProfileString("GRPBOX_COLOR", "COLOR_GOTFOCUS", "DarkTurquoise", StrBuffer, _
                                        StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
        glGBGotFocusColorName = StrBuffer.ToString

        StrBuffer.Remove(0, StrBuffer.Length)
        iRet = GetPrivateProfileString("GRPBOX_COLOR", "COLOR_LOSTFOCUS", "Blue", StrBuffer, _
                                        StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
        glGBLostFocusColorName = StrBuffer.ToString


        Call InitializeListView()

        '' add k.sakemi 2009/10/22
        gfncMultiSetValChange(TestType.SPU23Test)
        '' add end

        'add TEST FLOW display 2010.02.05 
        MainForm.lblSPU4.Text = "Step 0"

        cnt = 1
        For Each lstvw In ListViews
            lstvw.Tag = cnt     'To get indexes of the ListViews
            'AddHandler lstvw.SelectedIndexChanged, AddressOf ListView1_SelectedIndexChanged
            'AddHandler lstvw.KeyPress, AddressOf ListView1_KeyPress             'shows Trb1 by Enter key
            'AddHandler lstvw.MouseClick, AddressOf ListView1_MouseClick         'shows Trb1 by mouse click
            AddHandler lstvw.ItemMouseHover, AddressOf ListView1_ItemMouseHover 'shows tooltips
            AddHandler lstvw.GotFocus, AddressOf ListView1_GotFocus             'changes groupbox title color
            AddHandler lstvw.LostFocus, AddressOf ListView1_LostFocus           'changes groupbox title color
            cnt = cnt + 1
        Next

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Initializes ListView
    '   2009.01.27 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub InitializeListView()

        Dim fontFamily As New FontFamily("Arial")
        'Dim font As New Font(fontFamily, 8.25, FontStyle.Bold, GraphicsUnit.Point)
        Dim font As New Font(fontFamily, 9, FontStyle.Bold, GraphicsUnit.Point)
        Dim count As Integer

        '--ListView1 -- [DC37.5V Relay Circuit Test]
        ListView1.Location = New Point(31, 23)
        ListView1.Size = New System.Drawing.Size(454, 80)
        ListView1.TabIndex = 0
        ListView1.View = System.Windows.Forms.View.Details
        ListView1.GridLines = True
        ListView1.Font = font
        ListView1.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView1.FullRowSelect = True
        ListView1.MultiSelect = False

        Dim columnHeader0 As New ColumnHeader
        With columnHeader0
            .Text = ""
            .Width = 0
        End With
        Dim columnHeader1 As New ColumnHeader
        With columnHeader1
            .Text = "Name"
            .TextAlign = HorizontalAlignment.Center
            .Width = 55
        End With
        Dim columnHeader2 As New ColumnHeader
        With columnHeader2
            .Text = "No"
            .TextAlign = HorizontalAlignment.Center
            .Width = 30
        End With
        Dim columnHeader3 As New ColumnHeader
        With columnHeader3
            .Text = "Value-1"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader4 As New ColumnHeader
        With columnHeader4
            .Text = "Value-2"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader5 As New ColumnHeader
        With columnHeader5
            .Text = "Value-3"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader6 As New ColumnHeader
        With columnHeader6
            .Text = "Value-4"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader7 As New ColumnHeader
        With columnHeader7
            .Text = "P/F"
            .TextAlign = HorizontalAlignment.Center
            .Width = 42
        End With
        ListView1.Columns.Add(columnHeader0)
        ListView1.Columns.Add(columnHeader1)
        ListView1.Columns.Add(columnHeader2)
        ListView1.Columns.Add(columnHeader3)
        ListView1.Columns.Add(columnHeader4)
        ListView1.Columns.Add(columnHeader5)
        ListView1.Columns.Add(columnHeader6)
        ListView1.Columns.Add(columnHeader7)

        Dim DC37Col1() As String = New String() {"", "", ""}
        Dim DC37Name() As String = New String() {"", "37.5V", ""}
        Dim DC37No() As String = New String() {"(1)", "(2)", "(3)"}
        Dim DC37Crnt1() As String = New String() {"", "", ""}
        Dim DC37Crnt2() As String = New String() {"", "", ""}
        Dim DC37Crnt3() As String = New String() {"", "", ""}
        Dim DC37Crnt4() As String = New String() {"", "", ""}
        Dim DC37Jdg() As String = New String() {"", "", ""}

        For count = 0 To DC37Name.Length - 1
            Dim listItem As New ListViewItem(DC37Col1(count))
            listItem.SubItems.Add(DC37Name(count))
            listItem.SubItems.Add(DC37No(count))
            listItem.SubItems.Add(DC37Crnt1(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(DC37Crnt2(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(DC37Crnt3(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(DC37Crnt4(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(DC37Jdg(count))
            ListView1.Items.Add(listItem)
            ListView1.Items(count).UseItemStyleForSubItems = False
            If "Pass".Equals(ListView1.Items(count).SubItems(ListView1.Items(count).SubItems.Count - 1).Text) Then
                ListView1.Items(count).SubItems(ListView1.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_OK)
            ElseIf "Fail".Equals(ListView1.Items(count).SubItems(ListView1.Items(count).SubItems.Count - 1).Text) Then
                ListView1.Items(count).SubItems(ListView1.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_NG)
            End If
        Next
        GroupBox1.Controls.Add(ListView1)

        '--ListView2 -- [DC24V Relay Circuit Test]
        ListView2.Location = New Point(31, 23)
        ListView2.Size = New System.Drawing.Size(274, 44)
        ListView2.TabIndex = 1
        ListView2.View = System.Windows.Forms.View.Details
        ListView2.GridLines = True
        ListView2.Font = font
        ListView2.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView2.FullRowSelect = True
        ListView2.MultiSelect = False

        Dim columnHeader10 As New ColumnHeader
        With columnHeader10
            .Text = ""
            .Width = 0
        End With
        Dim columnHeader11 As New ColumnHeader
        With columnHeader11
            .Text = "Name"
            .TextAlign = HorizontalAlignment.Center
            .Width = 55
        End With
        Dim columnHeader12 As New ColumnHeader
        With columnHeader12
            .Text = "Value-1"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader13 As New ColumnHeader
        With columnHeader13
            .Text = "Value-2"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader14 As New ColumnHeader
        With columnHeader14
            .Text = "P/F"
            .TextAlign = HorizontalAlignment.Center
            .Width = 42
        End With
        ListView2.Columns.Add(columnHeader10)
        ListView2.Columns.Add(columnHeader11)
        ListView2.Columns.Add(columnHeader12)
        ListView2.Columns.Add(columnHeader13)
        ListView2.Columns.Add(columnHeader14)

        Dim DC24Col1() As String = New String() {""}
        Dim DC24Name() As String = New String() {"24V"}
        Dim DC24Crnt1() As String = New String() {""}
        Dim DC24Crnt2() As String = New String() {""}
        Dim DC24Jdg() As String = New String() {""}

        For count = 0 To DC24Name.Length - 1
            Dim listItem As New ListViewItem(DC24Col1(count))
            listItem.SubItems.Add(DC24Name(count))
            listItem.SubItems.Add(DC24Crnt1(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(DC24Crnt2(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(DC24Jdg(count))
            ListView2.Items.Add(listItem)
            ListView2.Items(count).UseItemStyleForSubItems = False
            If "Pass".Equals(ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).Text) Then
                ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_OK)
            ElseIf "Fail".Equals(ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).Text) Then
                ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_NG)
            End If
        Next
        GroupBox2.Controls.Add(ListView2)

        '--ListView3 -- [Signal Relay Circuit Test]
        ListView3.Location = New Point(31, 23)
        ListView3.Size = New System.Drawing.Size(444, 314)
        ListView3.TabIndex = 2
        ListView3.View = System.Windows.Forms.View.Details
        ListView3.GridLines = True
        ListView3.Font = font
        ListView3.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView3.FullRowSelect = True
        ListView3.MultiSelect = False

        Dim columnHeader20 As New ColumnHeader
        With columnHeader20
            .Text = ""
            .Width = 0
        End With
        Dim columnHeader21 As New ColumnHeader
        With columnHeader21
            .Text = "Name"
            .TextAlign = HorizontalAlignment.Center
            .Width = 200
        End With
        Dim columnHeader22 As New ColumnHeader
        With columnHeader22
            .Text = "No"
            .TextAlign = HorizontalAlignment.Center
            .Width = 30
        End With
        Dim columnHeader23 As New ColumnHeader
        With columnHeader23
            .Text = "Value-1"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader24 As New ColumnHeader
        With columnHeader24
            .Text = "Value-2"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader25 As New ColumnHeader
        With columnHeader25
            .Text = "P/F"
            .TextAlign = HorizontalAlignment.Center
            .Width = 42
        End With
        ListView3.Columns.Add(columnHeader20)
        ListView3.Columns.Add(columnHeader21)
        ListView3.Columns.Add(columnHeader22)
        ListView3.Columns.Add(columnHeader23)
        ListView3.Columns.Add(columnHeader24)
        ListView3.Columns.Add(columnHeader25)

        Dim SGCol1() As String = New String() {"", "", "", "", "", "", "", "", "", "", _
                                               "", "", "", "", "", "", "", ""}
        Dim SGName() As String = New String() {"Inverter Transmission 1", "", "Inverter Transmission 2", "", "Inverter Transmission 3", "", "Fresh Air Temperature Sensor 1", "", _
                                               "Fresh Air Temperature Sensor 2", "", "Higher Pressure Sensor", "", "Lower Pressure Sensor", "", "Pressure Sensor Power Supply", "", "Lonworks Transmission", ""}
        Dim SGNo() As String = New String() {"(1)", "(2)", "(1)", "(2)", "(1)", "(2)", "(1)", "(2)", "(1)", "(2)", _
                                               "(1)", "(2)", "(1)", "(2)", "(1)", "(2)", "(1)", "(2)"}
        Dim SGCrnt1() As String = New String() {"", "", "", "", "", "", "", "", "", "", _
                                                "", "", "", "", "", "", "", ""}
        Dim SGCrnt2() As String = New String() {"", "", "", "", "", "", "", "", "", "", _
                                                "", "", "", "", "", "", "", ""}
        Dim SGJdg() As String = New String() {"", "", "", "", "", "", "", "", "", "", _
                                              "", "", "", "", "", "", "", ""}

        For count = 0 To SGName.Length - 1
            Dim listItem As New ListViewItem(SGCol1(count))
            listItem.SubItems.Add(SGName(count))
            listItem.SubItems.Add(SGNo(count))
            listItem.SubItems.Add(SGCrnt1(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(SGCrnt2(count)).ForeColor = Color.FromName(COLOR_VALUE_OK)
            listItem.SubItems.Add(SGJdg(count))
            ListView3.Items.Add(listItem)
            ListView3.Items(count).UseItemStyleForSubItems = False
            If "Pass".Equals(ListView3.Items(count).SubItems(ListView3.Items(count).SubItems.Count - 1).Text) Then
                ListView3.Items(count).SubItems(ListView3.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_OK)
            ElseIf "Fail".Equals(ListView3.Items(count).SubItems(ListView3.Items(count).SubItems.Count - 1).Text) Then
                ListView3.Items(count).SubItems(ListView3.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_NG)
            End If
        Next
        GroupBox3.Controls.Add(ListView3)

        '--ListView4 -- [DC5V/DC24V]
        ListView4.Location = New Point(31, 23)
        ListView4.Size = New System.Drawing.Size(346, 60)
        ListView4.TabIndex = 3
        ListView4.View = System.Windows.Forms.View.Details
        ListView4.GridLines = True
        ListView4.Font = font
        ListView4.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView4.FullRowSelect = True
        ListView4.MultiSelect = False

        Dim columnHeader30 As New ColumnHeader
        With columnHeader30
            .Text = ""
            .Width = 0
        End With
        Dim columnHeader31 As New ColumnHeader
        With columnHeader31
            .Text = "Name"
            .TextAlign = HorizontalAlignment.Center
            .Width = 55
        End With
        Dim columnHeader33 As New ColumnHeader
        With columnHeader33
            .Text = "at 23.0Vdc"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader34 As New ColumnHeader
        With columnHeader34
            .Text = "at 42.5Vdc"        '' "at 44.0Vdc" mod k.sakemi 2009/10/23
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader35 As New ColumnHeader
        With columnHeader35
            .Text = "at 37.5Vdc"
            .TextAlign = HorizontalAlignment.Center
            .Width = 80
        End With
        Dim columnHeader36 As New ColumnHeader
        With columnHeader36
            .Text = "P/F"
            .TextAlign = HorizontalAlignment.Center
            .Width = 42
        End With
        ListView4.Columns.Add(columnHeader30)
        ListView4.Columns.Add(columnHeader31)
        ListView4.Columns.Add(columnHeader33)
        ListView4.Columns.Add(columnHeader34)
        ListView4.Columns.Add(columnHeader35)
        ListView4.Columns.Add(columnHeader36)

        Dim SPU1Col1() As String = New String() {"", ""}
        Dim SPU1Name() As String = New String() {"5V", "24V"}
        Dim SPU1Data() As String = New String() {"", ""}
        Dim SPU2Data() As String = New String() {"", ""}
        Dim SPU3Data() As String = New String() {"", ""}
        Dim SPU1Jdg() As String = New String() {"", ""}

        For count = 0 To SPU1Name.Length - 1
            Dim listItem As New ListViewItem(SPU1Col1(count))
            listItem.SubItems.Add(SPU1Name(count))
            listItem.SubItems.Add(SPU1Data(count))
            listItem.SubItems.Add(SPU2Data(count))
            listItem.SubItems.Add(SPU3Data(count))
            listItem.SubItems.Add(SPU1Jdg(count))
            ListView4.Items.Add(listItem)
            ListView4.Items(count).UseItemStyleForSubItems = False
            If "Pass".Equals(ListView4.Items(count).SubItems(ListView4.Items(count).SubItems.Count - 1).Text) Then
                ListView4.Items(count).SubItems(ListView4.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_OK)
            ElseIf "Fail".Equals(ListView4.Items(count).SubItems(ListView4.Items(count).SubItems.Count - 1).Text) Then
                ListView4.Items(count).SubItems(ListView4.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_NG)
            End If
        Next
        GroupBox4.Controls.Add(ListView4)

        '--ListView5 -- [M-SPU23 Appearance Check]
        ListView5.Location = New Point(31, 23)
        ListView5.Size = New System.Drawing.Size(338, 62)
        ListView5.TabIndex = 0
        ListView5.View = System.Windows.Forms.View.Details
        ListView5.GridLines = True
        ListView5.Font = font
        ListView5.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView5.FullRowSelect = True
        ListView5.MultiSelect = False

        Dim ColumnHeader50 As New ColumnHeader
        With ColumnHeader50
            .Text = ""
            .Width = 0
        End With
        Dim ColumnHeader51 As New ColumnHeader
        With ColumnHeader51
            .Text = "Check Items"
            .TextAlign = HorizontalAlignment.Center
            .Width = 292
        End With
        Dim ColumnHeader52 As New ColumnHeader
        With ColumnHeader52
            .Text = "P/F"
            .TextAlign = HorizontalAlignment.Center
            .Width = 42
        End With
        ListView5.Columns.Add(ColumnHeader50)
        ListView5.Columns.Add(ColumnHeader51)
        ListView5.Columns.Add(ColumnHeader52)

        Dim PWRCol15() As String = New String() {"", ""}
        Dim PWRName5() As String = New String() {"Damages on copper pattern", "Damages on components"}
        Dim PWRJdg5() As String = New String() {"", ""}

        For count = 0 To PWRName5.Length - 1
            Dim listItem As New ListViewItem(PWRCol15(count))
            listItem.SubItems.Add(PWRName5(count))
            listItem.SubItems.Add(PWRJdg5(count))
            ListView5.Items.Add(listItem)
            ListView5.Items(count).UseItemStyleForSubItems = False
            'If "Pass".Equals(ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).Text) Then
            '    ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_OK)
            'ElseIf "Fail".Equals(ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).Text) Then
            '    ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_NG)
            'End If
        Next
        GroupBox5.Controls.Add(ListView5)

        '--ListView6 -- [M-SCB01 Appearance Check]
        ListView6.Location = New Point(31, 23)
        ListView6.Size = New System.Drawing.Size(338, 62)
        ListView6.TabIndex = 0
        ListView6.View = System.Windows.Forms.View.Details
        ListView6.GridLines = True
        ListView6.Font = font
        ListView6.HeaderStyle = ColumnHeaderStyle.Nonclickable
        ListView6.FullRowSelect = True
        ListView6.MultiSelect = False

        Dim ColumnHeader60 As New ColumnHeader
        With ColumnHeader60
            .Text = ""
            .Width = 0
        End With
        Dim ColumnHeader61 As New ColumnHeader
        With ColumnHeader61
            .Text = "Check Items"
            .TextAlign = HorizontalAlignment.Center
            .Width = 292
        End With
        Dim ColumnHeader62 As New ColumnHeader
        With ColumnHeader62
            .Text = "P/F"
            .TextAlign = HorizontalAlignment.Center
            .Width = 42
        End With
        ListView6.Columns.Add(ColumnHeader60)
        ListView6.Columns.Add(ColumnHeader61)
        ListView6.Columns.Add(ColumnHeader62)

        Dim PWRCol16() As String = New String() {"", ""}
        Dim PWRName6() As String = New String() {"Damages on copper pattern", "Damages on components"}
        Dim PWRJdg6() As String = New String() {"", ""}

        For count = 0 To PWRName6.Length - 1
            Dim listItem As New ListViewItem(PWRCol16(count))
            listItem.SubItems.Add(PWRName6(count))
            listItem.SubItems.Add(PWRJdg6(count))
            ListView6.Items.Add(listItem)
            ListView6.Items(count).UseItemStyleForSubItems = False
            'If "Pass".Equals(ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).Text) Then
            '    ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_OK)
            'ElseIf "Fail".Equals(ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).Text) Then
            '    ListView2.Items(count).SubItems(ListView2.Items(count).SubItems.Count - 1).BackColor = Color.FromName(COLOR_NG)
            'End If
        Next
        GroupBox6.Controls.Add(ListView6)

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Selects [Abort Test] Button
    '-----------------------------------------------------------------------------------------------------
    Private Sub btnAbort_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAbort.Click

        mglAbortFlg = True
        Application.DoEvents()

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Selects [Next>] Button
    '
    '   2008.12.18 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub btnNext_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNext.Click
        Dim bRet As Boolean

        MainForm.TestStatLbl.Text = ""

        glTestResult = lblResult.Text

        If glTarget = TestTarget.HvacSPU23 Then
            If RSLT_FAIL.Equals(lblResult.Text) Then
                glDispChgNo = DispChgNo.PCBTest_Failed

                'S501, S502 are not final fault code 2010-01-25 T.Komine
                'S001 is not change trouble shooting screen 2010-02-05 T.Komine
                '@@@ mrk [ver1.4] U501, U502 are not final fault code 
                If glstrTestFltCode.Equals("S501") OrElse glstrTestFltCode.Equals("S502") _
                OrElse glstrTestFltCode.Equals("U501") OrElse glstrTestFltCode.Equals("U502") _
                OrElse glstrTestFltCode.Equals("S001") Then
                Else
                    'Added flag Narrow down test T.Komine 2009-11-30
                    glAdditionalTestF = True
                End If
            Else
                glDispChgNo = DispChgNo.PCBTest_Passed
            End If

            '' add k.sakemi 2009/11/18
        ElseIf glTarget = TestTarget.HvacSCB01 Then
            If RSLT_FAIL.Equals(lblResult.Text) Then
                glDispChgNo = DispChgNo.SCB01Test_Failed
            Else
                glDispChgNo = DispChgNo.SCB01Test_Passed
            End If
            '' add end
        Else
            glDispChgNo = DispChgNo.PCBTest_Next
        End If

        bRet = gfncDispChg(glDispChgNo)

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Selects [Restart Test] Button
    '
    '   2009.04.03 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub btnRestart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRestart.Click

#If DEMO Then
        FailDEMOFlg = IIf(FailDEMOFlg, False, True)
#End If

        'button Enabled <- False 2009-11-20 T.Komine
        Dim btn As Button = DirectCast(sender, Button)
        btn.Enabled = False
        Me.btnNext.Enabled = False
        Me.btnFltList.Enabled = False

        '2010-01-16 Clear ChkTime T.Komine
        Me.pnlTransChkTime.Visible = False
        Application.DoEvents()

        Call subPCBTest()

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '       Shown Event
    '
    '   2009.04.20 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub PCBTestForm2_Shown(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Shown
        Dim StrBuffer As New System.Text.StringBuilder
        Dim iRet As Integer
        Dim sTmp() As String

        '----- 2020-10-13 add by nis [ver1.4] 手動試験実施用の故障コード選択欄表示　デモ -----
#If DEMO = True Then
        'for DEBUGGING Troubleshooting messages
        If GetPrivateProfileInt("DEMO", "SHOW_FAULT_CODE_LIST", 0, glAppHomePath & "\" & INIFILE) <> 0 Then

            'for DEBUGGING Troubleshooting messages
            cmbDemoFaultCode.Items.Clear()

            'displays Test execution time
            StrBuffer.Capacity = 255
            StrBuffer.Remove(0, StrBuffer.Length)
            Select Case glTarget
                Case TestTarget.HvacSPU23   'M-SPU23A
                    '@@@ mrk >>
                    If glTestName = NAME_SPU23BTEST Then
                        iRet = GetPrivateProfileString("DEMO", "FAULT_CODE_SPU_B_GONOGO", "", StrBuffer, StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
                        If String.IsNullOrEmpty(StrBuffer.ToString.Trim) = False Then
                            sTmp = StrBuffer.ToString.Split(",")
                            For iCnt As Integer = 0 To sTmp.Length - 1
                                cmbDemoFaultCode.Items.Add(sTmp(iCnt))
                            Next
                            cmbDemoFaultCode.SelectedIndex = 0
                        End If
                    Else
                        iRet = GetPrivateProfileString("DEMO", "FAULT_CODE_SPU_A_GONOGO", "", StrBuffer, StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
                        If String.IsNullOrEmpty(StrBuffer.ToString.Trim) = False Then
                            sTmp = StrBuffer.ToString.Split(",")
                            For iCnt As Integer = 0 To sTmp.Length - 1
                                cmbDemoFaultCode.Items.Add(sTmp(iCnt))
                            Next
                            cmbDemoFaultCode.SelectedIndex = 0
                        End If
                    End If
                    '@@@ mrk <<

                Case TestTarget.HvacSCB01   'M-SCB01
                    iRet = GetPrivateProfileString("DEMO", "FAULT_CODE_SCB_GONOGO", "", StrBuffer, StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
                    If String.IsNullOrEmpty(StrBuffer.ToString.Trim) = False Then
                        sTmp = StrBuffer.ToString.Split(",")
                        For iCnt As Integer = 0 To sTmp.Length - 1
                            cmbDemoFaultCode.Items.Add(sTmp(iCnt))
                        Next
                        cmbDemoFaultCode.SelectedIndex = 0
                    End If
                Case Else   'M-SPU23B
                    '@@@ mrk
                    If glNarrowTestFltCode <> 0 Then

                    End If

                    'iRet = GetPrivateProfileString("DEMO", "FAULT_CODE_SPU_B_GONOGO", "", StrBuffer, StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
                    'If String.IsNullOrEmpty(StrBuffer.ToString.Trim) = False Then
                    '    sTmp = StrBuffer.ToString.Split(",")
                    '    For iCnt As Integer = 0 To sTmp.Length - 1
                    '        cmbDemoFaultCode.Items.Add(sTmp(iCnt))
                    '    Next
                    '    cmbDemoFaultCode.SelectedIndex = 0
                    'End If
            End Select

            pnlDebugTS.Visible = True

            lblResult.Text = RSLT_FAIL
            lblResult.ForeColor = Color.FromName(COLOR_NG)
            grpResult.Visible = True

            If cmbDemoFaultCode.Items.Count > 0 Then
                glstrTestFltCode = cmbDemoFaultCode.SelectedItem.ToString
            End If
            glAddTestPtnNo = fncSetAddTestPtnNo(glstrTestFltCode)

            btnFltList.Visible = True
            btnRestart.Visible = False
            btnNext.Visible = True
            'pnlPowerAlive.Visible = True

            'Dim bRet As Boolean = gfncTestSeqColorChg(TestType.PCBTest, SeqIdxPCB.TestEnd)
            Exit Sub
        End If

        If glTestName = NAME_SPU23BTEST Then
            gbDebugSPU23B.Visible = True
        End If
#End If
        '-----
        Call subPCBTest()

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '  PCB Test Execution
    '
    '                               [Return   ] None
    '                               [Parameter] None
    '   2009.04.16 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub subPCBTest()
        Dim bRet As Boolean
        Dim isNoErr As Boolean
        Dim EachTestErrF As Boolean = False     '2008.10.17 add
        Dim iRet As Integer

        mglAbortFlg = False
        isNoErr = True

        MainForm.TimerEMStopChk.Enabled = False     '2009.04.01 add

        'Enabled initial setting 2009-11-20 T.Komine
        Me.btnFltList.Enabled = True
        Me.btnRestart.Enabled = True
        Me.btnNext.Enabled = True

        mglFltFormIdx = 1
        mglFltListViewIdx = 0
        mglFltListItmIdx = -1

        glNarrowTestFltCode = 0   'Narrow Down Test Error Fault Code

        ' SPU23 Test Only 2009-10-21 T.Komine
        If glTarget = TestTarget.HvacSPU23 Then
            glstrTestFltCode = ""
            'Clear TestFlow-BAR 2010-01-22 T.Komine
            bRet = gfncTestFlowColorChg(TestType.SPU23Test, SeqIdxSPU23.Appearance_Check, COLORNO_NONE)     '2008.10.03 add
            gfncTestSeqColorChg(TestType.SPU23Test, SeqIdxSPU23.Appearance_Check)   'Appearance Display 2010-01-22 T.Komine

            '' add k.sakemi 2009/11/18
        ElseIf glTarget = TestTarget.HvacSCB01 Then
            glstrTestFltCode = ""
            'Clear TestFlow-BAR 2010-01-22 T.Komine
            bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.Appearance_Check, COLORNO_NONE)
            gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.Appearance_Check)   'Appearance Display 2010-01-22 T.Komine
            '' add end
        Else
            'Clear TestFlow-BAR 2009-10-21 T.Komine
            bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check, COLORNO_OFF)

            bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC5_24_PowerVolt, COLORNO_OFF)
            bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC375_RelayCircuit, COLORNO_OFF)
            bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC24_RelayCircuit, COLORNO_OFF)
            bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Signl_RelayCircuit, COLORNO_OFF)

            glNarrowTestFltCode = NDTestFIdx.NormalTest   'Narrow Down Test Error Fault Code

            gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check)   'Appearance Display 2010-01-22 T.Komine
        End If

        'Clears previous test results
        Call subTestResultClear()

        Call subMainFormMsgLblDsp(MSG_CLR, COLOR_CLR)

        btnAbort.Visible = True
        btnRestart.Visible = False
        btnNext.Visible = False
        btnBack.Visible = False
        btnFltList.Visible = False
        grpResult.Visible = False
        pnlPowerAlive.Visible = False
        'pnlTSMsg.Visible = False
        pnlTestMsg.Visible = False       '2008.10.15 add

        glAddTestResultPassed = True

        MainForm.TestStatLbl.Text = "Testing....."

        Call Thread.Sleep(200)
        Application.DoEvents()

        'bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add

        If mglAbortFlg Then
            GoTo Abort_Seq
        End If

        '----------------------------
        '  Sets Test Execution Pattern
        '----------------------------
        bRet = fncSetPCBTestExecPtn()

        'Gets Check Value from INI
        If fncGetPCBTestCheckDataFromINI() <> True Then
            Call subWriteErrorLog("Check Data Get Error", "fncGetPCBcTestCheckDataFromINI() at subPCBTest")
            Call subMainFormMsgLblDsp(MSG_CHKGET_ERR, COLOR_ERR)
            GoTo Fail_Seq
        End If


        '------------------------------------------
        ' Appearance Check
        '------------------------------------------
        If glTarget = TestTarget.HvacSPU23 Then
            bRet = gfncTestSeqColorChg(TestType.SPU23Test, SeqIdxPCB.Appearance_Check)
        Else
            bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check)
        End If

        If glTarget = TestTarget.HvacSCB01 Then
            bRet = gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.Appearance_Check)
        Else
            bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check)
        End If

        '' mod k.sakemi 2010/02/02
        '' EachTestErrF = False
        Dim bAppFailFalg As Boolean = False
        If mglSPU23TestFlg = True Then

            'If glTarget = TestTarget.HvacSPU23 Then
            '    bRet = gfncTestSeqColorChg(TestType.SPU23Test, SeqIdxPCB.Appearance_Check)
            'Else
            '    bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check)
            'End If

            If False = fncAppearanceCheck(glTestType, 0) Then
                If glTarget = TestTarget.HvacSPU23 Then
                    bRet = gfncTestFlowColorChg(TestType.SPU23Test, SeqIdxPCB.Appearance_Check, COLORNO_FAIL)
                Else
                    bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check, COLORNO_FAIL)
                    glNarrowTestFltCode = NDTestFIdx.Appearance_Check_forSPU23   'Narrow Down Test Error Fault Code
                End If
                '' EachTestErrF = True
                bAppFailFalg = True
                'GoTo Fail_Seq   '2008.12.05 add
            End If

        End If
        If mglSCB01TestFlg = True Then

            'If glTarget = TestTarget.HvacSCB01 Then
            '    bRet = gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.Appearance_Check)
            'Else
            '    bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check)
            'End If

            If False = fncAppearanceCheck(glTestType, 1) Then
                If glTarget = TestTarget.HvacSCB01 Then
                    bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.Appearance_Check, COLORNO_FAIL)
                Else
                    bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check, COLORNO_FAIL)
                    glNarrowTestFltCode = NDTestFIdx.Appearance_Check_forSCB01   'Narrow Down Test Error Fault Code
                End If
                '' EachTestErrF = True
                bAppFailFalg = True
                'GoTo Fail_Seq   '2008.12.05 add
            End If

        End If

        If bAppFailFalg = False Then
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add
        End If
        If mglAbortFlg Then
            GoTo Abort_Seq
        End If

        'then Fault?
        '' If EachTestErrF <> True Then
        If bAppFailFalg <> True Then
            If glTarget = TestTarget.HvacSPU23 Then
                bRet = gfncTestFlowColorChg(TestType.SPU23Test, SeqIdxPCB.Appearance_Check, COLORNO_PASS)
            ElseIf glTarget = TestTarget.HvacSCB01 Then
                bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.Appearance_Check, COLORNO_PASS)

            Else
                bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Appearance_Check, COLORNO_PASS)
            End If
        Else
            GoTo Fail_Seq
        End If
        '' mod end

        '----------------------------
        ' AO and DO Initialization
        '----------------------------
        If gfncAOALLInit() <> True Then
            Call subWriteErrorLog("AO All Init Error", "at subPCBTest")
            subMainFormMsgLblDsp(MSG_AO_INIT_ERR, COLOR_ERR)
            GoTo Fail_Seq
        End If
        If gfncDOALLInit() <> True Then
            Call subWriteErrorLog("DO All Init Error", "at subPCBTest")
            subMainFormMsgLblDsp(MSG_DO_INIT_ERR, COLOR_ERR)
            GoTo Fail_Seq
        End If

        bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add

        '----------------------------
        ' Control Power ON
        '----------------------------
        If fncControlPowerChange(POWER_ON) <> True Then
            Call subWriteErrorLog("Control Power ON Error", "at subPCBTest")
            GoTo Fail_Seq
        End If

        'Modify request 09/12/08 T.Komine 2009-12-09 
        Thread.Sleep(5000)
        Application.DoEvents()

        '------------------------------------------
        ' DC5V/24V Power Voltage Test
        '------------------------------------------
        If mglSPU23TestFlg Then
            If glTarget = TestTarget.HvacSPU23 Then
                bRet = gfncTestSeqColorChg(TestType.SPU23Test, SeqIdxSPU23.DC5_24_PowerVolt)
            Else
                bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.DC5_24_PowerVolt)
            End If
            iRet = fncDC5V24VRelayTest()
            Select Case iRet
                Case RET_NORMAL_NG, RET_IOCARD_ERR
                    If glTarget = TestTarget.HvacSPU23 Then
                        bRet = gfncTestFlowColorChg(TestType.SPU23Test, SeqIdxSPU23.DC5_24_PowerVolt, COLORNO_FAIL)
                        'glNarrowTestFltCode = NDTestFIdx.DC5VDC24VTest   'Narrow Down Test Error Fault Code
                    Else
                        bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC5_24_PowerVolt, COLORNO_FAIL)
                        glNarrowTestFltCode = NDTestFIdx.DC5VDC24VTest   'Narrow Down Test Error Fault Code
                    End If
                    isNoErr = False
                    'EachTestErrF = True    'AI test  Error
                    GoTo Fail_Seq   '2008.12.05 add
            End Select
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add
            If mglAbortFlg Then
                GoTo Abort_Seq
            End If
            If EachTestErrF = False Then    'AI Test No Error
                If glTarget = TestTarget.HvacSPU23 Then
                    bRet = gfncTestFlowColorChg(TestType.SPU23Test, SeqIdxSPU23.DC5_24_PowerVolt, COLORNO_PASS)
                Else
                    bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC5_24_PowerVolt, COLORNO_PASS)
                End If
            End If
        End If

        '------------------------------------------
        ' DC37.5V Relay Circuit Test
        '------------------------------------------
        If mglSCB01TestFlg Then

            '' mod k.sakemi 2009/11/18
            If glTarget = TestTarget.HvacSCB01 Then
                bRet = gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.DC375_RelayCircuit)
            Else
                bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.DC375_RelayCircuit)
            End If
            '' mod end

            iRet = fncDC375VRelayTest()
            Select Case iRet
                Case RET_NORMAL_NG, RET_IOCARD_ERR
                    '' mod k.sakemi 2009/11/18
                    If glTarget = TestTarget.HvacSCB01 Then
                        bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.DC375_RelayCircuit, COLORNO_FAIL)
                    Else
                        bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC375_RelayCircuit, COLORNO_FAIL)
                        glNarrowTestFltCode = NDTestFIdx.DC375VRelayCircuitTest   'Narrow Down Test Error Fault Code
                    End If
                    '' mod end
                    isNoErr = False
                    'EachTestErrF = True    'AI test  Error
                    GoTo Fail_Seq   '2008.12.05 add
            End Select
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add
            If mglAbortFlg Then
                GoTo Abort_Seq
            End If
            If EachTestErrF = False Then    'AI Test No Error
                '' mod k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.DC375_RelayCircuit, COLORNO_PASS)
                Else
                    bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC375_RelayCircuit, COLORNO_PASS)
                End If
                '' mod end

            End If
        End If

        '------------------------------------------
        ' DC24V Relay Circuit Test
        '------------------------------------------
        If mglSCB01TestFlg Then

            '' mod k.sakemi 2009/11/18
            If glTarget = TestTarget.HvacSCB01 Then
                bRet = gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.DC24_RelayCircuit)
            Else
                bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.DC24_RelayCircuit)
            End If
            '' mod end

            iRet = fncDC24VRelayTest()
            Select Case iRet
                Case RET_NORMAL_NG, RET_IOCARD_ERR
                    '' mod k.sakemi 2009/11/18
                    If glTarget = TestTarget.HvacSCB01 Then
                        bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.DC24_RelayCircuit, COLORNO_FAIL)
                    Else
                        bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC24_RelayCircuit, COLORNO_FAIL)
                        glNarrowTestFltCode = NDTestFIdx.DC24VRelayCircuitTest   'Narrow Down Test Error Fault Code
                    End If
                    '' mod end
                    isNoErr = False
                    'EachTestErrF = True    'AI test  Error
                    GoTo Fail_Seq   '2008.12.05 add
            End Select
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add
            If mglAbortFlg Then
                GoTo Abort_Seq
            End If
            If EachTestErrF = False Then    'AI Test No Error
                '' mod k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.DC24_RelayCircuit, COLORNO_PASS)
                Else
                    bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.DC24_RelayCircuit, COLORNO_PASS)
                End If
                '' mod end
            End If
        End If

        '------------------------------------------
        ' Signal Relay Circuit Test
        '------------------------------------------
        If mglSCB01TestFlg Then
            '' mod k.sakemi 2009/11/18
            If glTarget = TestTarget.HvacSCB01 Then
                bRet = gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.Signl_RelayCircuit)
            Else
                bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.Signl_RelayCircuit)
            End If
            '' mod end

            iRet = fncSigRelayTest()
            Select Case iRet
                Case RET_NORMAL_NG, RET_IOCARD_ERR
                    '' mod k.sakemi 2009/11/18
                    If glTarget = TestTarget.HvacSCB01 Then
                        bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.Signl_RelayCircuit, COLORNO_FAIL)
                    Else
                        bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Signl_RelayCircuit, COLORNO_FAIL)
                        glNarrowTestFltCode = NDTestFIdx.SigRelayCircuitTest   'Narrow Down Test Error Fault Code
                    End If
                    '' mod end
                    isNoErr = False
                    'EachTestErrF = True    'AI test  Error
                    GoTo Fail_Seq   '2008.12.05 add
            End Select
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add
            If mglAbortFlg Then
                GoTo Abort_Seq
            End If
            If EachTestErrF = False Then    'AI Test No Error
                '' mod k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    bRet = gfncTestFlowColorChg(TestType.SCB01Test, SeqIdxSCB01.Signl_RelayCircuit, COLORNO_PASS)
                Else
                    bRet = gfncNDTestFlowColorChg(TestType.TCUTest, SeqIdxTCU.Signl_RelayCircuit, COLORNO_PASS)
                End If
                '' mod end
            End If
        End If

        '-------------------------------------------
        'End Process
        '-------------------------------------------
        MainForm.TestStatLbl.Text = "Test finished."
        If isNoErr = True Then
            lblResult.Text = RSLT_PASS
            lblResult.ForeColor = Color.FromName(COLOR_OK)
        Else
            lblResult.Text = RSLT_FAIL
            lblResult.ForeColor = Color.FromName(COLOR_NG)
        End If
        Application.DoEvents()


Test_End:

        If bAppFailFalg = False Then
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add
        End If


        Forms.Cursor.Current = Cursors.WaitCursor
        Application.DoEvents()


        '----------------------------
        ' Control Power OFF
        '----------------------------
        If fncControlPowerChange(POWER_OFF) <> True Then
            Call subWriteErrorLog("Control Power OFF Error", "at subPCBTest")
            subMainFormMsgLblDsp(MSG_PWR_OFF_ERR, COLOR_ERR)
        End If

        'Delete Check 2009/11/27 T.Komine
        'bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.03 add

        '----------------------------
        ' AO,DO Clear
        '----------------------------
        If gfncAOALLClear() <> True Then
            Call subWriteErrorLog("AO All Clear Error", "at subPCBTest")
            subMainFormMsgLblDsp(MSG_AO_CLR_ERR, COLOR_ERR)
        End If
        If gfncDOALLClear() <> True Then
            Call subWriteErrorLog("DO All Clear Error", "at subPCBTest")
            subMainFormMsgLblDsp(MSG_DO_CLR_ERR, COLOR_ERR)
        End If

        'lblCheckTime.Text = "0 sec"
        btnAbort.Visible = False
        btnRestart.Visible = True
        btnNext.Visible = True
        'btnBack.Visible = True     '2009.04.16 del

        If glTarget = TestTarget.HvacSPU23 Then
            glstrTestFltCode = fncGetFltCodefromTrbIni(mglFltFormIdx, mglFltListViewIdx, mglFltListItmIdx)
#If DEMO Then
            lblFCode.Text = glstrTestFltCode
#End If
        End If

        ''Check Narrow Donw Test 2009-09-15 T.Komine
        If glTarget = TestTarget.HvacSPU23 Then

        ElseIf glTarget = TestTarget.HvacSCB01 Then
            '@@@ mrk [ver1.4] >>
            'grpResult.Text = "Result of M-SCB01 Test"
            '@@@ mrk [ver1.4] <<
        Else
            If glTestType = TestType.MicTest Then
                grpResult.Text = "Result of ACCP Narrow Down Test"
            Else
                grpResult.Text = "Result of TCU Narrow Down Test"
            End If
            'Edit end Check Narrow Donw Test 2009-09-15 T.Komine
        End If
        grpResult.Visible = True

        pnlTestMsg.Visible = False       '2008.10.15 add
        pnlPowerAlive.Visible = True
        If RSLT_FAIL.Equals(lblResult.Text) Then
            'pnlTSMsg.Visible = True
            btnFltList.Visible = True

            'AddTest Fault Set 2009-09-08 T.Komine
            glAddTestResultPassed = False

            ''  add k.sakemi 2009/11/18
            If glTarget = TestTarget.HvacSCB01 Then
                glstrTestFltCode = fncGetFltCodefromTrbIni(mglFltFormIdx, mglFltListViewIdx, mglFltListItmIdx)
            End If
            '' add end

        End If
        If glTarget = TestTarget.HvacSPU23 Then
            bRet = gfncTestSeqColorChg(TestType.SPU23Test, SeqIdxSPU23.TestEnd)

            ''  add k.sakemi 2009/11/18
        ElseIf glTarget = TestTarget.HvacSCB01 Then
            bRet = gfncTestSeqColorChg(TestType.SCB01Test, SeqIdxSCB01.TestEnd)
            '' add end
        Else
            bRet = gfncNDTestSeqColorChg(TestType.TCUTest, SeqIdxTCU.TestEnd)
        End If

        Application.DoEvents()

        Forms.Cursor.Current = Cursors.Default

        'If GroupBox1.Visible Then
        '    ListView1.Select()
        '    ListView1.Items(0).Selected = False
        '    GroupBox1.ForeColor = Color.FromName(glGBGotFocusColorName)
        'End If
        'Application.DoEvents()

        '' mod k.sakemi 2010/02/02
        If bAppFailFalg = False Then
            MainForm.TimerEMStopChk.Enabled = True     '2009.04.01 add
        End If


        Exit Sub


Fail_Seq:
        MainForm.TestStatLbl.Text = "Test failed !"
        lblResult.Text = RSLT_FAIL
        lblResult.ForeColor = Color.FromName(COLOR_NG)
        Application.DoEvents()
        GoTo Test_End


Abort_Seq:
        MainForm.TestStatLbl.Text = "Test was aborted !"
        If isNoErr = False Then
            lblResult.Text = RSLT_FAIL
        Else
            lblResult.Text = RSLT_ABOT
        End If
        lblResult.ForeColor = Color.FromName(COLOR_NG)
        Application.DoEvents()
        GoTo Test_End

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '  Clears Previous Test Results
    '
    '                               [Return   ] None
    '                               [Parameter] None
    '   2008.02.15 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub subTestResultClear()
        Dim i As Integer

        For i = 0 To ListView1.Items.Count - 1
            ListView1.Items(i).SubItems(3).Text = ""
            ListView1.Items(i).SubItems(4).Text = ""
            ListView1.Items(i).SubItems(5).Text = ""
            ListView1.Items(i).SubItems(6).Text = ""
            ListView1.Items(i).SubItems(7).Text = ""
            ListView1.Items(i).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView1.Items(i).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView1.Items(i).SubItems(5).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView1.Items(i).SubItems(6).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView1.Items(i).SubItems(7).BackColor = Color.FromName(COLOR_NONE)
        Next

        For i = 0 To ListView2.Items.Count - 1
            ListView2.Items(i).SubItems(2).Text = ""
            ListView2.Items(i).SubItems(3).Text = ""
            ListView2.Items(i).SubItems(4).Text = ""
            ListView2.Items(i).SubItems(2).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView2.Items(i).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView2.Items(i).SubItems(4).BackColor = Color.FromName(COLOR_NONE)
        Next

        For i = 0 To ListView3.Items.Count - 1
            ListView3.Items(i).SubItems(3).Text = ""
            ListView3.Items(i).SubItems(4).Text = ""
            ListView3.Items(i).SubItems(5).Text = ""
            ListView3.Items(i).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView3.Items(i).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView3.Items(i).SubItems(5).BackColor = Color.FromName(COLOR_NONE)
        Next

        For i = 0 To ListView4.Items.Count - 1
            ListView4.Items(i).SubItems(2).Text = ""
            ListView4.Items(i).SubItems(3).Text = ""
            ListView4.Items(i).SubItems(4).Text = ""
            ListView4.Items(i).SubItems(5).Text = ""
            ListView4.Items(i).SubItems(2).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView4.Items(i).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView4.Items(i).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_OK)
            ListView4.Items(i).SubItems(5).BackColor = Color.FromName(COLOR_NONE)
        Next

        For i = 0 To ListView5.Items.Count - 1
            ListView5.Items(i).SubItems(2).Text = ""
            ListView5.Items(i).SubItems(2).BackColor = Color.FromName(COLOR_NONE)
        Next

        For i = 0 To ListView6.Items.Count - 1
            ListView6.Items(i).SubItems(2).Text = ""
            ListView6.Items(i).SubItems(2).BackColor = Color.FromName(COLOR_NONE)
        Next

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '  Sets and shows ToolTipText of each test item when mouse cursol is upon it
    '
    '   2008.10.14 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub ListView1_ItemMouseHover(ByVal sender As Object, ByVal e As System.Windows.Forms.ListViewItemMouseHoverEventArgs)

        Dim sText As String = ""
        Dim idx As Integer
        Dim strBuffer As New System.Text.StringBuilder
        Dim sKeySwVer() As String = New String() {"CONSW_VER", "LONIF_VER"}
        Dim bIsDspF As Boolean = True
        Dim range1 As Double = 0.0
        Dim range2 As Double = 0.0
        Dim range3 As Double = 0.0
        Dim range4 As Double = 0.0

        idx = e.Item.Index
        strBuffer.Capacity = 255

        Select Case e.Item.ListView.Name
            Case "ListView1"    'DC37.5V Relay Circuit Test
                With glPCBChkDC375VRly(idx)
                    If .ChkData1 <= 0.0 Then
                        range1 = .Range1
                    Else
                        range1 = .ChkData1 * .Range1 / 100
                    End If
                    If .ChkData2 <= 0.0 Then
                        range2 = .Range2
                    Else
                        range2 = .ChkData2 * .Range2 / 100
                    End If
                    If .ChkData3 <= 0.0 Then
                        range3 = .Range3
                    Else
                        range3 = .ChkData3 * .Range3 / 100
                    End If

                    '' mod k.sakemi 2010/01/25 listview row 2 and column 4 displayed
                    If idx <> 1 Then
                        If .ChkData4 <= 0.0 Then
                            range4 = .Range4
                        Else
                            range4 = .ChkData4 * .Range4 / 100
                        End If

                        sText = "[Criterion] " & (.ChkData1 - range1).ToString & "V - " _
                                                  & (.ChkData1 + range1).ToString & "V : " _
                                                  & (.ChkData2 - range2).ToString & "V - " _
                                                  & (.ChkData2 + range2).ToString & "V : " _
                                                  & (.ChkData3 - range3).ToString & "V - " _
                                                  & (.ChkData3 + range3).ToString & "V : " _
                                                  & (.ChkData4 - range4).ToString & "V - " _
                                                  & (.ChkData4 + range4).ToString & "V"
                    Else

                        sText = "[Criterion] " & (.ChkData1 - range1).ToString & "V - " _
                                                    & (.ChkData1 + range1).ToString & "V : " _
                                                    & (.ChkData2 - range2).ToString & "V - " _
                                                    & (.ChkData2 + range2).ToString & "V : " _
                                                    & (.ChkData3 - range3).ToString & "V - " _
                                                    & (.ChkData3 + range3).ToString & "V"

                    End If
                    '' mod end
         

   
                End With

            Case "ListView2"    'DC24V Relay Circuit Test
                sText = "[Criterion] " & (glPCBChkDC24VRly(0).ChkData * ((100 - glPCBChkDC24VRly(0).Range) / 100)).ToString & "V - " _
                                       & (glPCBChkDC24VRly(0).ChkData * ((100 + glPCBChkDC24VRly(0).Range) / 100)).ToString & "V : " _
                                       & (glPCBChkDC24VRly(1).ChkData * ((100 - glPCBChkDC24VRly(1).Range) / 100)).ToString & "V - " _
                                       & (glPCBChkDC24VRly(1).ChkData * ((100 + glPCBChkDC24VRly(1).Range) / 100)).ToString & "V"

            Case "ListView3"    'Signal Relay Circuit Test
                With glPCBChkSigRly(idx)
                    If idx < 14 Then
                        If .ChkData1 <= 0.0 Then
                            range1 = .Range1
                        Else
                            range1 = .ChkData1 * .Range1 / 100
                        End If

                        sText = "[Criterion] " & (.ChkData1 - range1).ToString & "V - " _
                                               & (.ChkData1 + range1).ToString & "V"
                    Else
                        If .ChkData1 <= 0.0 Then
                            range1 = .Range1
                        Else
                            range1 = .ChkData1 * .Range1 / 100
                        End If
                        If .ChkData2 <= 0.0 Then
                            range2 = .Range2
                        Else
                            range2 = .ChkData2 * .Range2 / 100
                        End If

                        sText = "[Criterion] " & (.ChkData1 - range1).ToString & "V - " _
                                               & (.ChkData1 + range1).ToString & "V : " _
                                               & (.ChkData2 - range2).ToString & "V - " _
                                               & (.ChkData2 + range2).ToString & "V"
                    End If
                End With

            Case "ListView4"    'DC5V/DC24V Test
                If idx = 0 Then
                    sText = "[Criterion] at 23.0Vdc(" & (glPCBChkPte5V(0).ChkData * ((100 - glPCBChkPte5V(0).Range) / 100)).ToString & "V - " _
                                                      & (glPCBChkPte5V(0).ChkData * ((100 + glPCBChkPte5V(0).Range) / 100)).ToString _
                                & "V) at 42.5Vdc(" & (glPCBChkPte5V(1).ChkData * ((100 - glPCBChkPte5V(1).Range) / 100)).ToString & "V - " _
                                                   & (glPCBChkPte5V(1).ChkData * ((100 + glPCBChkPte5V(1).Range) / 100)).ToString _
                                & "V) at 37.5Vdc(" & (glPCBChkPte5V(2).ChkData * ((100 - glPCBChkPte5V(2).Range) / 100)).ToString & "V - " _
                                                   & (glPCBChkPte5V(2).ChkData * ((100 + glPCBChkPte5V(2).Range) / 100)).ToString & "V)"
                Else
                    sText = "[Criterion] at 23.0Vdc(" & (glPCBChkPte24V(0).ChkData * ((100 - glPCBChkPte24V(0).Range) / 100)).ToString & "V - " _
                                                      & (glPCBChkPte24V(0).ChkData * ((100 + glPCBChkPte24V(0).Range) / 100)).ToString _
                                & "V) at 42.5Vdc(" & (glPCBChkPte24V(1).ChkData * ((100 - glPCBChkPte24V(1).Range) / 100)).ToString & "V - " _
                                                   & (glPCBChkPte24V(1).ChkData * ((100 + glPCBChkPte24V(1).Range) / 100)).ToString _
                                & "V) at 37.5Vdc(" & (glPCBChkPte24V(2).ChkData * ((100 - glPCBChkPte24V(2).Range) / 100)).ToString & "V - " _
                                                   & (glPCBChkPte24V(2).ChkData * ((100 + glPCBChkPte24V(2).Range) / 100)).ToString & "V)"
                End If

            Case "ListView5", "ListView6"
                bIsDspF = False
        End Select

        If bIsDspF Then
            ToolTip1.SetToolTip(sender, sText)
        End If

        'ToolTip1.SetToolTip(sender, "Item=" & e.Item.ListView.Name.ToString & " ItemIndex=" & e.Item.Index.ToString)

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Changes Focused GroupBox ForeColor
    '
    '   2009.04.20 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub ListView1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim lstvw As ListView = TryCast(sender, ListView)
        Dim grptmp As New GroupBox

        Try
            If btnAbort.Visible Then
                Exit Sub
            End If

            Select Case lstvw.Name
                Case "ListView1"
                    grptmp = GroupBox1
                Case "ListView2"
                    grptmp = GroupBox2
                Case "ListView3"
                    grptmp = GroupBox3
                Case "ListView4"
                    grptmp = GroupBox4
                Case "ListView5"
                    grptmp = GroupBox5
                Case "ListView6"
                    grptmp = GroupBox6
            End Select
            grptmp.ForeColor = Color.FromName(glGBGotFocusColorName)

        Catch ex As Exception
            Call subWriteErrorLog(ex.Message, "at ListView1_GotFocus")
        End Try

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Changes LostFocused GroupBox ForeColor
    '
    '   2009.04.20 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub ListView1_LostFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        Dim lstvw As ListView = TryCast(sender, ListView)
        Dim grptmp As New GroupBox

        Try
            If btnAbort.Visible Then
                Exit Sub
            End If

            Select Case lstvw.Name
                Case "ListView1"
                    grptmp = GroupBox1
                Case "ListView2"
                    grptmp = GroupBox2
                Case "ListView3"
                    grptmp = GroupBox3
                Case "ListView4"
                    grptmp = GroupBox4
                Case "ListView5"
                    grptmp = GroupBox5
                Case "ListView6"
                    grptmp = GroupBox6
            End Select
            grptmp.ForeColor = Color.FromName(glGBLostFocusColorName)

        Catch ex As Exception
            Call subWriteErrorLog(ex.Message, "at ListView1_LostFocus")
        End Try


    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Selects [Show Fault List] Button
    '
    '   2008.12.18 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub btnFltList_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnFltList.Click
        Dim bRet As Boolean

        MainForm.TestStatLbl.Text = ""

        glDispChgNo = DispChgNo.PCBTest_FList

        bRet = gfncDispChg(glDispChgNo)

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '   Selects [< Back] Button
    '
    '   2008.11.26 updated
    '-----------------------------------------------------------------------------------------------------
    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Dim bRet As Boolean

        MainForm.TestStatLbl.Text = ""

        If glTarget = TestTarget.HvacSPU23 Then
            glDispChgNo = DispChgNo.PCBTest_Back
        Else
            glDispChgNo = DispChgNo.PCBTest_Next
        End If

        bRet = gfncDispChg(glDispChgNo)

    End Sub

    '-----------------------------------------------------------------------------------------------------
    '  DC37.5V Relay Test
    '
    '                               [Return   ] status
    '                                           RET_NORMAL_OK  : Normally Completed
    '                                           RET_NORMAL_NG  : Error
    '                               [Parameter] None
    '   2010.01.16 updated
    '-----------------------------------------------------------------------------------------------------
    Private Function fncDC375VRelayTest() As Integer
        Dim dGetData(4 - 1) As Double
        Dim dChkData(4 - 1) As Double
        Dim dRange(4 - 1) As Double
        Dim sErrMsg As String = ""
        Dim iRet As Integer = 0
        Dim i As Integer
        Dim isErrF As Boolean = False
        Dim bRet As Boolean
        Dim j As Integer = 0


        fncDC375VRelayTest = RET_NORMAL_OK

        If glPCBTestIdx(PCBTestIdx.DC375VRelayCircuitTest) = TEST_EXECUTE Then
            '-------------------------------------------------
            ' CP1 OFF, AIEE OFF
            '-------------------------------------------------
#If DEMO = False Then
            'CP1 OFF
            If gfncDO(CARD_CP1_DO, CH_CP1_DO, 0) <> True Then
                Exit Function
            End If

            '' del k.sakemi 2009/11/19
            'Contactor AIEE(DO1-Ch1) OFF
            'If gfncDO(CARD_AIEE_DO, CH_AIEE_DO, 0) <> True Then
            '    Exit Function
            'End If
            '' del end

            '1sec wait
            Thread.Sleep(1000)      '' mod k.sakemi 2009/11/19
#End If

            '' del k.sakemi 2009/11/19
            'Add 2009-10-23 T.Komine
            gfncWaitingPnlDisp(TXT_PWR_WAIT, PWR_WAIT_TIME_CNT, Me.lblTransChkCnt, Me.lblTransSec, Me.pnlTransChkTime, mglAbortFlg)
            If mglAbortFlg Then
                Exit Function
            End If
            '' del end

            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            With glPCBChkDC375VRly(0)
                dChkData(0) = .ChkData1
                dChkData(1) = .ChkData2
                dChkData(2) = .ChkData3
                dChkData(3) = .ChkData4
                If dChkData(0) <= 0.0 Then
                    dRange(0) = .Range1
                Else
                    dRange(0) = dChkData(0) * .Range1 / 100
                End If
                If dChkData(1) <= 0.0 Then
                    dRange(1) = .Range2
                Else
                    dRange(1) = dChkData(1) * .Range2 / 100
                End If
                If dChkData(2) <= 0.0 Then
                    dRange(2) = .Range3
                Else
                    dRange(2) = dChkData(2) * .Range3 / 100
                End If
                If dChkData(3) <= 0.0 Then
                    dRange(3) = .Range4
                Else
                    dRange(3) = dChkData(3) * .Range4 / 100
                End If
            End With

            ' PCB Test DC37.5V Relay Circuit Test function
            iRet = gfncPCBTest_DC375VRelay(dGetData, 0)
            If iRet <> RET_NORMAL_OK Then
                fncDC375VRelayTest = iRet
                Exit Function
            End If

            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            'Shows Scan Data
            For i = 0 To 3

                ListView1.Items(0).SubItems(i + 3).Text = dGetData(i).ToString("0.00")

                If (dGetData(i) >= (dChkData(i) - dRange(i)) _
                    AndAlso dGetData(i) <= (dChkData(i) + dRange(i))) Then
                    ListView1.Items(0).SubItems(i + 3).ForeColor = Color.FromName(COLOR_VALUE_OK)
                Else
                    ListView1.Items(0).SubItems(i + 3).ForeColor = Color.FromName(COLOR_VALUE_NG)
                    isErrF = True
                End If
            Next

            If isErrF Then
                ListView1.Items(0).SubItems(7).Text = TXT_JDG_NG
                ListView1.Items(0).SubItems(7).BackColor = Color.FromName(COLOR_NG)
                fncDC375VRelayTest = RET_NORMAL_NG
                '' add k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    mglFltFormIdx = 1
                    mglFltListViewIdx = 1
                    mglFltListItmIdx = 1
                End If
                '' add end
                GoTo Test_End
            Else
                ListView1.Items(0).SubItems(7).Text = TXT_JDG_OK
                ListView1.Items(0).SubItems(7).BackColor = Color.FromName(COLOR_OK)
            End If

            isErrF = False
            Application.DoEvents()

            '-------------------------------------------------
            ' CP1 ON, AIEE OFF
            '-------------------------------------------------
#If DEMO = False Then
            'CP1 ON
            If gfncDO(CARD_CP1_DO, CH_CP1_DO, 1) <> True Then
                Exit Function
            End If

            '1sec wait
            Thread.Sleep(1000)      '' mod k.sakemi 2009/11/19
#End If
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            With glPCBChkDC375VRly(1)
                dChkData(0) = .ChkData1
                dChkData(1) = .ChkData2
                dChkData(2) = .ChkData3
                dChkData(3) = .ChkData4
                If dChkData(0) <= 0.0 Then
                    dRange(0) = .Range1
                Else
                    dRange(0) = dChkData(0) * .Range1 / 100
                End If
                If dChkData(1) <= 0.0 Then
                    dRange(1) = .Range2
                Else
                    dRange(1) = dChkData(1) * .Range2 / 100
                End If
                If dChkData(2) <= 0.0 Then
                    dRange(2) = .Range3
                Else
                    dRange(2) = dChkData(2) * .Range3 / 100
                End If
                If dChkData(3) <= 0.0 Then
                    dRange(3) = .Range4
                Else
                    dRange(3) = dChkData(3) * .Range4 / 100
                End If
            End With

            ' PCB Test DC37.5V Relay Circuit Test function
            iRet = gfncPCBTest_DC375VRelay(dGetData, 1)
            If iRet <> RET_NORMAL_OK Then
                fncDC375VRelayTest = iRet
                Exit Function
            End If

            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            'Shows Scan Data
            For i = 0 To 2  'DMM1A-CH18 No Display&Check 2009-10-21 T.Komine 
                'For i = 0 To 3
                ListView1.Items(1).SubItems(i + 3).Text = dGetData(i).ToString("0.00")

                If (dGetData(i) >= (dChkData(i) - dRange(i)) _
                    AndAlso dGetData(i) <= (dChkData(i) + dRange(i))) Then
                    ListView1.Items(1).SubItems(i + 3).ForeColor = Color.FromName(COLOR_VALUE_OK)
                Else
                    ListView1.Items(1).SubItems(i + 3).ForeColor = Color.FromName(COLOR_VALUE_NG)
                    isErrF = True
                End If
            Next

            'display BAR 2009-12-01 T.Komine  
            ListView1.Items(1).SubItems(3 + 3).ForeColor = Color.FromName(COLOR_CLR)
            ListView1.Items(1).SubItems(3 + 3).Text = TXT_JDG_BAR

            If isErrF Then
                ListView1.Items(1).SubItems(7).Text = TXT_JDG_NG
                ListView1.Items(1).SubItems(7).BackColor = Color.FromName(COLOR_NG)
                fncDC375VRelayTest = RET_NORMAL_NG
                '' add k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    mglFltFormIdx = 1
                    mglFltListViewIdx = 1
                    mglFltListItmIdx = 1
                End If
                '' add end
                GoTo Test_End
            Else
                ListView1.Items(1).SubItems(7).Text = TXT_JDG_OK
                ListView1.Items(1).SubItems(7).BackColor = Color.FromName(COLOR_OK)
            End If

            isErrF = False
            Application.DoEvents()

            '-------------------------------------------------
            ' CP1 ON, AIEE ON
            '-------------------------------------------------
#If DEMO = False Then
            'Contactor AIEE(DO1-Ch1) ON
            If gfncDO(CARD_AIEE_DO, CH_AIEE_DO, 1) <> True Then
                Exit Function
            End If

            '1sec wait
            Thread.Sleep(1000)      '' mod k.sakemi 2009/11/19
#End If
            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            With glPCBChkDC375VRly(2)
                dChkData(0) = .ChkData1
                dChkData(1) = .ChkData2
                dChkData(2) = .ChkData3
                dChkData(3) = .ChkData4
                If dChkData(0) <= 0.0 Then
                    dRange(0) = .Range1
                Else
                    dRange(0) = dChkData(0) * .Range1 / 100
                End If
                If dChkData(1) <= 0.0 Then
                    dRange(1) = .Range2
                Else
                    dRange(1) = dChkData(1) * .Range2 / 100
                End If
                If dChkData(2) <= 0.0 Then
                    dRange(2) = .Range3
                Else
                    dRange(2) = dChkData(2) * .Range3 / 100
                End If
                If dChkData(3) <= 0.0 Then
                    dRange(3) = .Range4
                Else
                    dRange(3) = dChkData(3) * .Range4 / 100
                End If
            End With

            ' PCB Test DC37.5V Relay Circuit Test function
            iRet = gfncPCBTest_DC375VRelay(dGetData, 2)
            If iRet <> RET_NORMAL_OK Then
                fncDC375VRelayTest = iRet
                Exit Function
            End If

            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            'Shows Scan Data
            For i = 0 To 3
                ListView1.Items(2).SubItems(i + 3).Text = dGetData(i).ToString("0.00")

                If (dGetData(i) >= (dChkData(i) - dRange(i)) _
                    AndAlso dGetData(i) <= (dChkData(i) + dRange(i))) Then
                    ListView1.Items(2).SubItems(i + 3).ForeColor = Color.FromName(COLOR_VALUE_OK)
                Else
                    ListView1.Items(2).SubItems(i + 3).ForeColor = Color.FromName(COLOR_VALUE_NG)
                    isErrF = True
                End If
            Next

            If isErrF Then
                ListView1.Items(2).SubItems(7).Text = TXT_JDG_NG
                ListView1.Items(2).SubItems(7).BackColor = Color.FromName(COLOR_NG)
                fncDC375VRelayTest = RET_NORMAL_NG
                '' add k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    mglFltFormIdx = 1
                    mglFltListViewIdx = 1
                    mglFltListItmIdx = 1
                End If
                '' add end
            Else
                ListView1.Items(2).SubItems(7).Text = TXT_JDG_OK
                ListView1.Items(2).SubItems(7).BackColor = Color.FromName(COLOR_OK)
            End If

            Application.DoEvents()

Test_End:
            '-------------------------------------------------
            ' CP1 OFF  AIEE OFF
            '-------------------------------------------------
#If DEMO = False Then

            '' add k.sakemi 2009/11/19
            'CP1 OFF
            If gfncDO(CARD_CP1_DO, CH_CP1_DO, 0) <> True Then
                Exit Function
            End If
            '' add end

            'Contactor AIEE(DO1-Ch1) OFF
            If gfncDO(CARD_AIEE_DO, CH_AIEE_DO, 0) <> True Then
                Exit Function
            End If
#End If

        Else
            For i = 0 To 2
                ListView1.Items(i).SubItems(7).Text = TXT_JDG_BAR
            Next
        End If

    End Function

    '-----------------------------------------------------------------------------------------------------
    '  DC24V Relay Test
    '
    '                               [Return   ] status
    '                                           RET_NORMAL_OK  : Normally Completed
    '                                           RET_NORMAL_NG  : Error
    '                               [Parameter] None
    '   2010.01.16 updated
    '-----------------------------------------------------------------------------------------------------
    Private Function fncDC24VRelayTest() As Integer
        Dim dGetData(2 - 1) As Double
        Dim dChkData(2 - 1) As Double
        Dim sErrMsg As String = ""
        Dim iRet As Integer = 0
        Dim isErrF As Boolean = False
        Dim bRet As Boolean

        fncDC24VRelayTest = RET_NORMAL_OK

        If glPCBTestIdx(PCBTestIdx.DC24VRelayCircuitTest) = TEST_EXECUTE Then

            'DC24V Relay Circuit Test
            iRet = gfncPCBTest_DC24VRelay(dGetData)
            If iRet <> RET_NORMAL_OK Then
                fncDC24VRelayTest = iRet
                Exit Function
            End If

            bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

            Application.DoEvents()
            If mglAbortFlg Then
                Exit Function
            End If

            'Get Limit Data
            dChkData(0) = glPCBChkDC24VRly(0).ChkData
            dChkData(1) = glPCBChkDC24VRly(1).ChkData

            'Set data to ListView
            ListView2.Items(0).SubItems(2).Text = dGetData(0).ToString("0.00")

            If (dGetData(0) >= (dChkData(0) * ((100 - glPCBChkDC24VRly(0).Range) / 100))) _
                AndAlso (dGetData(0) <= (dChkData(0) * ((100 + glPCBChkDC24VRly(0).Range) / 100))) Then
                ListView2.Items(0).SubItems(2).ForeColor = Color.FromName(COLOR_VALUE_OK)
            Else
                ListView2.Items(0).SubItems(2).ForeColor = Color.FromName(COLOR_VALUE_NG)
                isErrF = True
            End If

            ListView2.Items(0).SubItems(3).Text = dGetData(1).ToString("0.00")

            If (dGetData(1) >= (dChkData(1) * ((100 - glPCBChkDC24VRly(1).Range) / 100))) _
                AndAlso (dGetData(1) <= (dChkData(1) * ((100 + glPCBChkDC24VRly(1).Range) / 100))) Then
                ListView2.Items(0).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
            Else
                ListView2.Items(0).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_NG)
                isErrF = True
            End If

            Application.DoEvents()

            If isErrF Then
                ListView2.Items(0).SubItems(4).Text = TXT_JDG_NG
                ListView2.Items(0).SubItems(4).BackColor = Color.FromName(COLOR_NG)
                fncDC24VRelayTest = RET_NORMAL_NG
                '' add k.sakemi 2009/11/18
                If glTarget = TestTarget.HvacSCB01 Then
                    mglFltFormIdx = 2
                    mglFltListViewIdx = 1
                    mglFltListItmIdx = 1
                End If
                '' add end
            Else
                ListView2.Items(0).SubItems(4).Text = TXT_JDG_OK
                ListView2.Items(0).SubItems(4).BackColor = Color.FromName(COLOR_OK)
            End If

            Application.DoEvents()

        Else
            ListView2.Items(0).SubItems(4).Text = TXT_JDG_BAR
        End If

    End Function

    '-----------------------------------------------------------------------------------------------------
    '  Signal Relay Test
    '
    '                               [Return   ] status
    '                                           RET_NORMAL_OK  : Normally Completed
    '                                           RET_NORMAL_NG  : Error
    '                               [Parameter] None
    '   2010.01.16 updated
    '-----------------------------------------------------------------------------------------------------
    Private Function fncSigRelayTest() As Integer
        Dim sngSetData As Single
        Dim dGetData(2 - 1) As Double
        Dim dChkData(2 - 1) As Double
        Dim dRange(2 - 1) As Double
        Dim sErrMsg As String = ""
        Dim iRet As Integer = 0
        Dim i As Integer
        Dim isErrF As Boolean = False
        Dim bRet As Boolean

        Dim AiCards() As Integer = New Integer() {IOCardNo.CARD_MM_1B, IOCardNo.CARD_MM_1B, IOCardNo.CARD_MM_1B, IOCardNo.CARD_MM_1B, _
                                                  IOCardNo.CARD_MM_1B, IOCardNo.CARD_MM_1B, IOCardNo.CARD_MM_1B, IOCardNo.CARD_MM_1B, _
                                                  IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, _
                                                  IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, _
                                                  IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A}

        Dim AiCards2() As Integer = New Integer() {-1, -1, -1, -1, _
                                                   -1, -1, -1, -1, _
                                                   -1, -1, -1, -1, _
                                                   -1, -1, IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A, _
                                                  IOCardNo.CARD_MM_1A, IOCardNo.CARD_MM_1A}

        Dim SigChs() As Integer = New Integer() {ChIndex.CH_1, ChIndex.CH_1, ChIndex.CH_2, ChIndex.CH_2, _
                                                 ChIndex.CH_3, ChIndex.CH_3, ChIndex.CH_4, ChIndex.CH_4, _
                                                 ChIndex.CH_9, ChIndex.CH_9, ChIndex.CH_10, ChIndex.CH_10, _
                                                 ChIndex.CH_11, ChIndex.CH_11, ChIndex.CH_12, ChIndex.CH_12, _
                                                 ChIndex.CH_14, ChIndex.CH_14}

        Dim SigChs2() As Integer = New Integer() {-1, -1, -1, -1, _
                                                  -1, -1, -1, -1, _
                                                  -1, -1, -1, -1, _
                                                  -1, -1, ChIndex.CH_13, ChIndex.CH_13, _
                                                 ChIndex.CH_15, ChIndex.CH_15}

        Dim AoCards() As Integer = New Integer() {IOCardNo.CARD_AO_1, IOCardNo.CARD_AO_1, IOCardNo.CARD_AO_1, IOCardNo.CARD_AO_1, _
                                                  IOCardNo.CARD_AO_1, IOCardNo.CARD_AO_1, IOCardNo.CARD_AO_1, IOCardNo.CARD_AO_1, _
                                                  IOCardNo.CARD_AO_2, IOCardNo.CARD_AO_2, IOCardNo.CARD_AO_2, IOCardNo.CARD_AO_2, _
                                                  IOCardNo.CARD_AO_2, IOCardNo.CARD_AO_2, IOCardNo.CARD_AO_2, IOCardNo.CARD_AO_2, _
                                                  IOCardNo.CARD_AO_3, IOCardNo.CARD_AO_3}

        Dim AoChs() As Integer = New Integer() {0, 0, 1, 1, _
                                                2, 2, 3, 3, _
                                                0, 0, 1, 1, _
                                                2, 2, 3, 3, _
                                                0, 0}

        fncSigRelayTest = RET_NORMAL_OK


        For i = 0 To 17 Step 2

            If glPCBTestIdx(PCBTestIdx.SigRelayCircuitTest) = TEST_EXECUTE Then

                isErrF = False
                '---------------------------------------------
                ' AO <-- 0V
                '---------------------------------------------
                sngSetData = glPCBChkSigRlyOutV(i).OutData
#If DEMO = False Then
                'Sets each data to 
                If gfncAO(AoCards(i), AoChs(i), sngSetData) <> True Then
                    Call subWriteErrorLog("AO Set Error", "at fncSigRelayTest of subPCBTest")
                    subMainFormMsgLblDsp(MSG_AO_ERR, COLOR_ERR)
                    fncSigRelayTest = RET_IOCARD_ERR
                    Exit Function
                End If

                Thread.Sleep(1000)
#Else
                Thread.Sleep(200)
#End If
                Application.DoEvents()

                bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                Application.DoEvents()
                If mglAbortFlg Then
                    Exit Function
                End If

                ' PCB Test Signal Relay Circuit Test function
                iRet = gfncPCBTest_SigRelay(dGetData, i, AiCards(i), AiCards2(i), SigChs(i), SigChs2(i))
                If iRet <> RET_NORMAL_OK Then
                    fncSigRelayTest = iRet
                    Exit Function
                End If

                With glPCBChkSigRly(i)
                    dChkData(0) = .ChkData1
                    If dChkData(0) <= 0.0 Then
                        dRange(0) = .Range1
                    Else
                        dRange(0) = dChkData(0) * .Range1 / 100
                    End If

                    If SigChs2(i) >= 0 Then

                        dChkData(1) = .ChkData2
                        If dChkData(1) <= 0.0 Then
                            dRange(1) = .Range2
                        Else
                            dRange(1) = dChkData(1) * .Range2 / 100
                        End If
                    End If
                End With

                ListView3.Items(i).SubItems(3).Text = dGetData(0).ToString("0.00")

                If (dGetData(0) >= (dChkData(0) - dRange(0)) AndAlso dGetData(0) <= (dChkData(0) + dRange(0))) Then
                    ListView3.Items(i).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
                Else
                    ListView3.Items(i).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_NG)
                    isErrF = True
                End If

                If SigChs2(i) >= 0 Then

                    ListView3.Items(i).SubItems(4).Text = dGetData(1).ToString("0.00")

                    If (dGetData(1) >= (dChkData(1) - dRange(1)) AndAlso dGetData(1) <= (dChkData(1) + dRange(1))) Then
                        ListView3.Items(i).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_OK)
                    Else
                        ListView3.Items(i).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_NG)
                        isErrF = True
                    End If

                Else
                    'display BAR 2009-12-01 T.Komine  
                    ListView3.Items(i).SubItems(4).ForeColor = Color.FromName(COLOR_CLR)
                    ListView3.Items(i).SubItems(4).Text = TXT_JDG_BAR
                End If

                If isErrF Then
                    ListView3.Items(i).SubItems(5).Text = TXT_JDG_NG
                    ListView3.Items(i).SubItems(5).BackColor = Color.FromName(COLOR_NG)
                    fncSigRelayTest = RET_NORMAL_NG
                    '' add k.sakemi 2009/11/18
                    If glTarget = TestTarget.HvacSCB01 Then
                        mglFltFormIdx = 3
                        mglFltListViewIdx = 1
                        mglFltListItmIdx = 1
                    End If
                    '' add end
                    '' add k.sakemi 2009/11/19
                    Exit Function
                    '' add end
                Else
                    ListView3.Items(i).SubItems(5).Text = TXT_JDG_OK
                    ListView3.Items(i).SubItems(5).BackColor = Color.FromName(COLOR_OK)
                End If

                bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                Application.DoEvents()
                If mglAbortFlg Then
                    Exit Function
                End If

                '---------------------------------------------
                ' AO <-- 10V
                '---------------------------------------------
                If isErrF = False Then

                    sngSetData = glPCBChkSigRlyOutV(i + 1).OutData
#If DEMO = False Then
                    'Sets each data to 
                    If gfncAO(AoCards(i), AoChs(i), sngSetData) <> True Then
                        Call subWriteErrorLog("AO Set Error", "at fncSigRelayTest of subPCBTest")
                        subMainFormMsgLblDsp(MSG_AO_ERR, COLOR_ERR)
                        fncSigRelayTest = RET_IOCARD_ERR
                        Exit Function
                    End If

                    Thread.Sleep(1000)
#Else
                    Thread.Sleep(200)
#End If
                    Application.DoEvents()

                    bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                    Application.DoEvents()
                    If mglAbortFlg Then
                        Exit Function
                    End If

                    ' PCB Test Signal Relay Circuit Test function
                    iRet = gfncPCBTest_SigRelay(dGetData, i + 1, AiCards(i + 1), AiCards2(i + 1), SigChs(i + 1), SigChs2(i + 1))

                    '' add k.sakemi 2009/11/19
                    '---------------------------------------------
                    ' AO <-- 0V
                    '---------------------------------------------
                    sngSetData = glPCBChkSigRlyOutV(i).OutData
                    'Sets each data to 
                    If gfncAO(AoCards(i), AoChs(i), sngSetData) <> True Then
                        Call subWriteErrorLog("AO Set Error", "at fncSigRelayTest of subPCBTest")
                        subMainFormMsgLblDsp(MSG_AO_ERR, COLOR_ERR)
                        fncSigRelayTest = RET_IOCARD_ERR
                        Exit Function
                    End If
                    '' add end

                    If iRet <> RET_NORMAL_OK Then
                        fncSigRelayTest = iRet
                        Exit Function
                    End If

                    With glPCBChkSigRly(i + 1)
                        dChkData(0) = .ChkData1
                        If dChkData(0) <= 0.0 Then
                            dRange(0) = .Range1
                        Else
                            dRange(0) = dChkData(0) * .Range1 / 100
                        End If

                        If SigChs2(i + 1) >= 0 Then

                            dChkData(1) = .ChkData2
                            If dChkData(1) <= 0.0 Then
                                dRange(1) = .Range2
                            Else
                                dRange(1) = dChkData(1) * .Range2 / 100
                            End If
                        End If
                    End With

                    ListView3.Items(i + 1).SubItems(3).Text = dGetData(0).ToString("0.00")

                    If (dGetData(0) >= (dChkData(0) - dRange(0)) AndAlso dGetData(0) <= (dChkData(0) + dRange(0))) Then
                        ListView3.Items(i + 1).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_OK)
                    Else
                        ListView3.Items(i + 1).SubItems(3).ForeColor = Color.FromName(COLOR_VALUE_NG)
                        isErrF = True
                    End If

                    If SigChs2(i + 1) >= 0 Then

                        ListView3.Items(i + 1).SubItems(4).Text = dGetData(1).ToString("0.00")

                        If (dGetData(1) >= (dChkData(1) - dRange(1)) AndAlso dGetData(1) <= (dChkData(1) + dRange(1))) Then
                            ListView3.Items(i + 1).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_OK)
                        Else
                            ListView3.Items(i + 1).SubItems(4).ForeColor = Color.FromName(COLOR_VALUE_NG)
                            isErrF = True
                        End If
                    Else
                        'display BAR 2009-12-01 T.Komine  
                        ListView3.Items(i + 1).SubItems(4).ForeColor = Color.FromName(COLOR_CLR)
                        ListView3.Items(i + 1).SubItems(4).Text = TXT_JDG_BAR
                    End If

                    If isErrF Then
                        ListView3.Items(i + 1).SubItems(5).Text = TXT_JDG_NG
                        ListView3.Items(i + 1).SubItems(5).BackColor = Color.FromName(COLOR_NG)
                        fncSigRelayTest = RET_NORMAL_NG
                        '' add k.sakemi 2009/11/18
                        If glTarget = TestTarget.HvacSCB01 Then
                            mglFltFormIdx = 3
                            mglFltListViewIdx = 1
                            mglFltListItmIdx = 1
                        End If
                        '' add end
                        '' add k.sakemi 2009/11/19
                        Exit Function
                        '' add end
                    Else
                        ListView3.Items(i + 1).SubItems(5).Text = TXT_JDG_OK
                        ListView3.Items(i + 1).SubItems(5).BackColor = Color.FromName(COLOR_OK)
                    End If

                    bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                    Application.DoEvents()
                    If mglAbortFlg Then
                        Exit Function
                    End If

                End If

                '' del k.sakemi 2009/11/19
                '                '---------------------------------------------
                '                ' AO <-- 10V
                '                '---------------------------------------------
                '#If DEMO = False Then
                '                sngSetData = glPCBChkSigRlyOutV(i).OutData

                '                'Sets each data to 
                '                If gfncAO(AoCards(i), AoChs(i), sngSetData) <> True Then
                '                    Call subWriteErrorLog("AO Set Error", "at fncSigRelayTest of subPCBTest")
                '                    subMainFormMsgLblDsp(MSG_AO_ERR, COLOR_ERR)
                '                    fncSigRelayTest = RET_IOCARD_ERR
                '                    Exit Function
                '                End If

                '                Thread.Sleep(1000)
                '#Else
                '                Thread.Sleep(200)
                '#End If
                '' del end

                Application.DoEvents()

                bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                Application.DoEvents()
                If mglAbortFlg Then
                    Exit Function
                End If

            Else
                ListView3.Items(i).SubItems(5).Text = TXT_JDG_BAR
                ListView3.Items(i + 1).SubItems(5).Text = TXT_JDG_BAR
            End If
        Next

    End Function

    '-----------------------------------------------------------------------------------------------------
    '  DC5V/DC24V Relay Test
    '
    '                               [Return   ] status
    '                                           RET_NORMAL_OK  : Normally Completed
    '                                           RET_NORMAL_NG  : Error
    '                               [Parameter] None
    '   2010.01.16 updated
    '-----------------------------------------------------------------------------------------------------
    Private Function fncDC5V24VRelayTest() As Integer
        Dim dGetData(2 - 1) As Double
        Dim dChkData(2 - 1) As Double
        Dim sErrMsg As String = ""
        Dim iRet As Integer = 0
        Dim i As Integer
        Dim isErrF() As Boolean = New Boolean() {False, False}
        Dim bRet As Boolean

        fncDC5V24VRelayTest = RET_NORMAL_OK

        If glPCBTestIdx(PCBTestIdx.DC5VDC24VTest) = TEST_EXECUTE Then
            For i = 0 To 2
                bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                Application.DoEvents()
                If mglAbortFlg Then
                    Exit Function
                End If

                dChkData(0) = glPCBChkPte5V(i).ChkData  '@@@ [CRITERIA_PCBTEST] PTE_5V_[23|44|375]V_CHK
                dChkData(1) = glPCBChkPte24V(i).ChkData '@@@ [CRITERIA_PCBTEST] PTE_24V_[23|44|375]V_CHK

                '@@@ mrk [ver1.4] >>
                If glTestName = NAME_SPU23BTEST Then
                    ' for SPU23B Test
                    iRet = gfncPCBTest_DC5V24VRelay_Ex(dGetData, glPCBChkPte24V(i), i)
                    If iRet <> RET_NORMAL_OK Then
                        fncDC5V24VRelayTest = iRet
                        Exit Function
                    End If
                Else
                    ' PCB Test DC5V/DC24V Relay Circuit Test function
                    iRet = gfncPCBTest_DC5V24VRelay(dGetData, i)
                    If iRet <> RET_NORMAL_OK Then
                        fncDC5V24VRelayTest = iRet
                        Exit Function
                    End If
                End If
                '@@@ mrk [ver1.4] <<

#If DEMO Then
                'dGetData(0) = 4.5
                'dGetData(0) = 999
                'dGetData(1) = 999
                'Thread.Sleep(5000)
#End If

                '5V
                'Modify 10.02.12 1.07 T.Komine 2010-02-17
                dGetData(0) = dGetData(0) * 1.07
                ListView4.Items(0).SubItems(i + 2).Text = dGetData(0).ToString("0.00")

                If (dGetData(0) >= (dChkData(0) * ((100 - glPCBChkPte5V(i).Range) / 100))) _
                    AndAlso (dGetData(0) <= (dChkData(0) * ((100 + glPCBChkPte5V(i).Range) / 100))) Then
                    ListView4.Items(0).SubItems(i + 2).ForeColor = Color.FromName(COLOR_VALUE_OK)
                Else
                    ListView4.Items(0).SubItems(i + 2).ForeColor = Color.FromName(COLOR_VALUE_NG)
                    isErrF(0) = True
                End If

                '24V
                'Modify 10.02.12 1.02 T.Komine 2010-02-17
                dGetData(1) = dGetData(1) * 1.02
                ListView4.Items(1).SubItems(i + 2).Text = dGetData(1).ToString("0.00")

                If (dGetData(1) >= (dChkData(1) * ((100 - glPCBChkPte24V(i).Range) / 100))) _
                    AndAlso (dGetData(1) <= (dChkData(1) * ((100 + glPCBChkPte24V(i).Range) / 100))) Then
                    ListView4.Items(1).SubItems(i + 2).ForeColor = Color.FromName(COLOR_VALUE_OK)
                Else
                    ListView4.Items(1).SubItems(i + 2).ForeColor = Color.FromName(COLOR_VALUE_NG)
                    isErrF(1) = True
                End If

                Application.DoEvents()

                bRet = fncEmergencyStopBtnCheck()   'emergency button check 2009.04.01 add

                Application.DoEvents()
                If mglAbortFlg Then
                    Exit Function
                End If
            Next

            If isErrF(0) Then
                ListView4.Items(0).SubItems(5).Text = TXT_JDG_NG
                ListView4.Items(0).SubItems(5).BackColor = Color.FromName(COLOR_NG)
                fncDC5V24VRelayTest = RET_NORMAL_NG
                If glTarget = TestTarget.HvacSPU23 Then
                    mglFltListViewIdx = 1
                    mglFltListItmIdx = 1
                End If
            Else
                ListView4.Items(0).SubItems(5).Text = TXT_JDG_OK
                ListView4.Items(0).SubItems(5).BackColor = Color.FromName(COLOR_OK)
            End If

            If isErrF(1) Then
                ListView4.Items(1).SubItems(5).Text = TXT_JDG_NG
                ListView4.Items(1).SubItems(5).BackColor = Color.FromName(COLOR_NG)
                fncDC5V24VRelayTest = RET_NORMAL_NG
                If glTarget = TestTarget.HvacSPU23 Then
                    mglFltListViewIdx = 1
                    mglFltListItmIdx = 2
                End If
            Else
                ListView4.Items(1).SubItems(5).Text = TXT_JDG_OK
                ListView4.Items(1).SubItems(5).BackColor = Color.FromName(COLOR_OK)
            End If

            If isErrF(0) And isErrF(1) Then
                mglFltListItmIdx = 3
            End If
        Else
            ListView4.Items(0).SubItems(5).Text = TXT_JDG_BAR
            ListView4.Items(1).SubItems(5).Text = TXT_JDG_BAR
        End If

    End Function

    '-----------------------------------------------------------------------------------------------------
    '  fncAppearance Check (Check for manual input items)
    '
    '                               [Return   ] status
    '                                                   True : Normally Completed
    '                                                   False : Error
    '                               [Parameter] TestType
    '   2010.01.21 updated
    '-----------------------------------------------------------------------------------------------------
    Private Function fncAppearanceCheck(ByVal ptrTestType As Integer, ByVal iCnt As Integer) As Boolean

        Dim isErrNo() As Integer = New Integer() {0, 0}

        fncAppearanceCheck = True

        Select Case ptrTestType

            'M-SPU23(PCB Test)
            Case TestType.SPU23Test
                If TXT_JDG_NO.Equals(OutlineForm.cmb1.SelectedItem.ToString) Then
                    ListView5.Items(0).SubItems(2).Text = TXT_JDG_OK
                    ListView5.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                Else
                    ListView5.Items(0).SubItems(2).Text = TXT_JDG_NG
                    ListView5.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                    isErrNo(0) = 1
                    fncAppearanceCheck = False
                End If

                If TXT_JDG_NO.Equals(OutlineForm.cmb2.SelectedItem.ToString) Then
                    ListView5.Items(1).SubItems(2).Text = TXT_JDG_OK
                    ListView5.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                Else
                    ListView5.Items(1).SubItems(2).Text = TXT_JDG_NG
                    ListView5.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                    isErrNo(1) = 2
                    fncAppearanceCheck = False
                End If

                If fncAppearanceCheck = False Then
                    mglFltFormIdx = 3
                    mglFltListViewIdx = 1

                    If isErrNo(0) <> 0 Then
                        mglFltListItmIdx = isErrNo(0)
                    ElseIf isErrNo(1) <> 0 Then
                        mglFltListItmIdx = isErrNo(1)
                    End If

                    'fault code (S501,S502) decide
                    glAddTestResultPassed = False
                    glstrTestFltCode = fncGetFltCodefromTrbIni(mglFltFormIdx, mglFltListViewIdx, mglFltListItmIdx)

                End If

                'M-SCB01(PCB Test)
            Case TestType.SCB01Test
                If TXT_JDG_NO.Equals(OutlineForm.cmb3.SelectedItem.ToString) Then
                    ListView6.Items(0).SubItems(2).Text = TXT_JDG_OK
                    ListView6.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                Else
                    ListView6.Items(0).SubItems(2).Text = TXT_JDG_NG
                    ListView6.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                    isErrNo(0) = 1
                    fncAppearanceCheck = False
                End If

                If TXT_JDG_NO.Equals(OutlineForm.cmb4.SelectedItem.ToString) Then
                    ListView6.Items(1).SubItems(2).Text = TXT_JDG_OK
                    ListView6.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                Else
                    ListView6.Items(1).SubItems(2).Text = TXT_JDG_NG
                    ListView6.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                    isErrNo(1) = 2
                    fncAppearanceCheck = False
                End If

                If fncAppearanceCheck = False Then
                    mglFltFormIdx = 4
                    mglFltListViewIdx = 1

                    If isErrNo(0) <> 0 Then
                        mglFltListItmIdx = isErrNo(0)
                    ElseIf isErrNo(1) <> 0 Then
                        mglFltListItmIdx = isErrNo(1)
                    End If

                End If

                'Narrow Down Test
            Case TestType.TCUTest, TestType.MicTest

                If iCnt = 0 Then
                    'M-SPU23(PCB Test)
                    If TXT_JDG_NO.Equals(OutlineForm.cmb1.SelectedItem.ToString) Then
                        ListView5.Items(0).SubItems(2).Text = TXT_JDG_OK
                        ListView5.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                    Else
                        ListView5.Items(0).SubItems(2).Text = TXT_JDG_NG
                        ListView5.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                        'mglFltFormIdx = 3
                        'mglFltListViewIdx = 1
                        'mglFltListItmIdx = 1
                        fncAppearanceCheck = False
                        'Exit Function
                    End If

                    If TXT_JDG_NO.Equals(OutlineForm.cmb2.SelectedItem.ToString) Then
                        ListView5.Items(1).SubItems(2).Text = TXT_JDG_OK
                        ListView5.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                    Else
                        ListView5.Items(1).SubItems(2).Text = TXT_JDG_NG
                        ListView5.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                        'mglFltFormIdx = 3
                        'mglFltListViewIdx = 1
                        'mglFltListItmIdx = 2
                        fncAppearanceCheck = False
                        'Exit Function
                    End If

                Else
                    'M-SCB01(PCB Test)
                    If TXT_JDG_NO.Equals(OutlineForm.cmb3.SelectedItem.ToString) Then
                        ListView6.Items(0).SubItems(2).Text = TXT_JDG_OK
                        ListView6.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                    Else
                        ListView6.Items(0).SubItems(2).Text = TXT_JDG_NG
                        ListView6.Items(0).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                        'mglFltFormIdx = 4
                        'mglFltListViewIdx = 1
                        'mglFltListItmIdx = 1
                        fncAppearanceCheck = False
                        'Exit Function
                    End If

                    If TXT_JDG_NO.Equals(OutlineForm.cmb4.SelectedItem.ToString) Then
                        ListView6.Items(1).SubItems(2).Text = TXT_JDG_OK
                        ListView6.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_OK)

                    Else
                        ListView6.Items(1).SubItems(2).Text = TXT_JDG_NG
                        ListView6.Items(1).SubItems(2).BackColor = Color.FromName(COLOR_NG)
                        'mglFltFormIdx = 4
                        'mglFltListViewIdx = 1
                        'mglFltListItmIdx = 2
                        fncAppearanceCheck = False
                        'Exit Function
                    End If
                End If
        End Select

        Application.DoEvents()

    End Function

#If DEMO Then
    ''---------------------------------------------------------------
    ''   for TS DEMO
    ''   2020-10-13 add by nis [v1.4]
    ''---------------------------------------------------------------
    'Private Sub cmbDemoTestType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbDemoTestType.SelectedIndexChanged
    '    Dim sKey_Testname() As String = {"_SPU_A_GONOGO", "_SPU_B_GONOGO", "_SCB_GONOGO"}
    '    Dim StrBuffer As New System.Text.StringBuilder
    '    Dim iRet As Integer
    '    Dim sTmp() As String

    '    Try
    '        'for DEBUGGING Troubleshooting messages
    '        cmbDemoFaultCode.Items.Clear()

    '        'displays Test execution time
    '        StrBuffer.Capacity = 255
    '        StrBuffer.Remove(0, StrBuffer.Length)
    '        iRet = GetPrivateProfileString("DEMO", "FAULT_CODE" & sKey_Testname(cmbDemoTestType.SelectedIndex), "", StrBuffer, StrBuffer.Capacity, glAppHomePath & "\" & INIFILE)
    '        If String.IsNullOrEmpty(StrBuffer.ToString.Trim) = False Then
    '            sTmp = StrBuffer.ToString.Split(",")
    '            For iCnt As Integer = 0 To sTmp.Length - 1
    '                cmbDemoFaultCode.Items.Add(sTmp(iCnt))
    '            Next
    '            cmbDemoFaultCode.SelectedIndex = 0
    '        End If

    '    Catch ex As Exception
    '        MessageBox.Show("cmbDemoTestType_SelectedIndexChanged() -exception occurred!")
    '    Finally
    '        StrBuffer = Nothing
    '    End Try

    'End Sub

    '---------------------------------------------------------------
    '   for TS DEMO
    '   2020-10-13 add by nis [v1.4]
    '---------------------------------------------------------------
    Private Sub cmbDemoFaultCode_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbDemoFaultCode.SelectedIndexChanged
        Dim iRet As Integer = 0
        Dim strBuffer As New System.Text.StringBuilder()

        Try
            If cmbDemoFaultCode.Items.Count > 0 Then
                glstrTestFltCode = cmbDemoFaultCode.SelectedItem.ToString

                ''Narrowdown Testがあるコードか
                'If "A101".Equals(glstrTestFltCode) OrElse "T101".Equals(glstrTestFltCode) Then
                '    cmbDemoNrwDwn.Visible = True
                '    cmbDemoNrwDwn.SelectedIndex = 0
                'Else
                '    cmbDemoNrwDwn.Visible = False
                '    glAdditionalTestF = False
                'End If

                glAddTestPtnNo = fncSetAddTestPtnNo(glstrTestFltCode)  'INI定義がない
            End If

        Catch ex As Exception
            MessageBox.Show("cmbDemoFaultCode_SelectedIndexChanged() -exception occurred!")
        End Try

    End Sub

    ''---------------------------------------------------------------
    ''   for TS DEMO
    ''   2020-10-13 add by nis [v1.4]
    ''---------------------------------------------------------------
    'Private Sub cmbDemoNrwDwn_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbDemoNrwDwn.SelectedIndexChanged

    '    Try
    '        Select Case cmbDemoNrwDwn.SelectedIndex
    '            Case 0      'Go/NoGo
    '                glAdditionalTestF = False
    '                glAddTestResultPassed = True
    '                glNarrowTestFltCode = 0

    '            Case 1      'Narrowdown Passed
    '                glAdditionalTestF = True
    '                glAddTestResultPassed = True
    '                glNarrowTestFltCode = 0

    '            Case 2 To 7 'Narrowdown Failed
    '                glAdditionalTestF = True
    '                glAddTestResultPassed = False
    '                glNarrowTestFltCode = cmbDemoNrwDwn.SelectedIndex - 1

    '            Case Else
    '                glAdditionalTestF = False
    '                glAddTestResultPassed = True
    '                glNarrowTestFltCode = 0
    '        End Select

    '    Catch ex As Exception
    '        MessageBox.Show("cmbDemoNrwDwn_SelectedIndexChanged() -exception occurred!")
    '    End Try

    'End Sub

#End If


End Class